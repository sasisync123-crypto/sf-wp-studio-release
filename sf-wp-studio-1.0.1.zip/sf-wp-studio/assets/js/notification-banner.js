document.addEventListener('DOMContentLoaded', () => {
  const banners = document.querySelectorAll('.custom-banner');
  if (banners.length === 0) return;

  banners.forEach((banner, index) => {
    const isToast = banner.dataset.toastMode === 'true';
    const autoHide = banner.dataset.autoHide === 'true';
    const hideDelay = parseInt(banner.dataset.hideDelay || '3') * 1000;
    const dismissIcon = banner.querySelector('.sf-icon-wrapper');
    const parent = banner.closest('.e-con-inner');

    banner.style.transition = 'opacity 0.5s ease, visibility 0.5s ease';
    if (parent) {
      parent.style.transition = 'height 0.3s ease, padding 0.3s ease';
    }

    const showBanner = () => {
      banner.style.opacity = '1';
      banner.style.visibility = 'visible';
    };

    const hideBanner = () => {
      banner.style.opacity = '0';
      banner.style.visibility = 'hidden';
      if (parent) {
        parent.style.height = '0';
        parent.style.padding = '0';
        parent.style.overflow = 'hidden';
      }
      setTimeout(() => {
        banner.remove();
      }, 500);
    };

    if (!isToast) {
      showBanner();
    } else {
      const delay = 2000 * (index + 1);
      setTimeout(() => {
        showBanner();
        if (autoHide) {
          setTimeout(() => {
            hideBanner();
          }, hideDelay);
        }
      }, delay);
    }

    if (dismissIcon) {
      dismissIcon.addEventListener('click', () => {
        hideBanner();
      });
    }
  });
});
