<?php
/* 
 * Plugin Name: SF Widget Suite
 * Description: Modular Elementor widget suite with dark mode, and multilingual support.
 * Version: 1.0.1
 * Author: Syncfusion, Inc
 * Text Domain: sfwp-studio
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Define the plugin root path constant.
define( 'SFWP_DIR', plugin_dir_path( __FILE__ ) );

// Check Elementor is active
function sfwp_studio_check_elementor() {
    if ( ! did_action( 'elementor/loaded' ) ) {
        add_action( 'admin_notices', function() {
            echo '<div class="notice notice-error"><p>SFWP Studio requires Elementor to be installed and activated.</p></div>';
        });
        return;
    }

    // Load plugin core
    require_once plugin_dir_path( __FILE__ ) . 'includes/loader.php';
}
add_action( 'plugins_loaded', 'sfwp_studio_check_elementor' );

// Load translations
function sfwp_studio_load_textdomain() {
    load_plugin_textdomain( 'sfwp-studio', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
}
add_action( 'init', 'sfwp_studio_load_textdomain' );



require_once SFWP_DIR . 'plugin-update-checker-5.6/plugin-update-checker.php'; 
use YahnisElsts\PluginUpdateChecker\v5\PucFactory;
 
$updateChecker = PucFactory::buildUpdateChecker(

    'https://raw.githubusercontent.com/sasisync123-crypto/sf-wp-studio-release/refs/heads/main/update.json',
    __FILE__,
    'sf-wp-studio'
);
