<?php
namespace SFWPStudio\Widgets;

if ( ! defined( 'ABSPATH' ) ) exit;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Repeater;

class Client_Logo extends \Elementor\ElementsKit_Widget_Client_Logo
{
    public function get_name()
    {
        return 'sf-client-logo';
    }

    public function get_title()
    {
        return __('SF Client Logo', 'my-elementor-widgets');
    }

    public function get_icon()
    {
        return 'sync-widget-icon eicon-tabs';
    }

    public function get_keywords()
    {
        return ['client', 'logo', 'carousel', 'slider'];
    }

    public function get_script_depends()
    {
        return ['client-logo'];
    }

    //SFWP CODE STARTS
    public function get_categories()
    {
        return ['syncfusion-widgets'];
    }

    public function is_dynamic_content(): bool
    {
        return false;
    }
    //SFWP CODE ENDS

    public static function get_placeholder_image_src()
    {
        $placeholder_image = ELEMENTOR_ASSETS_URL . 'images/placeholder.png';

        /**
         * Get placeholder image source.
         *
         * Filters the source of the default placeholder image used by Elementor.
         *
         * @since 1.0.0
         *
         * @param string $placeholder_image The source of the default placeholder image.
         */
        $placeholder_image = apply_filters('elementor/utils/get_placeholder_image_src', $placeholder_image);

        return $placeholder_image;
    }

    protected function register_controls()
    {

        $this->start_controls_section(
            'ekit_client_logo_section_client',
            [
                'label' => esc_html__('Logo', 'sf-widget'),
            ]
        );

        $this->add_control(
            'ekit_client_logo_slide_style',
            [
                'label' => esc_html__('Slide Style ', 'sf-widget'),
                'type' => Controls_Manager::SELECT,
                'default' => 'simple_logo_image',
                'options' => [
                    'simple_logo_image' => esc_html__('Simple', 'sf-widget'),
                    'banner_logo_image' => esc_html__('Banner', 'sf-widget'),
                ],
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'ekit_client_logo_list_title',
            [
                'label' => esc_html__('Client Name', 'sf-widget'),
                'type' => Controls_Manager::TEXT,
                'dynamic' => [
                    'active' => true,
                ],
                'default' => esc_html__('List Title', 'sf-widget'),
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'ekit_client_logo_image_normal',
            [
                'label' => esc_html__('Client Logo', 'sf-widget'),
                'type' => Controls_Manager::MEDIA,
                'dynamic' => [
                    'active' => true,
                ],
                'default' => [
                    'url' => $this->get_placeholder_image_src(),
                    'id' => -1
                ],
            ]
        );

        $repeater->add_control(
            'ekit_client_logo_enable_hover_logo',
            [
                'label' => esc_html__('Enable Hover Logo', 'sf-widget'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'sf-widget'),
                'label_off' => esc_html__('No', 'sf-widget'),
                'return_value' => 'yes',
                'default' => '',
            ]
        );

        $repeater->add_control(
            'ekit_client_logo_image_hover',
            [
                'label' => esc_html__('Hover Logo', 'sf-widget'),
                'type' => Controls_Manager::MEDIA,
                'dynamic' => [
                    'active' => true,
                ],
                'default' => [
                    'url' => $this->get_placeholder_image_src(),
                    'id' => -1
                ],
                'condition' => [
                    'ekit_client_logo_enable_hover_logo' => 'yes'
                ]
            ]
        );

        $repeater->add_control(
            'ekit_client_logo_enable_link',
            [
                'label' => esc_html__('Enable Link', 'sf-widget'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'sf-widget'),
                'label_off' => esc_html__('No', 'sf-widget'),
                'return_value' => 'yes',
            ]
        );

        $repeater->add_control(
            'ekit_client_logo_website_link',
            [
                'label' => esc_html__('Link', 'sf-widget'),
                'type' => Controls_Manager::URL,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__('https://wpmet.com', 'sf-widget'),
                'show_external' => true,
                'condition' => [
                    'ekit_client_logo_enable_link' => 'yes'
                ],
            ]
        );


        $this->add_control(
            'ekit_client_logo_repiter',
            [
                'label' => esc_html__('Repeater List', 'sf-widget'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'ekit_client_logo_list_title' => esc_html__('Title #1', 'sf-widget'),
                    ],
                    [
                        'ekit_client_logo_list_title' => esc_html__('Title #2', 'sf-widget'),
                    ],
                    [
                        'ekit_client_logo_list_title' => esc_html__('Title #3', 'sf-widget'),
                    ],
                    [
                        'ekit_client_logo_list_title' => esc_html__('Title #4', 'sf-widget'),
                    ],
                    [
                        'ekit_client_logo_list_title' => esc_html__('Title #5', 'sf-widget'),
                    ],
                    [
                        'ekit_client_logo_list_title' => esc_html__('Title #6', 'sf-widget'),
                    ],
                    [
                        'ekit_client_logo_list_title' => esc_html__('Title #7', 'sf-widget'),
                    ],
                ],
                'title_field' => '{{{ ekit_client_logo_list_title }}}',
            ]
        );

        $this->end_controls_section();

        // setting section

        $this->start_controls_section(
            'ekit_client_logo_slider_settings',
            [
                'label' => esc_html__('Settings', 'sf-widget'),
            ]
        );

        $this->add_control(
            'ekit_client_logo_slider_direction',
            [
                'label' => esc_html__('Slider Direction', 'elementskit'),
                'type' => Controls_Manager::SELECT,
                'default' => 'rtl',
                'options' => [
                    'ltr' => esc_html__('Left to Right', 'elementskit'),
                    'rtl' => esc_html__('Right to Left', 'elementskit'),
                ],
            ]
        );

        $this->add_responsive_control(
            'ekit_client_logo_left_right_spacing',
            [
                'label' => esc_html__('Spacing Left Right', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'default' => [
                    'size' => 24,
                ],
                'tablet_default' => [
                    'size' => 10,
                ],
                'mobile_default' => [
                    'size' => 10,
                ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                        'step' => 1,
                    ],
                ],
                'render_type' => 'template',
                'selectors' => [
                    '{{WRAPPER}} .elementskit-clients-slider' => '--ekit_client_logo_left_right_spacing: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'ekit_client_logo_slidetosho',
            [
                'label' => esc_html__('Slides To Show', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 1,
                        'max' => 20,
                        'step' => 1,
                    ],
                ],
                'devices' => ['desktop', 'tablet', 'mobile'],
                'desktop_default' => [
                    'size' => 7,
                    'unit' => 'px',
                ],
                'tablet_default' => [
                    'size' => 7,
                    'unit' => 'px',
                ],
                'mobile_default' => [
                    'size' => 7,
                    'unit' => 'px',
                ],
                'default' => [
                    'size' => 7,
                    'unit' => 'px',
                ],
                'render_type' => 'template',
                'selectors' => [
                    '{{WRAPPER}} .ekit-price-card-slider' => '--ekit_client_logo_slidetosho:  {{SIZE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'ekit_client_logo_slidesToScroll',
            [
                'label' => esc_html__('Slides To Scroll', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 1,
                        'max' => 20,
                        'step' => 1,
                    ],
                ],
                'devices' => ['desktop', 'tablet', 'mobile'],
                'desktop_default' => [
                    'size' => 1,
                    'unit' => 'px',
                ],
                'tablet_default' => [
                    'size' => 1,
                    'unit' => 'px',
                ],
                'mobile_default' => [
                    'size' => 1,
                    'unit' => 'px',
                ],
                'default' => [
                    'size' => 1,
                    'unit' => 'px',
                ],
            ]
        );



        $this->add_control(
            'ekit_client_logo_autoplay',
            [
                'label' => esc_html__('Autoplay', 'sf-widget'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'sf-widget'),
                'label_off' => esc_html__('No', 'sf-widget'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
        $this->add_control(
            'ekit_client_logo_speed',
            [
                'label' => esc_html__('Speed (ms)', 'sf-widget'),
                'type' => Controls_Manager::NUMBER,
                'min' => 1000,
                'max' => 15000,
                'step' => 100,
                'default' => 3000,
                'condition' => [
                    'ekit_client_logo_autoplay' => 'yes',
                ]
            ]
        );
        $this->add_control(
            'ekit_client_logo_pause_on_hover',
            [
                'label' => esc_html__('Pause on Hover', 'sf-widget'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'sf-widget'),
                'label_off' => esc_html__('No', 'sf-widget'),
                'return_value' => 'yes',
                'default' => 'yes',
                'condition' => [
                    'ekit_client_logo_autoplay' => 'yes',
                ]
            ]
        );
        $this->add_control(
            'ekit_client_logo_show_arrow',
            [
                'label' => esc_html__('Show arrow', 'sf-widget'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'sf-widget'),
                'label_off' => esc_html__('No', 'sf-widget'),
                'return_value' => 'yes',
                'default' => '',
            ]
        );
        $this->add_control(
            'ekit_client_logo_loop',
            [
                'label' => esc_html__('Enable Loop?', 'sf-widget'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'sf-widget'),
                'label_off' => esc_html__('No', 'sf-widget'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
        $this->add_control(
            'ekit_client_logo_left_arrow_icon',
            [
                'label' => esc_html__('Left arrow Icon', 'sf-widget'),
                'type' => Controls_Manager::ICONS,
                'fa4compatibility' => 'ekit_client_logo_left_arrow',
                'default' => [
                    'value' => 'icon icon-left-arrow2',
                    'library' => 'ekiticons',
                ],
                'condition' => [
                    'ekit_client_logo_show_arrow' => 'yes',
                ]
            ]
        );

        $this->add_control(
            'ekit_client_logo_right_arrow_icon',
            [
                'label' => esc_html__('Right arrow Icon', 'sf-widget'),
                'type' => Controls_Manager::ICONS,
                'fa4compatibility' => 'ekit_client_logo_right_arrow',
                'default' => [
                    'value' => 'icon icon-right-arrow2',
                    'library' => 'ekiticons',
                ],
                'condition' => [
                    'ekit_client_logo_show_arrow' => 'yes',
                ]
            ]
        );
        $this->add_control(
            'ekit_client_logo_show_dot',
            [
                'label' => esc_html__('Show dots', 'sf-widget'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'sf-widget'),
                'label_off' => esc_html__('No', 'sf-widget'),
                'return_value' => 'yes',
                'default' => '',
            ]
        );

        $this->add_control(
            'ekit_client_logo_additional_option_heading',
            [
                'label' => esc_html__('Additional Options', 'sf-widget'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'ekit_client_logo_rows',
            [
                'label' => esc_html__('Rows', 'sf-widget'),
                'description' => esc_html__('Setting this to more than 1 initializes grid mode. Use slidesPerRow to set how many slides should be in each row.
				', 'sf-widget'),
                'type' => Controls_Manager::SELECT,
                'default' => 1,
                'options' => [
                    '1' => esc_html__('One row', 'sf-widget'),
                    '2' => esc_html__('Two row', 'sf-widget'),
                    '3' => esc_html__('Three row', 'sf-widget'),
                ],
            ]
        );
        $this->add_control(
            'ekit_client_logo_separator',
            [
                'label' => esc_html__('Show Separator', 'sf-widget'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Show', 'sf-widget'),
                'label_off' => esc_html__('Hide', 'sf-widget'),
                'return_value' => 'yes',
                'default' => '',
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'ekit_client_logo_container_style_tab',
            [
                'label' => esc_html__('Container', 'sf-widget'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'ekit_client_logo_container_bg_color',
                'label' => esc_html__('Background', 'sf-widget'),
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .elementskit-clients-slider .ekit-main-swiper'
            ]
        );

        $this->add_responsive_control(
            'ekit_client_logo_container_padding',
            [
                'label' => esc_html__('Padding', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .elementskit-clients-slider .swiper-wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'ekit_client_logo_container_margin',
            [
                'label' => esc_html__('Margin', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .elementskit-clients-slider .swiper-wrapper' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'ekit_client_logo_container_min_height',
            [
                'label' => esc_html__('Min Height', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'step' => 1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementskit-clients-slider .single-client' => 'min-height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        // style tab
        // Logo

        $this->start_controls_section(
            'ekit_client_logo_image_style',
            [
                'label' => esc_html__('Logo', 'sf-widget'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    // 'ekit_client_logo_slide_style' => 'simple_logo_image',
                ]
            ]
        );

        $this->add_responsive_control(
            'ekit_client_logo_image_style_border_radious',
            [
                'label' => esc_html__('Border Radius', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .elementskit-clients-slider .single-client' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'ekit_client_logo_hover_animation_driction',
            [
                'label' => esc_html__('Overlay Direction', 'sf-widget'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'hover_from_left' => [
                        'title' => esc_html__('From Left', 'sf-widget'),
                        'icon' => 'fa fa-caret-right',
                    ],
                    'hover_from_top' => [
                        'title' => esc_html__('From Top', 'sf-widget'),
                        'icon' => 'fa fa-caret-down',
                    ],
                    'hover_from_bottom' => [
                        'title' => esc_html__('From Bottom', 'sf-widget'),
                        'icon' => 'fa fa-caret-up',
                    ],
                    'hover_from_right' => [
                        'title' => esc_html__('From Right', 'sf-widget'),
                        'icon' => 'fa fa-caret-left',
                    ],

                ],
                'default' => 'hover_from_bottom',
                'toggle' => true,
                'condition' => [
                    'ekit_client_logo_slide_style' => 'banner_logo_image'
                ]
            ]
        );


        $this->add_group_control(
            Group_Control_Background::get_type(),
            array(
                'name' => 'ekit_client_logo_hover_animation_color',
                'label' => esc_html__('Hover Background', 'sf-widget'),
                'default' => '',
                'selector' => '{{WRAPPER}} .elementskit-clients-slider.banner_logo_image .single-client:before',
                'condition' => [
                    'ekit_client_logo_slide_style' => 'banner_logo_image'
                ]
            )
        );

        $this->add_responsive_control(
            'ekit_client_logo_margin',
            [
                'label' => esc_html__('Margin', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .single-client' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'ekit_client_logo_padding',
            [
                'label' => esc_html__('Padding', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .single-client' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'section_divider',
            [
                'type' => Controls_Manager::DIVIDER,
                'style' => 'solid',
            ]
        );

        $this->add_control(
            'client_logo_image_fit',
            [
                'label' => esc_html__('Image Object Fit', 'my-elementor-widgets'),
                'type' => Controls_Manager::SELECT,
                'default' => 'contain',
                'options' => [
                    'contain' => esc_html__('Contain', 'my-elementor-widgets'),
                    'cover' => esc_html__('Cover', 'my-elementor-widgets'),
                    'fill' => esc_html__('Fill', 'my-elementor-widgets'),
                    'none' => esc_html__('None', 'my-elementor-widgets'),
                    'scale-down' => esc_html__('Scale Down', 'my-elementor-widgets'),
                ],
                'selectors' => [
                    '{{WRAPPER}} .content-image img' => 'object-fit: {{VALUE}}; width: 100%; height: 100%;',
                ],
            ]
        );

        $this->add_responsive_control(
            'client_logo_image_width',
            [
                'label' => esc_html__('Image Width', 'my-elementor-widgets'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%', 'vw'],
                'range' => [
                    'px' => ['min' => 50, 'max' => 500],
                    '%' => ['min' => 10, 'max' => 100],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 56,
                ],
                'selectors' => [
                    '{{WRAPPER}} .content-image' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'client_logo_image_height',
            [
                'label' => esc_html__('Image Height', 'my-elementor-widgets'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'vh'],
                'range' => [
                    'px' => ['min' => 30, 'max' => 300],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 56,
                ],
                'selectors' => [
                    '{{WRAPPER}} .content-image' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->start_controls_tabs(
            'ekit_client_logo_border_control'
        );

        $this->start_controls_tab(
            'ekit_client_logo_border_style_normal_tab',
            [
                'label' => esc_html__('Normal', 'sf-widget'),
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'ekit_client_logo_image_box_shadow_group',
                'label' => esc_html__('Box Shadow', 'sf-widget'),
                'selector' => '{{WRAPPER}} .elementskit-clients-slider .single-client',
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'ekit_client_logo_image_style_border_group',
                'label' => esc_html__('Border', 'sf-widget'),
                'selector' => '{{WRAPPER}} .elementskit-clients-slider .single-client',
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'ekit_client_logo_border_style_hover_tab',
            [
                'label' => esc_html__('Hover', 'sf-widget'),
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'ekit_client_logo_image_box_shadow_hover_group',
                'label' => esc_html__('Box Shadow', 'sf-widget'),
                'selector' => '{{WRAPPER}} .elementskit-clients-slider.simple_logo_image .single-client:hover',
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'ekit_client_logo_image_style_hover_border_group',
                'label' => esc_html__('Border', 'sf-widget'),
                'selector' => '{{WRAPPER}} .elementskit-clients-slider .single-client:hover',
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();

        $this->start_controls_tabs('ekit_client_logo_normal_tab');

        $this->start_controls_tab(
            'ekit_client_logo_style_normal_tab',
            [
                'label' => esc_html__('Normal', 'sf-widget'),
            ]
        );

        $this->add_responsive_control(
            'ekit_client_logo_opacity',
            [
                'label' => esc_html__('Opacity', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [''],
                'range' => [
                    '' => [
                        'min' => 0,
                        'max' => 1,
                        'step' => .1,
                    ],
                ],
                'default' => [
                    'unit' => '',
                    'size' => 1,
                ],
                'selectors' => [
                    '{{WRAPPER}} .simple_logo_image .single-client .content-image .main-image' => 'opacity: {{SIZE}};filter: alpha(opacity={{SIZE}})',
                    '{{WRAPPER}} .elementskit-clients-slider .single-client img' => 'opacity: {{SIZE}};filter: alpha(opacity={{SIZE}})',
                ],
            ]
        );

        $this->end_controls_tab();

        //  hover tab

        $this->start_controls_tab(
            'ekit_client_logo_style_hover_tab',
            [
                'label' => esc_html__('Hover', 'sf-widget'),
            ]
        );

        $this->add_responsive_control(
            'ekit_client_logo_opacity_hover',
            [
                'label' => esc_html__('Opacity', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [''],
                'range' => [
                    '' => [
                        'min' => 0,
                        'max' => 1,
                        'step' => .1,
                    ],
                ],
                'default' => [
                    'unit' => '',
                    'size' => 1,
                ],
                'selectors' => [
                    '{{WRAPPER}} .simple_logo_image .single-client:hover .content-image img' => 'opacity: {{SIZE}};filter: alpha(opacity={{SIZE}})',
                ],
            ]
        );

        $this->add_responsive_control(
            'ekit_client_logo_hover_opacity',
            [
                'label' => esc_html__('Opacity Hover', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [''],
                'range' => [
                    '' => [
                        'min' => 0,
                        'max' => 1,
                        'step' => .1,
                    ],
                ],
                'default' => [
                    'unit' => '',
                    'size' => 1,
                ],
                'selectors' => [
                    '{{WRAPPER}} .simple_logo_image .single-client:hover .content-image .main-image' => 'opacity: {{SIZE}};filter: alpha(opacity={{SIZE}})',
                ],
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

        //  Navigation section

        $this->start_controls_section(
            'ekit_client_logo_section_navigation',
            [
                'label' => esc_html__('Arrows', 'sf-widget'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'ekit_client_logo_show_arrow' => 'yes'
                ]
            ]
        );

        $this->add_control(
            'ekit_client_logo_arrow_pos',
            [
                'label' => esc_html__('Position', 'sf-widget'),
                'type' => Controls_Manager::SELECT,
                'default' => 'arrow_inside',
                'options' => [
                    'arrow_outside' => esc_html__('Outside', 'sf-widget'),
                    'arrow_inside' => esc_html__('Inside', 'sf-widget'),
                ],
            ]
        );

        $this->add_responsive_control(
            'ekit_client_logo_arrow_size',
            [
                'label' => esc_html__('Size', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 10,
                        'max' => 200,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 20,
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementskit-clients-slider .swiper-navigation-button' => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .elementskit-clients-slider .swiper-navigation-button svg' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'ekit_client_logo_arrow_padding',
            [
                'label' => esc_html__('Padding', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'default' => [
                    'unit' => 'px',
                    'top' => 15,
                    'right' => 15,
                    'bottom' => 15,
                    'left' => 15,
                    'isLinked' => true
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementskit-clients-slider .swiper-navigation-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'ekit_client_logo_arrow_border_group',
                'label' => esc_html__('Border', 'sf-widget'),
                'selector' => '{{WRAPPER}} .elementskit-clients-slider .swiper-navigation-button',
            ]
        );

        $this->add_responsive_control(
            'ekit_client_logo_arrow_border_radious',
            [
                'label' => esc_html__('Border Radius', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .elementskit-clients-slider .swiper-navigation-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'ekit_client_logo_arrow_shadow',
                'selector' => '{{WRAPPER}} .elementskit-clients-slider .swiper-navigation-button',
            ]
        );

        $this->add_control(
            'ekit_client_logo_position_popover_toggle',
            [
                'label' => esc_html__('Arrow Position', 'sf-widget'),
                'type' => Controls_Manager::POPOVER_TOGGLE,
                'label_off' => esc_html__('Default', 'sf-widget'),
                'label_on' => esc_html__('Custom', 'sf-widget'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->start_popover();

        $this->add_control(
            'ekit_client_logo_arrow_pos_head',
            [
                'label' => esc_html__('Left Arrow Position', 'sf-widget'),
                'type' => Controls_Manager::HEADING
            ]
        );

        $this->add_responsive_control(
            'ekit_client_logo_arrow_left_pos',
            [
                'label' => esc_html__('Left Arrow Position (X)', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => -1000,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => -1000,
                        'max' => 1000,
                    ],
                ],

                'selectors' => [
                    '{{WRAPPER}} .elementskit-clients-slider .swiper-navigation-button.swiper-button-prev' => 'left: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    "ekit_client_logo_position_popover_toggle!" => '',
                ],
            ]
        );

        $this->add_responsive_control(
            'ekit_client_logo_arrow_left_vertical_pos',
            [
                'label' => esc_html__('Left Arrow Position (Y)', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => -1000,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => -1000,
                        'max' => 1000,
                    ],
                ],

                'selectors' => [
                    '{{WRAPPER}} .elementskit-clients-slider .swiper-navigation-button.swiper-button-prev' => 'top: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    "ekit_client_logo_position_popover_toggle!" => '',
                ],
            ]
        );

        $this->add_control(
            'ekit_client_logo_arrow_right_pos_head',
            [
                'label' => esc_html__('Right Arrow Position', 'sf-widget'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'ekit_client_logo_arrow_right_pos',
            [
                'label' => esc_html__('Right Arrow Position (X)', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => -1000,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => -1000,
                        'max' => 1000,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementskit-clients-slider .swiper-navigation-button.swiper-button-next' => 'right: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    "ekit_client_logo_position_popover_toggle!" => '',
                ],
            ]
        );

        $this->add_responsive_control(
            'ekit_client_logo_arrow_right_vertical_pos',
            [
                'label' => esc_html__('Right Arrow Position (Y)', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => -1000,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => -1000,
                        'max' => 1000,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementskit-clients-slider .swiper-navigation-button.swiper-button-next' => 'top: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    "ekit_client_logo_position_popover_toggle!" => '',
                ],
            ]
        );

        $this->end_popover();
        // Arrow Normal

        $this->start_controls_tabs('ekit_logo_style_tabs');

        $this->start_controls_tab(
            'ekit_logo_arrow_normal_tab',
            [
                'label' => esc_html__('Normal', 'sf-widget'),
            ]
        );

        $this->add_control(
            'ekit_client_logo_arrow_color',
            [
                'label' => esc_html__('Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .elementskit-clients-slider .swiper-navigation-button' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .elementskit-clients-slider .swiper-navigation-button svg' => 'fill: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'ekit_client_logo_arrow_background',
            [
                'label' => esc_html__('Background', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .elementskit-clients-slider .swiper-navigation-button' => 'background: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_tab();

        //  Arrow hover tab

        $this->start_controls_tab(
            'ekit_client_logo_arrow_hover_tab',
            [
                'label' => esc_html__('Hover', 'sf-widget'),
            ]
        );

        $this->add_control(
            'ekit_client_logo_arrow_hv_color',
            [
                'label' => esc_html__('Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .elementskit-clients-slider .swiper-navigation-button:hover' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .elementskit-clients-slider .swiper-navigation-button:hover svg' => 'fill: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'ekit_client_logo_arrow_hover_background',
            [
                'label' => esc_html__('Background', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .elementskit-clients-slider .swiper-navigation-button:hover' => 'background: {{VALUE}}',
                ],
            ]
        );
        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();


        // Dots

        $this->start_controls_section(
            'ekit_client_logo_navigation_dot',
            [
                'label' => esc_html__('Dots', 'sf-widget'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'ekit_client_logo_show_dot' => 'yes'
                ]
            ]
        );

        $this->add_control(
            'ekit_client_logo_client_logo_dot_style',
            [
                'label' => esc_html__('Dot Style', 'sf-widget'),
                'type' => Controls_Manager::SELECT,
                'default' => 'dot_dotted',
                'options' => [
                    'dot_default' => esc_html__('Default', 'sf-widget'),
                    'dot_dashed' => esc_html__('Dashed', 'sf-widget'),
                    'dot_dotted' => esc_html__('Dotted', 'sf-widget'),
                    'dot_paginated' => esc_html__('Paginate', 'sf-widget'),
                ],
            ]
        );

        $this->add_responsive_control(
            'ekit_client_logo_dots_left_right_spacing',
            [
                'label' => esc_html__('Spacing Left Right', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'default' => [
                    'size' => 8,
                ],
                'tablet_default' => [
                    'size' => 10,
                ],
                'mobile_default' => [
                    'size' => 10,
                ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementskit-clients-slider .swiper-pagination > span' => 'margin-right: {{SIZE}}{{UNIT}};margin-left: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'ekit_client_logo_dots_top_to_bottom',
            [
                'label' => esc_html__('Spacing Top To Bottom', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => -120,
                        'max' => 120,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => -50,
                ],

                'selectors' => [
                    '{{WRAPPER}} .elementskit-clients-slider .swiper-pagination' => 'bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'ekit_client_logo_dot_color',
            [
                'label' => esc_html__('Dot Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .elementskit-clients-slider.dot_paginated .swiper-pagination > span' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'ekit_client_logo_client_logo_dot_style' => 'dot_paginated'
                ]
            ]
        );

        $this->add_responsive_control(
            'ekit_client_logo_dot_width',
            [
                'label' => esc_html__('Width', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 8,
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementskit-clients-slider .swiper-pagination > span' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'ekit_client_logo_dot_height',
            [
                'label' => esc_html__('Height', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 8,
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementskit-clients-slider .swiper-pagination > span' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'ekit_client_logo_dot_border_radius',
            [
                'label' => esc_html__('Border radius', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .elementskit-clients-slider .swiper-pagination > span' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'ekit_client_logo_dot_background',
                'label' => esc_html__('Background', 'sf-widget'),
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .elementskit-clients-slider .swiper-pagination > span',
            ]
        );

        $this->add_control(
            'ekit_client_logo_dot_active_heading',
            [
                'label' => esc_html__('Active', 'sf-widget'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'ekit_client_logo_dot_active_background',
                'label' => esc_html__('Background', 'sf-widget'),
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .elementskit-clients-slider .swiper-pagination span.swiper-pagination-bullet-active',
            ]
        );

        $this->add_responsive_control(
            'ekit_client_logo_dot_active_width',
            [
                'label' => esc_html__('Width', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 40,
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementskit-clients-slider .swiper-pagination span.swiper-pagination-bullet-active' => 'width: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'ekit_client_logo_client_logo_dot_style' => 'dot_dashed'
                ],
            ]
        );

        $this->add_responsive_control(
            'ekit_client_logo_dot_active_scale',
            [
                'label' => esc_html__('Height', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => .5,
                        'max' => 3,
                        'step' => 0.1,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 1.2,
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementskit-clients-slider .swiper-pagination span.swiper-pagination-bullet-active' => 'transform: scale({{SIZE}});',
                ],
                'condition' => [
                    'ekit_client_logo_client_logo_dot_style' => 'dot_dotted'
                ],
            ]
        );

        $this->end_controls_section();

        //  Separator
        $this->start_controls_section(
            'ekit_client_logo_separator_section',
            [
                'label' => esc_html__('Separator', 'sf-widget'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'ekit_client_logo_separator' => 'yes'
                ]
            ]
        );
        $this->add_responsive_control(
            'ekit_client_logo_separator_height',
            [
                'label' => esc_html__('Hight', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 5,
                        'max' => 100,
                        'step' => 1,
                    ],

                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 30,
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementskit-clients-slider .elementskit-client-slider-item.log-separator:after' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'ekit_client_logo_separator_width',
            [
                'label' => esc_html__('Width', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 1,
                        'max' => 10,
                        'step' => 1,
                    ],

                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 2,
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementskit-clients-slider .elementskit-client-slider-item.log-separator:after' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'ekit_client_logo_separator_top_bottom_position',
            [
                'label' => esc_html__('Top Bottom Position', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['%'],
                'range' => [
                    '%' => [
                        'min' => -10,
                        'max' => 110,
                        'step' => 1,
                    ],

                ],
                'default' => [
                    'unit' => '%',
                    'size' => 50,
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementskit-clients-slider .elementskit-client-slider-item.log-separator:after' => 'top: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'ekit_client_logo_separator_left_right_position',
            [
                'label' => esc_html__('Left Right Position', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['%'],
                'range' => [
                    '%' => [
                        'min' => -5,
                        'max' => 120,
                        'step' => 1,
                    ],

                ],
                'default' => [
                    'unit' => '%',
                    'size' => 100,
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementskit-clients-slider .elementskit-client-slider-item.log-separator:after' => 'left: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->start_controls_tabs('ekit_client_logo_seperator_color_tabs');

        $this->start_controls_tab(
            'ekit_client_logo_seperator_color_normal_tab',
            [
                'label' => esc_html__('Normal', 'sf-widget'),
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'ekit_client_logo_seperator_bg_color',
                'label' => esc_html__('Separator Color', 'sf-widget'),
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .elementskit-clients-slider .elementskit-client-slider-item.log-separator:after',
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'ekit_client_logo_seperator_color_hover_tab',
            [
                'label' => esc_html__('Hover', 'sf-widget'),
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'ekit_client_logo_seperator_bg_color_hover',
                'label' => esc_html__('Separator Color', 'sf-widget'),
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .elementskit-clients-slider:hover .elementskit-client-slider-item.log-separator:after',
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();


        $this->start_controls_section(
            'section_slide_inner_style',
            [
                'label' => esc_html__('Slide Inner Box', 'my-elementor-widgets'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'slide_inner_background',
                'label' => esc_html__('Background', 'my-elementor-widgets'),
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .swiper-slide-inner',
                'fields_options' => [
                    'background' => [
                        'label' => esc_html__('Background Type', 'my-elementor-widgets'),
                    ],
                    'color' => [
                        'label' => esc_html__('Color', 'my-elementor-widgets'),
                    ],
                    'gradient_type' => [
                        'label' => esc_html__('Gradient Type', 'my-elementor-widgets'),
                    ],
                    'image' => [
                        'label' => esc_html__('Image', 'my-elementor-widgets'),
                    ],
                ],
            ]
        );

        $this->add_responsive_control(
            'slide_inner_bg_position',
            [
                'label' => esc_html__('Position', 'my-elementor-widgets'),
                'type' => Controls_Manager::SELECT,
                'default' => '',
                'options' => [
                    '' => esc_html__('Default', 'my-elementor-widgets'),
                    'top left' => esc_html__('Top Left', 'my-elementor-widgets'),
                    'top center' => esc_html__('Top Center', 'my-elementor-widgets'),
                    'top right' => esc_html__('Top Right', 'my-elementor-widgets'),
                    'center left' => esc_html__('Center Left', 'my-elementor-widgets'),
                    'center center' => esc_html__('Center Center', 'my-elementor-widgets'),
                    'center right' => esc_html__('Center Right', 'my-elementor-widgets'),
                    'bottom left' => esc_html__('Bottom Left', 'my-elementor-widgets'),
                    'bottom center' => esc_html__('Bottom Center', 'my-elementor-widgets'),
                    'bottom right' => esc_html__('Bottom Right', 'my-elementor-widgets'),
                ],
                'selectors' => [
                    '{{WRAPPER}} .swiper-slide-inner' => 'background-position: {{VALUE}};',
                ],
                'condition' => [
                    'slide_inner_background_background' => ['classic'],
                    'slide_inner_background_image[url]' => '',
                ],
            ]
        );

        $this->add_responsive_control(
            'slide_inner_bg_repeat',
            [
                'label' => esc_html__('Repeat', 'my-elementor-widgets'),
                'type' => Controls_Manager::SELECT,
                'default' => '',
                'options' => [
                    '' => esc_html__('Default', 'my-elementor-widgets'),
                    'no-repeat' => esc_html__('No-repeat', 'my-elementor-widgets'),
                    'repeat' => esc_html__('Repeat', 'my-elementor-widgets'),
                    'repeat-x' => esc_html__('Repeat-x', 'my-elementor-widgets'),
                    'repeat-y' => esc_html__('Repeat-y', 'my-elementor-widgets'),
                ],
                'selectors' => [
                    '{{WRAPPER}} .swiper-slide-inner' => 'background-repeat: {{VALUE}};',
                ],
                'condition' => [
                    'slide_inner_background_background' => ['classic'],
                    'slide_inner_background_image[url]' => '',
                ],
            ]
        );

        $this->add_responsive_control(
            'slide_inner_bg_size',
            [
                'label' => esc_html__('Size', 'my-elementor-widgets'),
                'type' => Controls_Manager::SELECT,
                'default' => '',
                'options' => [
                    '' => esc_html__('Default', 'my-elementor-widgets'),
                    'auto' => esc_html__('Auto', 'my-elementor-widgets'),
                    'cover' => esc_html__('Cover', 'my-elementor-widgets'),
                    'contain' => esc_html__('Contain', 'my-elementor-widgets'),
                ],
                'selectors' => [
                    '{{WRAPPER}} .swiper-slide-inner' => 'background-size: {{VALUE}};',
                ],
                'condition' => [
                    'slide_inner_background_background' => ['classic'],
                    'slide_inner_background_image[url]' => '',
                ],
            ]
        );

        $this->add_responsive_control(
            'slide_inner_width',
            [
                'label' => esc_html__('Width', 'my-elementor-widgets'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => ['min' => 50, 'max' => 1000],
                    '%' => ['min' => 10, 'max' => 100],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 155,
                ],
                'selectors' => [
                    '{{WRAPPER}} .swiper-slide' => 'min-width: {{SIZE}}{{UNIT}} !important;',
                ],
            ]
        );

        $this->add_responsive_control(
            'slide_inner_height',
            [
                'label' => esc_html__('Height', 'my-elementor-widgets'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'vh'],
                'range' => [
                    'px' => ['min' => 50, 'max' => 500],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 80,
                ],
                'selectors' => [
                    '{{WRAPPER}} .swiper-slide-inner' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'use_gradient_border',
            [
                'label' => esc_html__('Use Gradient Border Color', 'sf-widget'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'sf-widget'),
                'label_off' => esc_html__('No', 'sf-widget'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_responsive_control(
            'border_width',
            [
                'label' => esc_html__('Border Width', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 10,
                    ],
                ],
                'default' => [
                    'size' => 2,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .swiper-slide-inner' => 'border-width: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'use_gradient_border!' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'border_style',
            [
                'label' => esc_html__('Border Style', 'sf-widget'),
                'type' => Controls_Manager::SELECT,
                'default' => 'none',
                'options' => [
                    'solid' => esc_html__('Solid', 'sf-widget'),
                    'dashed' => esc_html__('Dashed', 'sf-widget'),
                    'dotted' => esc_html__('Dotted', 'sf-widget'),
                    'double' => esc_html__('Double', 'sf-widget'),
                    'none' => esc_html__('None', 'sf-widget'),
                ],
                'selectors' => [
                    '{{WRAPPER}} .swiper-slide-inner' => 'border-style: {{VALUE}};',
                ],
                'condition' => [
                    'use_gradient_border!' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'border_color',
            [
                'label' => esc_html__('Border Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .swiper-slide-inner' => 'border-color: {{VALUE}};',
                ],
                'condition' => [
                    'use_gradient_border!' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'gradient_color_1',
            [
                'label' => __('Gradient Border Color 1', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .swiper-slide-inner' => '--grad-color-1: {{VALUE}};',
                ],
                'condition' => [
                    'use_gradient_border' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'gradient_color_2',
            [
                'label' => __('Gradient Border Color 2', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .swiper-slide-inner' => '--grad-color-2: {{VALUE}};',
                ],
                'condition' => [
                    'use_gradient_border' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'gradient_color_3',
            [
                'label' => __('Gradient Border Color 3', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .swiper-slide-inner' => '--grad-color-3: {{VALUE}};',
                ],
                'condition' => [
                    'use_gradient_border' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'gradient_direction',
            [
                'label' => __('Gradient Direction', 'sf-widget'),
                'type' => Controls_Manager::SELECT,
                'default' => 'to top right',
                'options' => [
                    'to left' => 'Left → Right',
                    'to right' => 'Right → Left',
                    'to top' => 'Bottom → Top',
                    'to bottom' => 'Top → Bottom',
                    'to top left' => 'Bottom-Right → Top-Left',
                    'to top right' => 'Bottom-Left → Top-Right',
                    'to bottom left' => 'Top-Right → Bottom-Left',
                    'to bottom right' => 'Top-Left → Bottom-Right',
                ],
                'selectors' => [
                    '{{WRAPPER}} .swiper-slide-inner' => '--grad-direction: {{VALUE}};',
                ],
                'condition' => [
                    'use_gradient_border' => 'yes',
                ],
            ]
        );

        $this->add_responsive_control(
            'slide_inner_border_radius',
            [
                'label' => esc_html__('Border Radius', 'my-elementor-widgets'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .swiper-slide-inner' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );


        $this->end_controls_tabs();

        $this->end_controls_section();


        $this->insert_pro_message();
    }

    protected function render_raw()
    {
        $settings = $this->get_settings_for_display();
        $logos = $settings['ekit_client_logo_repiter'];

        // Direction
        $slider_direction = $settings['ekit_client_logo_slider_direction'] ?? (is_rtl() ? 'rtl' : 'ltr');

        // Swiper config
        $config = [
            'rtl' => ($slider_direction === 'rtl'),
            'direction' => 'horizontal',
            'arrows' => !empty($settings['ekit_client_logo_show_arrow']),
            'dots' => !empty($settings['ekit_client_logo_show_dot']),
            'autoplay' => !empty($settings['ekit_client_logo_autoplay']) ? [
                'delay' => 0,
                'disableOnInteraction' => false
            ] : false,
            'speed' => $settings['ekit_client_logo_speed'] ?? 3000,
            'slidesPerView' => $settings['ekit_client_logo_slidetosho']['size'] ?? 4,
            'slidesPerGroup' => $settings['ekit_client_logo_slidesToScroll']['size'] ?? 1,
            'pauseOnHover' => !empty($settings['ekit_client_logo_pause_on_hover']),
            'loop' => (!empty($settings['ekit_client_logo_loop']) && $settings['ekit_client_logo_loop'] === 'yes' && (!empty($settings['ekit_client_logo_rows']) && $settings['ekit_client_logo_rows'] == 1)),
            'breakpoints' => [
                320 => [
                    'slidesPerView' => $settings['ekit_client_logo_slidetosho_mobile']['size'] ?? 1,
                    'slidesPerGroup' => $settings['ekit_client_logo_slidesToScroll_mobile']['size'] ?? 1,
                    'spaceBetween' => $settings['ekit_client_logo_left_right_spacing_mobile']['size'] ?? 10,
                ],
                768 => [
                    'slidesPerView' => $settings['ekit_client_logo_slidetosho_tablet']['size'] ?? 2,
                    'slidesPerGroup' => $settings['ekit_client_logo_slidesToScroll_tablet']['size'] ?? 1,
                    'spaceBetween' => $settings['ekit_client_logo_left_right_spacing_tablet']['size'] ?? 10,
                ],
                1024 => [
                    'slidesPerView' => $settings['ekit_client_logo_slidetosho']['size'] ?? 2,
                    'slidesPerGroup' => $settings['ekit_client_logo_slidesToScroll']['size'] ?? 1,
                    'spaceBetween' => $settings['ekit_client_logo_left_right_spacing']['size'] ?? 15,
                ]
            ],
        ];

        if (!empty($settings['ekit_client_logo_rows']) && $settings['ekit_client_logo_rows'] > 1) {
            $config['grid'] = [
                'fill' => 'row',
                'rows' => (int) $settings['ekit_client_logo_rows']
            ];
        }

        // Wrapper
        $this->add_render_attribute('wrapper', [
            'dir' => $slider_direction,
            'class' => [
                'elementskit-clients-slider',
                !empty($settings['ekit_client_logo_show_dot']) ? 'slider-dotted' : '',
                $settings['ekit_client_logo_arrow_pos'] ?? '',
                $settings['ekit_client_logo_client_logo_dot_style'] ?? '',
                $settings['ekit_client_logo_hover_animation_driction'] ?? '',
                $settings['ekit_client_logo_slide_style'] ?? '',
            ],
            'data-config' => wp_json_encode($config),
        ]);

        $separator_enable = ($settings['ekit_client_logo_separator'] ?? '') === 'yes' ? 'log-separator' : '';

        // Render attribute for .swiper-slide-inner
        $this->add_render_attribute(
            'slide_inner',
            [
                'class' => 'swiper-slide-inner',
                'data-gradient-border' => esc_attr($settings['use_gradient_border']),
            ]
        );

        // $this->add_render_attribute('slide_inner', 'class', 'swiper-slide-inner'); ?>
        <div <?php echo $this->get_render_attribute_string('wrapper'); ?>>
            <div class="<?php echo esc_attr(\ElementsKit_Lite\Utils::swiper_class() . ' sf-swiper'); ?>">
                <div class="swiper-wrapper">
                    <?php foreach ($logos as $index => $logo): ?>
                        <?php
                        $this->add_render_attribute("button-{$index}", [
                            'href' => $logo['ekit_client_logo_link']['url'] ?? '#',
                            'target' => !empty($logo['ekit_client_logo_link']['is_external']) ? '_blank' : '',
                            'rel' => !empty($logo['ekit_client_logo_link']['nofollow']) ? 'nofollow' : '',
                        ]);
                        ?>
                        <div class="elementskit-client-slider-item swiper-slide<?php echo esc_attr($separator_enable); ?>">
                            <div <?php echo $this->get_render_attribute_string('slide_inner'); ?>>
                                <div class="single-client image-switcher"
                                    title="<?php echo esc_attr($logo['ekit_client_logo_list_title'] ?? ''); ?>">
                                    <?php if ($logo['ekit_client_logo_enable_link'] === 'yes'): ?>
                                        <a <?php $this->print_render_attribute_string("button-{$index}"); ?>>
                                            <span class="content-image">
                                                <?php
                                                echo wp_kses(
                                                    \Elementskit_Lite\Utils::get_attachment_image_html($logo, 'ekit_client_logo_image_normal', 'full', [
                                                        'class' => $logo['ekit_client_logo_enable_hover_logo'] === 'yes' ? 'main-image' : ''
                                                    ]),
                                                    \ElementsKit_Lite\Utils::get_kses_array()
                                                );

                                                if ($logo['ekit_client_logo_enable_hover_logo'] === 'yes') {
                                                    echo wp_kses(
                                                        \Elementskit_Lite\Utils::get_attachment_image_html($logo, 'ekit_client_logo_image_hover', 'full', [
                                                            'class' => 'hover-image'
                                                        ]),
                                                        \ElementsKit_Lite\Utils::get_kses_array()
                                                    );
                                                }
                                                ?>
                                            </span>
                                        </a>
                                    <?php else: ?>
                                        <div class="content-image">
                                            <?php
                                            echo wp_kses(
                                                \Elementskit_Lite\Utils::get_attachment_image_html($logo, 'ekit_client_logo_image_normal', 'full', [
                                                    'class' => $logo['ekit_client_logo_enable_hover_logo'] === 'yes' ? 'main-image' : ''
                                                ]),
                                                \ElementsKit_Lite\Utils::get_kses_array()
                                            );

                                            if ($logo['ekit_client_logo_enable_hover_logo'] === 'yes') {
                                                echo wp_kses(
                                                    \Elementskit_Lite\Utils::get_attachment_image_html($logo, 'ekit_client_logo_image_hover', 'full', [
                                                        'class' => 'hover-image'
                                                    ]),
                                                    \ElementsKit_Lite\Utils::get_kses_array()
                                                );
                                            }
                                            ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <?php if (!empty($settings['ekit_client_logo_show_dot'])): ?>
                    <div class="swiper-pagination"></div>
                <?php endif; ?>

                <?php if (!empty($settings['ekit_client_logo_show_arrow'])): ?>
                    <div class="swiper-navigation-button swiper-button-prev">
                        <?php \Elementor\Icons_Manager::render_icon($settings['ekit_client_logo_left_arrow_icon'], ['aria-hidden' => 'true']); ?>
                    </div>
                    <div class="swiper-navigation-button swiper-button-next">
                        <?php \Elementor\Icons_Manager::render_icon($settings['ekit_client_logo_right_arrow_icon'], ['aria-hidden' => 'true']); ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <?php
    }

}
