<?php
namespace SFWPStudio\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Icons_Manager;
use Elementor\Control_Media;

if ( ! defined( 'ABSPATH' ) ) exit;

class Heading extends Widget_Base {
	use \ElementsKit_Lite\Widgets\Widget_Notice;
	use \SFWPStudio\Core\Helpers\Traits\ButtonTrait;
	use \SFWPStudio\Core\Helpers\Traits\ListTrait;
	use \SFWPStudio\Core\Helpers\Traits\FancyAnimatedTextTrait;
	
	public function get_name() {
        return 'sf-heading';
    }
 
    public function get_title() {
        return esc_html__( 'SF Heading', 'sf-widget' );
    }
 
    public function get_icon() {
        return 'sync-widget-icon eicon-tabs';
    }

	public function get_keywords()
    {
        return ['sf' ,'heading', 'Title'];
    }

	public function get_script_depends() {
		return ['heading'];
	}

	//SFWP CODE STARTS
    public function get_categories()
    {
        return ['syncfusion-widgets'];
    }

    public function is_dynamic_content(): bool
    {
        return false;
    }
    //SFWP CODE ENDS
	

    protected function register_controls() {

		$this->start_controls_section(
			'ekit_heading_section_title',
			array(
				'label' => esc_html__( 'SF Title', 'sf-widget' ),
			)
		);

		$this->add_control(
			'ekit_heading_title', [
				'label'			 => esc_html__( 'Heading Title', 'sf-widget' ),
				'type'			 => Controls_Manager::TEXT,
				'dynamic'		 => [
					'active' => true,
				],
				'description'	 => esc_html__( '"Focused Title" Settings will be worked, If you use this {{something}} format', 'sf-widget' ),
				'label_block'	 => true,
				'placeholder'	 => esc_html__( 'Grow your {{report}}', 'sf-widget' ),
				'default'		 => esc_html__( 'Grow your {{report}}', 'sf-widget' ),
			]
		);

		$this->add_control( 
			'ekit_heading_link', [
			'label'			 => esc_html__( 'Link', 'sf-widget' ),
			'type'			 => Controls_Manager::URL,
			'dynamic'		 => [
				'active' => true,
			],
			'label_block' => true,
			'placeholder' => esc_html__( 'Paste URL or type', 'sf-widget' ),
			'autocomplete' => false,
			'options' => [ 'is_external', 'nofollow', 'custom_attributes' ],
        ]);

		$this->add_control(
			'ekit_heading_title_tag',
			[
				'label' => esc_html__( 'Title HTML Tag', 'sf-widget' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
					'span' => 'span',
					'p' => 'p',
				],
				'default' => 'h1',
			]
		);

		$this->add_control( 
			'show_title_border', [
			'label' => esc_html__( 'Show Border', 'sf-widget' ),
			'type' => Controls_Manager::SWITCHER,
			'default' => 'no',
        ]);
        
        $this->add_control(
			'title_border_position',
			[
				'label' => esc_html__( 'Border Position', 'sf-widget' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'start',
				'options' => [
					'start' => esc_html__( 'Start', 'sf-widget' ),
					'end' => esc_html__( 'End', 'sf-widget' ),
				],
				'condition' => [
					'show_title_border' => 'yes'
				]
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'ekit_heading_section_subtitle',
			array(
				'label' => esc_html__( 'SF Subtitle', 'sf-widget' ),
			)
		);

		$this->add_control(
			'ekit_heading_sub_title_show',
			[
				'label' => esc_html__( 'Show Sub Title', 'sf-widget' ),
				'type' => Controls_Manager::SWITCHER,
				'default' => 'no',
			]
		);

		$this->add_control(
			'ekit_heading_sub_title_border',
			[
				'label' => esc_html__( 'Border Sub Title', 'sf-widget' ),
				'type' => Controls_Manager::SWITCHER,
				'default' => 'no',
				'condition' => [
                    'ekit_heading_sub_title_show' => 'yes',
                    //'ekit_heading_sub_title_outline' => '!yes'
				]
			]
		);

		$this->add_control(
			'ekit_heading_sub_title_add_icon',
			[
				'label' => esc_html__( 'Add Icon?', 'sf-widget' ),
				'type' => Controls_Manager::SWITCHER,
				'default' => 'no',
				'condition' => [
                    'ekit_heading_sub_title_show' => 'yes',
				]
			]
		);

		$this->add_control(
            'ekit_heading_sub_title_icon',
            [
                'label' => __( 'Select Icon', 'sf-widget' ),
                'type' => Controls_Manager::ICONS,
                'default' => [
                    'value' => 'icon icon-home',
                    'library' => 'elementskit',
                ],
                'condition' => [
                    'ekit_heading_sub_title_show' => 'yes',
                    'ekit_heading_sub_title_add_icon' => 'yes',
                ],
            ]
        );

		$this->add_responsive_control(
			'ekit_heading_sub_title_icon_position',
			[
				'label' => esc_html_x('Icon Position', 'Border Control', 'sf-widget' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'before'   => esc_html__('Before', 'sf-widget' ),
					'after'  => esc_html_x('After', 'Border Control', 'sf-widget' ),
				],
				'default' => 'before',
				'condition' => [
					'ekit_heading_sub_title_show' => 'yes',
					'ekit_heading_sub_title_add_icon' => 'yes'
				],
			]
		);

		$this->add_control(
			'ekit_heading_sub_title_outline',
			[
				'label' => esc_html__( 'Show Outline', 'sf-widget' ),
				'type' => Controls_Manager::SWITCHER,
				'default' => 'yes',
				// 'prefix_class' => 'sf-heading-outline-',
				'condition' => [
					'ekit_heading_sub_title_show' => 'yes',
					'ekit_heading_sub_title_border!' => 'yes'
				]
			]
		);

		$this->add_control(
			'ekit_heading_sub_title', [
				'label'			 =>esc_html__( 'Heading Sub Title', 'sf-widget' ),
				'type'			 => Controls_Manager::TEXT,
				'dynamic'		 => [
					'active' => true,
				],
				'label_block'	 => true,
				'placeholder'	 =>esc_html__( 'TIME HAS CHANGED', 'sf-widget' ),
				'default'		 =>esc_html__( 'TIME HAS CHANGED', 'sf-widget' ),
				'condition' => [
					'ekit_heading_sub_title_show' => 'yes'
				],

			]
		);
		$this->add_control(
			'ekit_heading_sub_title_position',
			[
				'label' => esc_html__( 'Sub Title Position', 'sf-widget' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'before_title',
				'options' => [
					'before_title' => esc_html__( 'Before Title', 'sf-widget' ),
					'after_title' => esc_html__( 'After Title', 'sf-widget' ),
				],
				'condition' => [
					'ekit_heading_sub_title_show' => 'yes'
				]
			]
		);

		$this->add_control(
			'ekit_heading_sub_title_tag',
			[
				'label' => esc_html__( 'Sub Title HTML Tag', 'sf-widget' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
					'span' => 'span',
					'p' => 'p',
				],
				'default' => 'h6',
				'condition' => [
					'ekit_heading_sub_title_show' => 'yes'
				]
			]
		);
		$this->end_controls_section();

		$this->fancy_text_register_controls();

		//Title Description
        $this->start_controls_section(
            'ekit_heading_section_extra_title',
            array(
                'label' => esc_html__( 'SF Description', 'sf-widget' ),
            )
        );
 
        $this->add_control(
            'ekit_heading_section_extra_title_show',
            [
                'label' => esc_html__( 'Show Description', 'sf-widget' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'no',
            ]
        );
       
        $this->add_control(
            'ekit_heading_extra_title',
            [
                'label' => esc_html__( 'Heading Description', 'sf-widget' ),
                'type' => Controls_Manager::WYSIWYG,
                'dynamic' => [
                    'active' => true,
                ],
                'rows' => 10,
                'label_block'    => true,
                'default'    =>esc_html__( 'A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradise ', 'sf-widget' ),
                'placeholder'    =>esc_html__( 'Title Description', 'sf-widget' ),
                'condition' => [
                    'ekit_heading_section_extra_title_show' => 'yes',
                ],
 
            ]
        );
       
 
        $this->add_responsive_control( 
			'desciption_width', [
            'label' => __( 'Maximum Width', 'sf-widget' ),
            'type' => Controls_Manager::SLIDER,
            'size_units' => [ 'px', 'em', '%' ],
            'selectors' => [
                '{{WRAPPER}} .ekit-heading__description' => 'max-width: {{SIZE}}{{UNIT}};'
            ],
            'condition' => [
                'ekit_heading_section_extra_title_show' => 'yes',
            ]
        ]);
 
        $this->end_controls_section();

		
 
		$this->start_controls_section(
			'ekit_heading_section_seperator',
			array(
				'label' => esc_html__( 'SF Separator', 'sf-widget' ),
			)
		);


		$this->add_control(
			'ekit_heading_show_seperator', [
				'label'			 =>esc_html__( 'Show Separator', 'sf-widget' ),
				'type'			 => Controls_Manager::SWITCHER,
				'default' => 'No',
				'label_on' =>esc_html__( 'Yes', 'sf-widget' ),
				'label_off' =>esc_html__( 'No', 'sf-widget' ),
			]

		);
		$this->add_control(
			'ekit_heading_seperator_style',
			[
				'label' => esc_html__( 'Separator Style', 'sf-widget' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'elementskit-border-divider ekit-dotted' => esc_html__( 'Dotted', 'sf-widget' ),
					'elementskit-border-divider elementskit-style-long' => esc_html__( 'Solid', 'sf-widget' ),
					'elementskit-border-star' => esc_html__( 'Solid with star', 'sf-widget' ),
					'elementskit-border-star elementskit-bullet' => esc_html__( 'Solid with bullet', 'sf-widget' ),
					'ekit_border_custom' => esc_html__( 'Custom', 'sf-widget' ),
				],
				'default' => 'elementskit-border-divider ekit-dotted',
				'condition' => [
					'ekit_heading_show_seperator' => 'yes',
				],
			]
		);

		$this->add_control(
			'ekit_heading_seperator_position',
			[
				'label' => esc_html__( 'Separator Position', 'sf-widget' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'top' => esc_html__( 'Top', 'sf-widget' ),
					'before' => esc_html__( 'Before Title', 'sf-widget' ),
					'after' => esc_html__( 'After Title', 'sf-widget' ),
					'bottom' => esc_html__( 'Bottom', 'sf-widget' ),
				],
				'default' => 'after',
				'condition' => [
					'ekit_heading_show_seperator' => 'yes',
				],
			]
		);

		$this->add_control(
			'ekit_heading_seperator_image',
			[
				'label' => esc_html__( 'Choose Image', 'sf-widget' ),
				'type' => Controls_Manager::MEDIA,
				'dynamic' => [
					'active' => true,
				],
				'default' => [
					'url' => "",
					'id'    => -1
				],
				'condition' => [
					'ekit_heading_show_seperator' => 'yes',
					'ekit_heading_seperator_style' => 'ekit_border_custom',
				],

			]
		);

		$this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'ekit_heading_seperator_image_size',
				'default' => 'large',
				'condition' => [
					'ekit_heading_show_seperator' => 'yes',
					'ekit_heading_seperator_style' => 'ekit_border_custom',
				],
            ]
        );

		$this->end_controls_section();
		
		$this->start_controls_section(
			'ekit_heading_section_general',
			array(
				'label' => esc_html__( 'General', 'sf-widget' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_responsive_control(
			'ekit_heading_title_align', [
				'label'			 =>esc_html__( 'Alignment', 'sf-widget' ),
				'type'			 => Controls_Manager::CHOOSE,
				'options'		 => [
					'start'		 => [
						'title'	 =>esc_html__( 'Left', 'sf-widget' ),
						'icon'	 => 'eicon-text-align-left',
					],
					'center'	 => [
						'title'	 =>esc_html__( 'Center', 'sf-widget' ),
						'icon'	 => 'eicon-text-align-center',
					],
					'end'		 => [
						'title'	 =>esc_html__( 'Right', 'sf-widget' ),
						'icon'	 => 'eicon-text-align-right',
					],
				],
				'default'		 => 'start',
				'selectors'	 => [
					'{{WRAPPER}} .ekit-heading.sf-heading' => 'align-items: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();


		//Title Style Section
		$this->start_controls_section(
			'ekit_heading_section_title_style', [
				'label'	 => esc_html__( 'SF Title', 'sf-widget' ),
				'tab'	 => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'ekit_heading_title_color', [
				'label'		 =>esc_html__( 'Color', 'sf-widget' ),
				'type'		 => Controls_Manager::COLOR,
				'selectors'	 => [
					'{{WRAPPER}} .elementskit-section-title-wraper .elementskit-section-title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'ekit_heading_title_color_hover', [
				'label'		 =>esc_html__( 'Hover Color', 'sf-widget' ),
				'type'		 => Controls_Manager::COLOR,
				'selectors'	 => [
					'{{WRAPPER}} .elementskit-section-title-wraper .elementskit-section-title:hover' => 'color: {{VALUE}};',
				],
			]
		);

        $this->add_group_control(
            Group_Control_Text_Shadow::get_type(),
            [
                'name' => 'ekit_heading_title_shadow',
                'selector' => '{{WRAPPER}} .elementskit-section-title-wraper .elementskit-section-title',

            ]
        );

		$this->add_responsive_control(
			'ekit_heading_title_margin',
			array(
				'label'      => esc_html__( 'Margin', 'sf-widget' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .elementskit-section-title-wraper .elementskit-section-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(), [
			'name'		 => 'ekit_heading_title_typography',
			'selector'	 => '{{WRAPPER}} .elementskit-section-title-wraper .elementskit-section-title',
			]
		);

		$this->add_control( 
			'title_left_border_heading', [
			'label' => esc_html__( 'Border', 'sf-widget' ),
			'type' => Controls_Manager::HEADING,
			'separator' => 'before',
			'condition' => [
				'show_title_border' => 'yes'	
			]
		]);

		$this->add_control( 
			'title_left_border_width', [
			'label' => __( 'Border Width', 'sf-widget' ),
			'type' => Controls_Manager::SLIDER,
			'size_units' => [ 'px', 'em' ],
			'range' => [
				'px' => [
					'min' => 0,
					'max' => 32,
					'step' => 1,
				]
			],
			'default' => [ 'unit' => 'px', 'size' => 5 ],
			'selectors' => [
                '{{WRAPPER}} .ekit-heading__title-has-border::before' => 
                    'width: {{SIZE}}{{UNIT}};'
			],
			'condition' => [
				'show_title_border' => 'yes'	
			]
		]);

		$this->add_control( 
			'title_left_border_height', [
			'label' => __( 'Border Height', 'sf-widget' ),
			'type' => Controls_Manager::SLIDER,
			'size_units' => [ '%', 'px', 'em' ],
			'default' => [ 'unit' => '%', 'size' => 100 ],
			'selectors' => [
				'{{WRAPPER}} .ekit-heading__title-has-border::before' => 
					'height: {{SIZE}}{{UNIT}};'
			],
			'condition' => [
				'show_title_border' => 'yes'	
			]
        ]);

		$this->add_control( 
			'title_border_vertical_position', [
			'label' => __( 'Vertical Position', 'sf-widget' ),
			'type' => Controls_Manager::SLIDER,
			'size_units' => [ '%', 'px', 'em' ],
			'default' => [ 'unit' => 'px', 'size' => 0 ],
			'selectors' => [
				'{{WRAPPER}} .ekit-heading__title-has-border::before' => 
					'top: {{SIZE}}{{UNIT}};'
			],
			'condition' => [
				'show_title_border' => 'yes'	
			]
		]);

		$this->add_control( 
			'title_left_border_gap', [
			'label' => __( 'Right Gap', 'sf-widget' ),
			'type' => Controls_Manager::SLIDER,
			'size_units' => [ 'px', 'em' ],
			'range' => [
				'px' => [
					'min' => 0,
					'max' => 128,
					'step' => 1,
				]
			],
			'default' => [ 'unit' => 'px', 'size' => 30 ],
			'selectors' => [
				'{{WRAPPER}} .ekit-heading__title-has-border' => 
					'padding-left: {{SIZE}}{{UNIT}};',
				'{{WRAPPER}} .ekit-heading__title-has-border ~ *' => 
                    'padding-left: {{SIZE}}{{UNIT}};',
                '{{WRAPPER}} .ekit-heading__subtitle-has-border' => 
                    'margin-left: {{SIZE}}{{UNIT}};'
			],
			'condition' => [
                'show_title_border' => 'yes',
				'title_border_position' => 'start',
                'ekit_heading_title_align!' => 'text_center'
			]
        ]);

		$this->add_control( 
			'title_left_border_gap2', [
			'label' => __( 'Left Gap', 'sf-widget' ),
			'type' => Controls_Manager::SLIDER,
			'size_units' => [ 'px', 'em' ],
			'range' => [
				'px' => [
					'min' => 0,
					'max' => 128,
					'step' => 1,
				]
			],
			'default' => [ 'unit' => 'px', 'size' => 30 ],
			'selectors' => [
				'{{WRAPPER}} .ekit-heading__title-has-border' => 
					'padding-right: {{SIZE}}{{UNIT}};',
				'{{WRAPPER}} .ekit-heading__title-has-border ~ *' => 
					'padding-right: {{SIZE}}{{UNIT}};',
				'{{WRAPPER}} .ekit-heading__subtitle-has-border' => 
					'margin-right: {{SIZE}}{{UNIT}};'
			],
			'condition' => [
				'show_title_border' => 'yes',
                'title_border_position' => 'end',
                'ekit_heading_title_align!' => 'text_center'
			]
		]);

		$this->add_group_control(Group_Control_Background::get_type(),
			[
				'name' => 'title_left_border_color',
				'label' => __( 'Background', 'sf-widget' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .ekit-heading__title-has-border::before',
				'types' => ['gradient'],
				'condition' => [
					'show_title_border' => 'yes'	
				]
			]
		);

		$this->end_controls_section();

		//Focused Title Style Section
		$this->start_controls_section(
			'ekit_heading_section_focused_title_style', [
				'label'	 => esc_html__( 'Focused Title', 'sf-widget' ),
				'tab'	 => Controls_Manager::TAB_STYLE,
			]
		);

		// Dropdown Control for Background Type
		$this->add_control(
			'ekit_heading_focused_title_color_type',
			[
				'label'   => esc_html__( 'Text Color Type', 'sf-widget' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'gradient',
				'options' => [
					'color'    => esc_html__( 'Solid Color', 'sf-widget' ),
					'gradient' => esc_html__( 'Gradient', 'sf-widget' ),
				],
			]
		);
		$this->add_responsive_control(
			'ekit_heading_focused_title_color', [
				'label'     => esc_html__( 'Color', 'sf-widget' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .elementskit-section-title-wraper .elementskit-section-title > span' => 'color:{{VALUE}} ;',
				],
				'default' => '',
				'condition' => [
					'ekit_heading_focused_title_color_type' => 'color',
				]
			]
		);

		$this->add_responsive_control(
			'ekit_heading_focused_title_color_hover', [
				'label'		 =>esc_html__( 'Hover Color', 'sf-widget' ),
				'type'		 => Controls_Manager::COLOR,
				'selectors'	 => [
					'{{WRAPPER}} .elementskit-section-title-wraper .elementskit-section-title:hover > span' => 'color: {{VALUE}};',
				],
				'default' => '',
				'condition' => [
					'ekit_heading_focused_title_color_type' => 'color',
				]
			]
		);

        $this->add_group_control(
            Group_Control_Background::get_type(),
            array(
				'name'     => 'ekit_heading_title_secondary_bg',
				'label'		 => esc_html__( 'Focused Title Secondary BG', 'sf-widget' ),
				'selector' => '{{WRAPPER}} .elementskit-section-title-wraper .elementskit-section-title.text_fill > span',
				'fields_options' => [
                'background' => ['default' => 'gradient'],
                'color' => [
                    'default' => '',
					'condition' => ['background' => 'gradient']
                ],
                'color_b' => [
                    'default' => '',
                ],
                'gradient_type' => [
                    'default' => 'linear',
                ],
                'gradient_angle' => [
                    'default' => [
                        'unit' => 'deg',
                        'size' => 90,
                    ],
                ],
            ],
				'condition' => [
					'ekit_heading_focused_title_color_type' => 'gradient',
				],
            )
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            array(
				'name'     => 'ekit_heading_focused_title_secondary_bg',
				'label'		 => esc_html__( 'Focused Title Secondary BG', 'sf-widget' ),
				'selector' => '{{WRAPPER}} .elementskit-section-title-wraper .elementskit-section-title > span',
				'condition' => [
					'ekit_heading_focused_title_color_type!' => 'gradient'
				],
            )
		);

		$this->add_control(
			'ekit_heading_focused_title_secondary_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'sf-widget' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .elementskit-section-title-wraper .elementskit-section-title > span' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'ekit_heading_focused_title_color_type!' => 'gradient'
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(), [
			'name'		 => 'ekit_heading_focused_title_typography',
			'separator' => 'before',
			'selector'	 => '{{WRAPPER}} .elementskit-section-title-wraper .elementskit-section-title span:last-child, {{WRAPPER}} .elementskit-section-title-wraper .elementskit-section-title > span',
			]
		);

		$this->add_responsive_control(
			'ekit_heading_title_text_decoration_color', [
				'label'		 =>esc_html__( 'Text decoration color', 'sf-widget' ),
				'type'		 => Controls_Manager::COLOR,
				'selectors'	 => [
					'{{WRAPPER}} .elementskit-section-title-wraper .elementskit-section-title span:last-child' => 'text-decoration-color: {{VALUE}};',
					'{{WRAPPER}} .elementskit-section-title-wraper .elementskit-section-title > span' => 'text-decoration-color: {{VALUE}};',
				],
				'condition' => [
            'ekit_heading_focused_title_typography_text_decoration!' => [ 'none', '' ], // '' represents default
        ],
			]
		);

		$this->add_group_control(
            Group_Control_Text_Shadow::get_type(),
            [
                'name' => 'ekit_heading_focus_title_shadow',
                'selector' => '{{WRAPPER}} .elementskit-section-title-wraper .elementskit-section-title > span',

            ]
        );

		$this->add_responsive_control(
			'ekit_heading_focused_title_secondary_spacing',
			[
				'label' => esc_html__( 'Padding', 'sf-widget' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .elementskit-section-title-wraper .elementskit-section-title > span' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		//Sub title Style Section
		$this->start_controls_section(
			'ekit_heading_section_sub_title_style', [
				'label'	 => esc_html__( 'SF Subtitle', 'sf-widget' ),
				'tab'	 => Controls_Manager::TAB_STYLE,
				'condition' => [
					'ekit_heading_sub_title_show' => 'yes',
					'ekit_heading_sub_title!' => ''
				]
			]
		);

		$this->add_control(
			'ekit_heading_use_sub_title_text_fill', [
				'label'			 =>esc_html__( 'Use text fill', 'sf-widget' ),
				'type'			 => Controls_Manager::SWITCHER,
				'default' => 'no',
				'label_on' =>esc_html__( 'Yes', 'sf-widget' ),
				'label_off' =>esc_html__( 'No', 'sf-widget' ),

			]
		);

        $this->add_group_control(
            Group_Control_Background::get_type(),
            array(
				'name'     => 'ekit_heading_sub_title_secondary_bg',
				'label'		 => esc_html__( 'Sub Title', 'sf-widget' ),
				'selector' => '{{WRAPPER}} .elementskit-section-title-wraper .elementskit-section-subtitle',
				'condition' => [
					'ekit_heading_use_sub_title_text_fill' => 'yes',
				],
            )
		);

		$this->add_responsive_control(
			'ekit_heading_sub_title_color', [
				'label'		 => esc_html__( 'Color', 'sf-widget' ),
				'type'		 => Controls_Manager::COLOR,
				'selectors'	 => [
					'{{WRAPPER}} .elementskit-section-title-wraper .elementskit-section-subtitle' => 'color: {{VALUE}};',
				],
				'condition' => [
					'ekit_heading_use_sub_title_text_fill!' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'ekit_heading_sub_title_bg_color', [
				'label'		 => esc_html__( 'Background Color', 'sf-widget' ),
				'type'		 => Controls_Manager::COLOR,
				'selectors'	 => [
					'{{WRAPPER}} .elementskit-section-title-wraper .elementskit-section-subtitle' => 'background-color: {{VALUE}};',
				],
				'condition' => [
					'ekit_heading_use_sub_title_text_fill!' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(), [
			'name'		 => 'ekit_heading_sub_title_typography',
			'selector'	 => '{{WRAPPER}} .elementskit-section-title-wraper .elementskit-section-subtitle',
			]
		);

		$this->add_responsive_control(
			'ekit_heading_sub_title_margin',
			[
				'label' => esc_html__( 'Margin', 'sf-widget' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'rem', '%' ],
				'selectors' => [
                    '{{WRAPPER}} .elementskit-section-title-wraper .sf_heading_subtitle' => 
                        'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control( 
			'ekit_heading_sub_title_padding', [
			'label' => esc_html__( 'Padding', 'sf-widget' ),
			'type' => Controls_Manager::DIMENSIONS,
			'size_units' => [ 'px', '%', 'em'],
			'selectors' => [
				'{{WRAPPER}} .elementskit-section-title-wraper .sf_heading_subtitle .elementskit-section-subtitle' => 
					'padding:{{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]);

		$this->add_control(
            'ekit_heading_sub_title_icon_settings',
            [
                'label' => esc_html__('Icon Settings', 'sf-widget' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
				'condition' => [
					'ekit_heading_sub_title_add_icon' => 'yes'
				],
            ]
        );

		$this->add_responsive_control(
			'ekit_heading_sub_title_icon_color',
			[
				'label' => esc_html__('Color', 'sf-widget' ),
				'type' => Controls_Manager::COLOR,
				'condition' => [
					'ekit_heading_use_sub_title_text_fill!' => 'yes',
					'ekit_heading_sub_title_add_icon' => 'yes',
				],
				'selectors' => [
					'{{WRAPPER}} .elementskit-section-title-wraper .sf_heading_subtitle .ekit-heading--subtitle :is(i, svg)' => 'color: {{VALUE}}; fill: {{VALUE}};',
				],
			]
		);

		$this->add_control(
            'ekit_subtitle_icon_gap',
            [
                'label' => __('Icon Gap', 'sf-widget' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    's' => [
                        'min' => 1,
                        // 'max' => 10,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementskit-section-title-wraper .sf_heading_subtitle .ekit-heading--subtitle' => 'gap: {{SIZE}}{{UNIT}};',
                ],
				'condition' => [
					'ekit_heading_sub_title_add_icon' => 'yes'
				],
            ]
        );

		$this->add_control(
            'ekit_subtitle_icon_size',
            [
                'label' => __('Icon Size', 'sf-widget' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', 'rem'],
                'range' => [
                    's' => [
                        'min' => 1,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementskit-section-title-wraper .sf_heading_subtitle .ekit-heading--subtitle :is(i, svg)' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
				'condition' => [
					'ekit_heading_sub_title_add_icon' => 'yes'
				],
            ]
        );

        $this->add_control(
            'ekit_heading_sub_title_border_heading_title_left',
            [
                'label' => esc_html__( 'Subtitle Border Left', 'sf-widget' ),
                'type' => Controls_Manager::HEADING,
                'condition' => [
                    'ekit_heading_sub_title_border' => 'yes',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            array(
				'name'     => 'ekit_heading_sub_title_border_color_left',
				'label'		 => esc_html__( 'Sub Title', 'sf-widget' ),
				'selector' => '{{WRAPPER}} .elementskit-section-subtitle.elementskit-style-border::before',
				'condition' => [
					'ekit_heading_sub_title_border' => 'yes',
				],
            )
		);

		
		$this->add_responsive_control(
			'ekit_heading_sub_title_border_left_width',
			[
				'label' => esc_html__( 'Width', 'sf-widget' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
						'step' => 1,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 40,
				],
				'selectors' => [
					'{{WRAPPER}} .elementskit-section-subtitle.elementskit-style-border::before' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'ekit_heading_sub_title_border' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'ekit_heading_sub_title_border_heading_title_right_margin',
			[
				'label' => __( 'Margin', 'sf-widget' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .elementskit-section-subtitle.elementskit-style-border::before' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'ekit_heading_sub_title_border' => 'yes',
				],
			]
		);

        $this->add_control(
            'ekit_heading_sub_title_border_heading_title_right',
            [
                'label' => esc_html__( 'Subtitle Border Right color', 'sf-widget' ),
                'type' => Controls_Manager::HEADING,
                'condition' => [
                    'ekit_heading_sub_title_border' => 'yes',
                ],
            ]
		);

        $this->add_group_control(
            Group_Control_Background::get_type(),
            array(
                'name'     => 'ekit_heading_sub_title_border_color_right',
                'label'		 => esc_html__( 'Sub Title', 'sf-widget' ),
                'selector' => '{{WRAPPER}} .elementskit-section-subtitle.elementskit-style-border::after',
                'condition' => [
                    'ekit_heading_sub_title_border' => 'yes',
                ],
            )
        );

		$this->add_responsive_control(
			'ekit_heading_sub_title_border_right_width',
			[
				'label' => esc_html__( 'Width', 'sf-widget' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
						'step' => 1,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 40,
				],
				'selectors' => [
					'{{WRAPPER}} .elementskit-section-subtitle.elementskit-style-border::after' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'ekit_heading_sub_title_border' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'ekit_heading_sub_title_border_heading_title_left_margin',
			[
				'label' => __( 'Margin', 'sf-widget' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .elementskit-section-subtitle.elementskit-style-border::after' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'ekit_heading_sub_title_border' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'ekit_heading_sub_title_border_height',
			[
				'label' => esc_html__( 'Height', 'sf-widget' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
						'step' => 1,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 3,
				],
				'selectors' => [
					'{{WRAPPER}} .elementskit-section-subtitle.elementskit-style-border::before, {{WRAPPER}} .elementskit-section-subtitle.elementskit-style-border::after' => 'height: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'ekit_heading_sub_title_border' => 'yes',
				],
			]
		);

        $this->add_responsive_control(
            'ekit_heading_sub_title_vertical_alignment',
            [
                'label' => esc_html__( 'Vertical Position', 'sf-widget' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range' => [
                    'px' => [
                        'min' => -20,
                        'max' => 20,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 3,
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementskit-section-subtitle.elementskit-style-border::before, {{WRAPPER}} .elementskit-section-subtitle.elementskit-style-border::after' => 'transform: translateY({{SIZE}}{{UNIT}}); -webkit-transform: translateY({{SIZE}}{{UNIT}}); -ms-transform: translateY({{SIZE}}{{UNIT}})',
                ],
                'condition' => [
                    'ekit_heading_sub_title_border' => 'yes',
                ],
            ]
		);
		
		$this->add_control( 
			'subheading_outline_heading', [
			'label' => esc_html__( 'Outline', 'sf-widget' ),
			'type' => Controls_Manager::HEADING,
			'separator' => 'before',
			'condition' => [
				'ekit_heading_sub_title_outline' => 'yes'	
			]
		]);

		do_action('sf_heading_subtitle_gradient_border',$this);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'subheading_outline',
				'label' => __( 'Outline', 'sf-widget' ),
				'selector' => '{{WRAPPER}} .ekit-heading__subtitle-has-border',
				'condition' => [
					'ekit_heading_sub_title_outline' => 'yes',
				]
			]
		);

		$this->add_responsive_control( 
			'subheading_outline_radius', [
			'label' => esc_html__( 'Outline Radius', 'sf-widget' ),
			'type' => Controls_Manager::DIMENSIONS,
			'size_units' => [ 'px', '%', 'em'],
			'default' => [
				'top' => '2',
				'right' => '2',
				'bottom' => '2',
				'left' => '2',
				'unit' => 'em',
				'isLinked' => true
			],
			'selectors' => [
				'{{WRAPPER}} .ekit-heading__subtitle-has-border' => 
					'border-radius:{{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
			'condition' => [
				'ekit_heading_sub_title_outline' => 'yes',
			]
		]);

		$this->end_controls_section();

		$this->fancy_text_register_style_controls();

		//Extra Title Style Section
        $this->start_controls_section(
			'ekit_heading_section_extra_title_style',
			[
				'label' => esc_html__( 'SF Description', 'sf-widget' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
					'ekit_heading_section_extra_title_show' => 'yes',
				],
			]
		);
 
		$this->add_responsive_control(
			'ekit_heading_extra_title_color',
			[
				'label'     => esc_html__( 'Description Color', 'sf-widget' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .elementskit-section-title-wraper p' => 'color: {{VALUE}};',
				],
				'default' => '',
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'ekit_heading_extra_title_typography',
				'selector' => '{{WRAPPER}} .elementskit-section-title-wraper p',
			]
		);
		
		$this->add_responsive_control(
			'ekit_heading_extra_title_margin',
			[
				'label'      => esc_html__( 'Margin', 'sf-widget' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .elementskit-section-title-wraper .ekit-heading__description' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		$this->end_controls_section();

		$this->register_list_controls("no");
		
		//Separator Style Section
		$this->start_controls_section(
			'ekit_heading_section_seperator_style', [
				'label'	 => esc_html__( 'Separator', 'sf-widget' ),
				'tab'	 => Controls_Manager::TAB_STYLE,
				'condition' => [
					'ekit_heading_show_seperator' => 'yes'
				]
			]
		);
		$this->add_responsive_control(
			'ekit_heading_seperator_width',
			[
				'label' => esc_html__( 'Width', 'sf-widget' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 100,
				],
				'selectors' => [
					'{{WRAPPER}} .elementskit-section-title-wraper .elementskit-border-divider' => 'width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .elementskit-section-title-wraper .elementskit-border-divider.elementskit-style-long' => 'width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .elementskit-section-title-wraper .elementskit-border-star' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition'		=> [
					'ekit_heading_seperator_style!' => 'ekit_border_custom'
				]
			]
		);

		$this->add_responsive_control(
			'ekit_heading_seperator_height',
			[
				'label' => esc_html__( 'Height', 'sf-widget' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 4,
				],
				'selectors' => [
					'{{WRAPPER}} .elementskit-section-title-wraper .elementskit-border-divider, {{WRAPPER}} .elementskit-border-divider::before' => 'height: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .elementskit-section-title-wraper .elementskit-border-divider.elementskit-style-long' => 'height: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .elementskit-section-title-wraper .elementskit-border-star' => 'height: {{SIZE}}{{UNIT}};',
					
				],
				'condition'		=> [
					'ekit_heading_seperator_style!' => 'ekit_border_custom'
				]
			]
		);

		$this->add_responsive_control(
			'ekit_heading_seperator_margin',
			[
				'label' => esc_html__( 'Margin', 'sf-widget' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .elementskit-section-title-wraper .ekit_heading_separetor_wraper' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'ekit_heading_seperator_color', [
				'label'		 =>esc_html__( 'Separator color', 'sf-widget' ),
				'type'		 => Controls_Manager::COLOR,
				'selectors'	 => [
					'{{WRAPPER}} .elementskit-section-title-wraper .elementskit-border-divider' => 'background: linear-gradient(90deg, {{VALUE}} 0%, {{VALUE}} 100%);',
					'{{WRAPPER}} .elementskit-section-title-wraper .elementskit-border-divider:before' => 'background-color: {{VALUE}}; color: {{VALUE}};',
					'{{WRAPPER}} .elementskit-section-title-wraper .elementskit-border-divider.elementskit-style-long' => 'color: {{VALUE}};',
					'{{WRAPPER}} .elementskit-section-title-wraper .elementskit-border-star' => 'color: {{VALUE}}',
					'{{WRAPPER}} .elementskit-section-title-wraper .elementskit-border-star:after' => 'background-color: {{VALUE}};',
				],
				'condition'		=> [
					'ekit_heading_seperator_style!' => 'ekit_border_custom'
				]
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_layout',
			[
				'label' => __('Button Layout Settings', 'sf-widget' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
				'condition' => [
                    'One_show_button_sf_controls' => 'yes','Two_show_button_sf_controls' => 'yes',
        ],
			]
	);

		$this->add_responsive_control(
			'flex_direction',
			[
				'label' => __('Flex Direction', 'sf-widget' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'row',
				'options' => [
					'row' => __('Row', 'sf-widget' ),
					'column' => __('Column', 'sf-widget' ),
				],
				'selectors' => [
					'{{WRAPPER}} .ekit-heading-button-wrapper' => 'flex-direction: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'button_gap',
			[
				'label' => __('Gap Between Buttons', 'sf-widget' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => ['px', 'em', '%'],
				'range' => [
					'px' => ['min' => 0, 'max' => 100],
					'em' => ['min' => 0, 'max' => 10],
					'%'  => ['min' => 0, 'max' => 100],
				],
				'default' => [
					'unit' => 'px',
					'size' => '',
				],
				'selectors' => [
					'{{WRAPPER}} .ekit-heading-button-wrapper' => 'gap: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		//button
		$this->register_button_controls("One", "1");
		$this->register_button_controls("Two", "2");

        //modified sf btn
    }

    protected function render( ) {
        echo '<div class="ekit-wid-con" >';
			$this->render_raw();
        echo '</div>';
    }

    protected function render_raw( ) {
        $settings = $this->get_settings_for_display();
		extract($settings);

		// Sanitize Title & Sub-Title Tags
		$options_ekit_heading_title_tag = array_keys([
			'h1' => 'H1',
			'h2' => 'H2',
			'h3' => 'H3',
			'h4' => 'H4',
			'h5' => 'H5',
			'h6' => 'H6',
			'div' => 'div',
			'span' => 'span',
			'p' => 'p',
		]);
		$title_tag = \ElementsKit_Lite\Utils::esc_options($ekit_heading_title_tag, $options_ekit_heading_title_tag, 'h2');

		// Sanitize Sub Title Tag
		$options_ekit_heading_sub_title_tag = array_keys([
			'h1' => 'H1',
			'h2' => 'H2',
			'h3' => 'H3',
			'h4' => 'H4',
			'h5' => 'H5',
			'h6' => 'H6',
			'div' => 'div',
			'span' => 'span',
			'p' => 'p',
		]);
		$sub_title_tag = \ElementsKit_Lite\Utils::esc_options($ekit_heading_sub_title_tag, $options_ekit_heading_sub_title_tag, 'p');

		// Image sectionn
        $image_html = '';
        if (!empty($settings['ekit_heading_seperator_image']['url'])) {

            $this->add_render_attribute('image', 'src', $settings['ekit_heading_seperator_image']['url']);
            $this->add_render_attribute('image', 'alt', Control_Media::get_image_alt($settings['ekit_heading_seperator_image']));
            $this->add_render_attribute('image', 'title', Control_Media::get_image_title($settings['ekit_heading_seperator_image']));

            $image_html = Group_Control_Image_Size::get_attachment_image_html($settings, 'ekit_heading_seperator_image_size', 'ekit_heading_seperator_image');

        }

		$seperator = '';
		if ($ekit_heading_seperator_style != 'ekit_border_custom') {
			$seperator = ($ekit_heading_show_seperator == 'yes') ? '<div class="ekit_heading_separetor_wraper ekit_heading_'. esc_attr($ekit_heading_seperator_style) .'"><div class="'. esc_attr($ekit_heading_seperator_style) .'"></div></div>' : '';
		} 
		else {
			$seperator = ($ekit_heading_show_seperator == 'yes') ? '<div class="ekit_heading_separetor_wraper ekit_heading_'. esc_attr($ekit_heading_seperator_style) .'"><div class="'. esc_attr($ekit_heading_seperator_style) .'">'.$image_html.'</div></div>' : '';
		}

		$title_text_fill = ($ekit_heading_focused_title_color_type == 'gradient') ? 'text_fill' : '';

		$sub_title_text_fill =	 ($settings['ekit_heading_use_sub_title_text_fill'] == 'yes') ? 'elementskit-gradient-title' : '';

		$sub_title_border =	 ($settings['ekit_heading_sub_title_border'] == 'yes') ? 'elementskit-style-border' : '';

		$sub_title_add_icon = $settings['ekit_heading_sub_title_add_icon'];
		$sub_title_icon_position = $settings['ekit_heading_sub_title_icon_position'];
		$sub_title_icon = $settings['ekit_heading_sub_title_icon'];

		$title_border = (isset($show_title_border) && $show_title_border == 'yes') ? ' ekit-heading__title-has-border '. esc_attr($title_border_position) : '';
		$subheading_outline = (isset($ekit_heading_sub_title_outline) && $ekit_heading_sub_title_outline == 'yes') ? 'sf-heading-has-outline ekit-heading__subtitle-has-border' : '';

			echo '<div class="ekit-heading sf-heading elementskit-section-title-wraper">';

			echo (($ekit_heading_seperator_position) == 'top') ? wp_kses($seperator, \ElementsKit_Lite\Utils::get_kses_array()): '';

			if($ekit_heading_sub_title_position == 'before_title'){
				if(!empty($ekit_heading_sub_title) && ($settings['ekit_heading_sub_title_show'] == 'yes')):
					echo '<div class="sf_heading_subtitle">';
					if ($settings['ekit_heading_use_sub_title_text_fill'] !== 'yes') : ?>
                		<div class="sf_animated-gradient-ring"></div>
            		 <?php endif;
					echo '<'. esc_attr($sub_title_tag).' class="ekit-heading--subtitle elementskit-section-subtitle '.esc_attr($sub_title_text_fill).' '.esc_attr($sub_title_border).''.esc_attr($subheading_outline).'">';
						if ($sub_title_add_icon === 'yes'&& $sub_title_icon_position === 'before' && !empty($sub_title_icon['value'])) {
							\Elementor\Icons_Manager::render_icon($sub_title_icon, ['aria-hidden' => 'true']);
						}
						echo esc_html( $ekit_heading_sub_title );
						if ($sub_title_add_icon === 'yes'&& $sub_title_icon_position === 'after' && !empty($sub_title_icon['value'])) {
							\Elementor\Icons_Manager::render_icon($sub_title_icon, ['aria-hidden' => 'true']);
						}
					echo '</'.esc_attr($sub_title_tag).'>';
					echo '</div>';
				endif;
			}

			$ekit_title = \ElementsKit_Lite\Utils::kspan($ekit_heading_title);

			echo (($ekit_heading_seperator_position) == 'before') ? wp_kses($seperator, \ElementsKit_Lite\Utils::get_kses_array()) : '';
			if(!empty($ekit_heading_title)):
				if ( ! empty( $ekit_heading_link['url'] ) ) {
					$this->add_link_attributes( 'ekit_heading_link', $ekit_heading_link );
					echo sprintf(
						'<a %1$s><%2$s class="ekit-heading--title elementskit-section-title %3$s">%4$s</%2$s></a>',
						$this->get_render_attribute_string('ekit_heading_link'), // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Already escaped by elementor
						esc_attr($title_tag),
						esc_attr($title_text_fill.''.$title_border),
						wp_kses($ekit_title, \ElementsKit_Lite\Utils::get_kses_array())
					);
				} 
				else {
					echo sprintf(
						'<%1$s class="ekit-heading--title elementskit-section-title %2$s">%3$s</%1$s>',
						esc_attr($title_tag),
						esc_attr($title_text_fill.''.$title_border),
						wp_kses($ekit_title, \ElementsKit_Lite\Utils::get_kses_array())
					);
				}
			endif;

			echo (
				$ekit_heading_seperator_position == 'after'
			) ? wp_kses($seperator, \ElementsKit_Lite\Utils::get_kses_array()) : '';

			if($ekit_heading_sub_title_position == 'after_title'){
				if(!empty($ekit_heading_sub_title) && ($settings['ekit_heading_sub_title_show'] == 'yes')):
					echo '<div class="sf_heading_subtitle">';
					if ($settings['ekit_heading_use_sub_title_text_fill'] !== 'yes') : ?>
                		<div class="sf_animated-gradient-ring"></div>
            		 <?php endif;
					echo '<'. esc_attr($sub_title_tag).' class="ekit-heading--subtitle elementskit-section-subtitle '.esc_attr($sub_title_text_fill).' '.esc_attr($sub_title_border).''.esc_attr($subheading_outline).'">';
						if ($sub_title_add_icon === 'yes'&& $sub_title_icon_position === 'before' && !empty($sub_title_icon['value'])) {
							\Elementor\Icons_Manager::render_icon($sub_title_icon, ['aria-hidden' => 'true']);
						}
						echo esc_html( $ekit_heading_sub_title );
						if ($sub_title_add_icon === 'yes'&& $sub_title_icon_position === 'after' && !empty($sub_title_icon['value'])) {
							\Elementor\Icons_Manager::render_icon($sub_title_icon, ['aria-hidden' => 'true']);
						}
					echo '</'.esc_attr($sub_title_tag).'>';
					echo '</div>';
				endif;
			}

			$this->fancy_text_render();

			if(!empty( $ekit_heading_extra_title ) && $settings['ekit_heading_section_extra_title_show'] === 'yes') : ?>
            <div class='ekit-heading__description'>
                <?php echo wp_kses( wpautop( $ekit_heading_extra_title ), \ElementsKit_Lite\Utils::get_kses_array() ); ?>
            </div>
			<?php endif;

			$this -> render_list();

			echo '<div class="ekit-heading-button-wrapper">';
			$this->render_button("One");
			$this->render_button("Two");
			echo '</div>';
			
			echo ($ekit_heading_seperator_position == 'bottom') ? wp_kses($seperator, \ElementsKit_Lite\Utils::get_kses_array()) : '';
			echo '</div>';
    }
}