jQuery(window).on("elementor:init", function () {
  elementor.hooks.addAction(
    "panel/open_editor/widget/sf-form",
    function (panel, model, view) {
      view.model.attributes.widgetType = "form";
      elementor.hooks.doAction(
        "panel/open_editor/widget/form",
        panel,
        model,
        view
      );
    }
  );
});