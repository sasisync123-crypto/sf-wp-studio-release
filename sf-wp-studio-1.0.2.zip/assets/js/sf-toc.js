(function($) {
    'use strict';

    /* --------------------------------------------------------------
       BUILD TOC
       -------------------------------------------------------------- */
    var buildToc = function($scope) {
        var $body = $scope.find('.sf-toc__body');
        var $list = $body.find('.sf-toc__list');
        var rawSettings = $body.data('settings') || {};

        var settings = {
            headings:               rawSettings.headings_by_tags || ['h2','h3','h4','h5','h6'],
            exclude:                rawSettings.exclude_headings_by_selector || '',
            container:              rawSettings.container || '',
            hierarchical:           rawSettings.hierarchical_view === 'yes',
            markerView:             rawSettings.marker_view || 'none',
            customMarker:           rawSettings.custom_marker_text || '',
            noHeadingsMsg:          rawSettings.no_headings_message || 'No headings found.',
            icon:                   rawSettings.icon || 'fas fa-circle',
            minimizeBox:            rawSettings.minimize_box === 'yes',
            collapseSubitems:       rawSettings.collapse_subitems === 'yes' || '',
            expandIcon:             rawSettings.expand_icon || {},
            collapseIcon:           rawSettings.collapse_icon || {}
        };

        var $container = $(settings.container);
        if (!$container.length) {
            $container = $scope.closest('article, .hentry, .post, .entry-content, .elementor-post, .elementor-section, main').first();
            if (!$container.length) $container = $('body');
        }

        var selector  = settings.headings.map(function(t){return t.trim();}).join(',');
        var $headings = $container.find(selector);
        var widgetId  = $body.attr('id');
        if (widgetId) {
            $headings = $headings.not('#'+widgetId).not('#'+widgetId+' *');
        }
        $headings = $headings.not('.sf-toc__header, .sf-toc__header *, .sf-toc__body, .sf-toc__body *');
        if (settings.exclude) {
            var excl = settings.exclude.split(',').map(function(s){return s.trim();}).filter(function(s){return s;});
            excl.forEach(function(sel){ $headings = $headings.not(sel); });
        }

        if ($headings.length === 0) {
            $list.html('<li class="sf-toc__no-headings">'+settings.noHeadingsMsg+'</li>');
            return { $list: $list, headings: $headings };
        }

        $list.empty();

        if (!settings.hierarchical) {
            $headings.each(function(index) {
                var $h = $(this);
                var text = $h.text().trim();
                if (!text) return;

                var id = $h.attr('id') || (function(){
                    var newId = 'sf-toc-heading-'+$scope.data('id')+'-'+index;
                    $h.attr('id', newId);
                    return newId;
                })();

                var marker = '';
                if (settings.markerView === 'none') {
                    // no marker
                } else if (settings.customMarker) {
                    marker = '<span class="sf-toc__marker">'+settings.customMarker+'</span> ';
                } else if (settings.markerView === 'numbers') {
                    marker = '<span class="sf-toc__marker">'+(index+1)+'.</span> ';
                } else {
                    marker = '<span class="sf-toc__marker"><i class="'+settings.icon+'"></i></span> ';
                }

                var $li = $(
                    '<li class="sf-toc__list-item">' +
                        '<a href="#'+id+'">' +
                            marker +
                            '<span class="sf-toc__link-text">'+text+'</span>' +
                        '</a>' +
                    '</li>'
                );

                $list.append($li);
            });
        } else {
            var stack = [], topCounter = 0;
            $headings.each(function(index) {
                var $h = $(this);
                var text = $h.text().trim();
                if (!text) return;
                var level = parseInt($h.prop('tagName').substring(1), 10);
                var id = $h.attr('id') || (function(){
                    var newId = 'sf-toc-heading-'+$scope.data('id')+'-'+index;
                    $h.attr('id', newId);
                    return newId;
                })();

                while (stack.length && stack[stack.length-1].level >= level) stack.pop();

                var fullNum, parent;
                if (stack.length) {
                    parent = stack[stack.length-1];
                    parent.childrenCounter = (parent.childrenCounter || 0) + 1;
                    fullNum = parent.fullNum + '.' + parent.childrenCounter;
                } else {
                    topCounter++;
                    fullNum = topCounter.toString();
                }

                var markerHtml = '';
                if (settings.markerView !== 'none') {
                    if (settings.customMarker) {
                        markerHtml = '<span class="sf-toc__marker">'+settings.customMarker+'</span> ';
                    } else if (settings.markerView === 'numbers') {
                        markerHtml = '<span class="sf-toc__marker">'+fullNum+'.</span> ';
                    } else {
                        markerHtml = '<span class="sf-toc__marker"><i class="'+settings.icon+'"></i></span> ';
                    }
                }

                var linkHtml =
                    '<a href="#'+id+'">' +
                        markerHtml +
                        '<span class="sf-toc__link-text">'+text+'</span>' +
                    '</a>';

                var $newLi = $('<li class="sf-toc__list-item"></li>').html(linkHtml);
                var newItem = { $li: $newLi, level: level, fullNum: fullNum, childrenCounter: 0 };

                if (stack.length === 0) {
                    $list.append($newLi);
                } else {
                    var $parentLi = parent.$li;
                    var $subUl = $parentLi.children('ul.sf-toc__list--children');
                    if (!$subUl.length) {
                        $subUl = $('<ul class="sf-toc__list sf-toc__list--children"></ul>');
                        $parentLi.append($subUl);
                    }
                    $subUl.append($newLi);
                }
                stack.push(newItem);
            });
        }

        if (settings.hierarchical && settings.collapseSubitems) {
            $list.find('ul.sf-toc__list--children').each(function(){
                $(this).hide();
                var $parentLi = $(this).parent('li');
                $parentLi.addClass('sf-toc__list-item--collapsed');
                var $link = $parentLi.find('> a');
                $link.prepend('<i class="sf-toc__sub-toggle fas fa-chevron-right"></i> ');
            });
        }

        return { $list: $list, headings: $headings };
    };

    /* --------------------------------------------------------------
       TOGGLE MINIMIZE / EXPAND
       -------------------------------------------------------------- */
    var toggleMinimize = function($scope) {
        var $header   = $scope.find('.sf-toc__header');
        var $body     = $scope.find('.sf-toc__body');
        var $expand   = $header.find('.sf-toc__toggle-button--expand');
        var $collapse = $header.find('.sf-toc__toggle-button--collapse');
        var isExpanded = $expand.attr('aria-expanded') === 'true';
        $body.slideToggle(300);
        $expand.attr('aria-expanded', !isExpanded);
        $collapse.attr('aria-expanded', !isExpanded);
        if (isExpanded) { $expand.hide(); $collapse.show(); }
        else            { $expand.show(); $collapse.hide(); }
    };

    /* --------------------------------------------------------------
       TOGGLE SUB-ITEMS
       -------------------------------------------------------------- */
    var toggleSubitems = function($toggle) {
        var $li   = $toggle.closest('li');
        var $ul   = $li.children('ul.sf-toc__list--children');
        var $icon = $toggle.find('i.sf-toc__sub-toggle');
        $ul.slideToggle(200);
        $li.toggleClass('sf-toc__list-item--collapsed');
        $icon.toggleClass('fa-chevron-right fa-chevron-down');
    };

    /* --------------------------------------------------------------
       ACTIVE LINK
       -------------------------------------------------------------- */
    var setActiveTocLink = function($scope) {
        var $links = $scope.find('.sf-toc__list a');
        $links.removeClass('sf-toc__link--active');

        var $headings = $scope.data('toc-headings');
        if (!$headings || !$headings.length) return;

        var scrollTop = $(window).scrollTop() + 1;
        var threshold = scrollTop;

        var activeHeading = null;
        var bestDiff = Infinity;

        $headings.each(function () {
            var $h = $(this);
            var top = $h.offset().top;
            var bottom = top + $h.outerHeight(true);
            if (bottom > scrollTop) {
                var diff = Math.abs(top - threshold);
                if (diff < bestDiff) {
                    bestDiff = diff;
                    activeHeading = $h;
                }
            }
        });

        if (!activeHeading) {
            $headings.each(function () {
                if ($(this).offset().top <= threshold) {
                    activeHeading = $(this);
                    return false;
                }
            });
        }

        if (activeHeading && activeHeading.length) {
            var id = activeHeading.attr('id');
            if (id) {
                $links.filter('[href="#' + id + '"]').addClass('sf-toc__link--active');
            }
        }
    };

    /* --------------------------------------------------------------
       THROTTLE
       -------------------------------------------------------------- */
    var throttle = function(fn, delay) {
        var last = 0;
        return function() {
            var now = Date.now();
            if (now - last >= delay) {
                last = now;
                fn.apply(this, arguments);
            }
        };
    };

    /* --------------------------------------------------------------
       ELEMENTOR FRONTEND INIT
       -------------------------------------------------------------- */
    $(window).on('elementor/frontend/init', function() {
        elementorFrontend.hooks.addAction('frontend/element_ready/sf-toc.default', function($scope){

            var widgetId = $scope.data('id');
            if (!widgetId) return;

            var tocData = buildToc($scope);
            $scope.data('toc-headings', tocData.headings);

            var $header = $scope.find('.sf-toc__header');
            $header.off('click.sfTocMin keydown.sfTocMin', '.sf-toc__toggle-button');
            $header.on('click.sfTocMin keydown.sfTocMin', '.sf-toc__toggle-button', function(e){
                if (e.type === 'keydown' && e.which !== 13 && e.which !== 32) return;
                e.preventDefault();
                toggleMinimize($scope);
            });

            var $expand   = $header.find('.sf-toc__toggle-button--expand');
            var $collapse = $header.find('.sf-toc__toggle-button--collapse');
            if ($expand.attr('aria-expanded') === 'true') $collapse.hide();
            else $expand.hide();

            $scope.off('click.sfTocSub', '.sf-toc__sub-toggle');
            $scope.on('click.sfTocSub', '.sf-toc__sub-toggle', function(e){
                e.preventDefault();
                toggleSubitems($(this));
            });

            var updateActive = throttle(function() {
                setActiveTocLink($scope);
            }, 100);

            var namespace = '.sfTocActive_' + widgetId;
            $(window).off('scroll' + namespace + ' resize' + namespace);
            $(window).on('scroll' + namespace + ' resize' + namespace, updateActive);

            $scope.off('click.sfTocLink');
            $scope.on('click.sfTocLink', '.sf-toc__list a', function(e) {
                var $link = $(this);
                var href = $link.attr('href');
                if (!href || !href.startsWith('#')) return;

                var targetId = href.substring(1);
                var $target = $('#' + targetId);
                if (!$target.length) return;

                e.preventDefault();

                var adminBar = $('#wpadminbar').outerHeight() || 0;
                var stickyHeader = 0;
                var offset = adminBar + stickyHeader;

                $('html, body').animate({
                    scrollTop: $target.offset().top - offset
                }, 500, function() {
                    updateActive();
                    history.pushState(null, null, href);
                });

                setTimeout(updateActive, 100);
            });

            setTimeout(updateActive, 100);
        });
    });

})(jQuery);