(function ($) {
    $(window).on('elementor/frontend/init', function () {
        elementorFrontend.hooks.addAction('frontend/element_ready/sf_timeline.default', function ($scope) {
            custom_timeline_hover($scope);
            initScrollDot($scope);
        });
    });
 
    function custom_timeline_hover($scope) {
        $scope.find(".elementskit-invisible").each(function () {
            ElementsKit_Helper?.observeElement(this, (el) => {
                const $el = $(el);
                if (!$el.hasClass("animated")) {
                    const animationClass = "animated " + $el.data("settings")._animation;
                    $el.removeClass("elementskit-invisible").addClass(animationClass);
                }
            }, {
                threshold: 0.1
            });
        });
 
        let $lastHovered = null;
 
        const $timelines = $scope.find(".horizantal-timeline > .single-timeline");
        if (!$timelines.hasClass("hover")) {
            $timelines.first().addClass("hover").siblings().removeClass("hover");
        }
 
        $scope.on("mouseenter", ".horizantal-timeline > .single-timeline", function () {
            $(this).addClass("hover").siblings().removeClass("hover");
            $lastHovered = $(this);
        });
 
        $scope.on("mouseleave", ".horizantal-timeline > .single-timeline", function () {
            $(this).removeClass("hover");
            if ($lastHovered) {
                $lastHovered.addClass("hover");
            }
        });
    }
 
    function initScrollDot($scope) {
      // const settings = window.sfTimelineSettings || {};
      // if (settings.scrollDot !== 'yes' || settings.pinpointIsText !== 'yes') return;
 
      const $bar = $scope.find(".sf-timeline-bar");
      if (!$bar.length) return;
 
      let $dot = $bar.find(".scroll-dot");
      if (!$dot.length)
        $dot = $('<div class="scroll-dot"></div>').appendTo($bar);
 
      const DOT_SIZE = 12,
        GAP = 5;
 
      let $activeItem = null;
      const activateItem = ($item) => {
        if ($activeItem) $activeItem.removeClass("scroll-active");
        $item.addClass("scroll-active");
        $activeItem = $item;
      };
 
      const update = () => {
        const { top, height } = $bar[0].getBoundingClientRect();
        const progress = Math.min(Math.max((window.scrollY + window.innerHeight / 2 - top - window.scrollY) / height, 0 ), 1);
        const travel = height - DOT_SIZE - GAP * 2;
        $dot.css("transform", `translateX(-41%) translateY(${progress * travel + DOT_SIZE / 2}px)`);
        const centerY = window.scrollY + window.innerHeight / 2;
        let closest = null;
        let minDist = Infinity;
        $scope.find(".single-timeline").each(function () {
          const $this = $(this);
          const itemTop = $this.offset().top + $this.outerHeight() / 2;
          const dist = Math.abs(centerY - itemTop);
          if (dist < minDist) {
            minDist = dist;
            closest = $this;
          }
        });
        if (closest) {
          activateItem(closest);
          closest.find(".sf-timeline-pin-text")[0].offsetHeight;
        }
      };
 
      update();
      $(window).on("scroll.sfDot resize.sfDot", update);
    }
})(jQuery);