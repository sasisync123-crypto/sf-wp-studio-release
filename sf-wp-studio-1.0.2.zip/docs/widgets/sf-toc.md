Prompt: 
> You are a documentation assistant for Elementor widget development.  


Using the following JSON input, generate a well-structured widget documentation in markdown formate.
IMPORTANT : Generate the document in a way that it is fully understandle and make a professional document and follow the standard document creation rulue, make all sentance starting as capital case


 <!-- SFWP_DOCS_PLACEHOLDER -->
 

Maintain this structure and formatting:

## 🧩 Widget Documentation Template

### 📝 Widget Summary  
Write a 2-line summary describing what the widget does and how it enhances the user experience. Use `"widget name"` and `"summary"` fields.

---

### 🆓 Free Features  
List all features from `"free_features"` using this format:
- **{{ name }}** – {{ description }}

---

### 💎 Pro Features  
List all features from `"pro_features"` using this format:
- **{{ name }}** – {{ description }}

---

### 🔍 Background & Motivation  
**Existing Limitations**  
Use `"background_motivation.limitations"`

**Why We Developed This**  
Use `"background_motivation.motivation"`

---

### 🏗️ Architecture  
Generate this section dynamically based on `"architecture"` values:

- **Base Widget**:  
  - If `"type"` is `"custom"` → `"Built from scratch using {{ base }} base classes."`  
  - If `"type"` is `"extended"` → `"Extended from {{ extends }} using {{ base }}."`  
  - If `"type"` is `"forked"` → `"Forked from {{ forked_from }} in {{ base }} and customized independently."`

- **Trait Used**: List `"traits"`  
- **Used separate style sheet**: `"Yes"` if `"is_separate_style_sheet"` is `"yes"`  
- **Used JS file**: `"Yes"` if `"is_JS_Used"` is `"yes"`

---

### 📈 What’s Next  
-Formate -  **{{ name }}** – {{ description }}
- **Planned Feature 1** – Use `"next.features[0]" `  
- **Planned Feature 2** – Use `"next.features[1]"`  
- **Refactor Plan** – Use `"next.refactor"`

---

### 🗂️ Usage Context  
**Used In**: List `"usage_context.used_in"`  
**Compatible With**: List `"usage_context.compatible_with"`



