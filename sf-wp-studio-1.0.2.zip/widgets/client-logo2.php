<?php
namespace SFWPStudio\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Utils;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Icons_Manager;

class Client_Logo2 extends Widget_Base {

    public function get_name() { 
        return 'sf-client-logo2'; 
    }

    public function get_title() { 
        return __( 'SF Client Logo -2 (Scroll Action)', 'sf-widget' ); 
    }

    public function get_icon() { 
        return 'eicon-logo'; 
    }

    public function get_keywords() { 
        return [ 'logo', 'carousel', 'scroll', 'client', 'infinite' ]; 
    }

    public function get_categories() {
        return [ 'sf-widget' ]; 
    }

    public function get_script_depends() { 
        return [ 'client-logo2' ]; 
    }

    public function is_dynamic_content(): bool { 
        return false; 
    }

    protected function _register_controls() {

        /* ---------- Logos ---------- */
        $this->start_controls_section(
            'section_logos',
            [ 'label' => __( 'Client Logos', 'sf-widget' ) ]
        );

        $repeater = new Repeater();

        $repeater->add_control( 'logo_image', [
            'label'   => __( 'Logo Image', 'sf-widget' ),
            'type'    => Controls_Manager::MEDIA,
            'default' => [ 'url' => Utils::get_placeholder_image_src() ],
            'dynamic' => [ 'active' => true ],
        ]);

        $repeater->add_control( 'enable_hover_logo', [
            'label'   => __( 'Enable Hover Logo', 'sf-widget' ),
            'type'    => Controls_Manager::SWITCHER,
            'default' => '',
        ]);

        $repeater->add_control( 'logo_image_hover', [
            'label'     => __( 'Hover Logo', 'sf-widget' ),
            'type'      => Controls_Manager::MEDIA,
            'default'   => [ 'url' => Utils::get_placeholder_image_src() ],
            'dynamic'   => [ 'active' => true ],
            'condition' => [ 'enable_hover_logo' => 'yes' ],
        ]);

        $repeater->add_control( 'logo_name', [
            'label'   => __( 'Client Name (Alt)', 'sf-widget' ),
            'type'    => Controls_Manager::TEXT,
            'default' => __( 'Client Logo', 'sf-widget' ),
        ]);

        $repeater->add_control( 'logo_link', [
            'label'       => __( 'Link URL', 'sf-widget' ),
            'type'        => Controls_Manager::URL,
            'placeholder' => __( 'https://example.com', 'sf-widget' ),
            'dynamic'     => [ 'active' => true ],
        ]);

        $this->add_control( 'logos', [
            'label'       => __( 'Logos', 'sf-widget' ),
            'type'        => Controls_Manager::REPEATER,
            'fields'      => $repeater->get_controls(),
            'default'     => [
                [ 'logo_name' => 'Client 1' ],
                [ 'logo_name' => 'Client 2' ],
                [ 'logo_name' => 'Client 3' ],
            ],
            'title_field' => '{{{ logo_name }}}',
        ]);

        $this->end_controls_section();

        /* ---------- Settings ---------- */
        $this->start_controls_section( 'section_settings', [
            'label' => __( 'Carousel Settings', 'sf-widget' )
        ]);

        // Scroll Speed control REMOVED

        $this->add_responsive_control( 'logo_gap', [
            'label'     => __( 'Gap Between Logos', 'sf-widget' ),
            'type'      => Controls_Manager::SLIDER,
            'size_units'=> [ 'px' ],
            'range'     => [ 'px' => [ 'min' => 0, 'max' => 100 ] ],
            'default'   => [ 'size' => 32 ],
            'selectors' => [ '{{WRAPPER}} .sf-logo-track' => 'gap: {{SIZE}}{{UNIT}};' ],
        ]);

        $this->add_responsive_control( 'logo_height', [
            'label'     => __( 'Logo Height', 'sf-widget' ),
            'type'      => Controls_Manager::SLIDER,
            'size_units'=> [ 'px' ],
            'range'     => [ 'px' => [ 'min' => 40, 'max' => 200 ] ],
            'default'   => [ 'size' => 80 ],
            'selectors' => [ '{{WRAPPER}} .sf-logo-item img' => 'max-height: {{SIZE}}{{UNIT}};' ],
        ]);

        $this->add_control( 'ekit_show_arrow', [
            'label'   => __( 'Show Arrow', 'sf-widget' ),
            'type'    => Controls_Manager::SWITCHER,
            'default' => '',
        ]);

        $this->add_control( 'ekit_left_arrow_icon', [
            'label'     => __( 'Left Arrow Icon', 'sf-widget' ),
            'type'      => Controls_Manager::ICONS,
            'default'   => [ 'value' => 'fas fa-chevron-left', 'library' => 'fa-solid' ],
            'condition' => [ 'ekit_show_arrow' => 'yes' ],
        ]);

        $this->add_control( 'ekit_right_arrow_icon', [
            'label'     => __( 'Right Arrow Icon', 'sf-widget' ),
            'type'      => Controls_Manager::ICONS,
            'default'   => [ 'value' => 'fas fa-chevron-right', 'library' => 'fa-solid' ],
            'condition' => [ 'ekit_show_arrow' => 'yes' ],
        ]);

        $this->add_control( 'ekit_show_dot', [
            'label'   => __( 'Show Dots', 'sf-widget' ),
            'type'    => Controls_Manager::SWITCHER,
            'default' => '',
        ]);

        $this->end_controls_section();

        /* ---------- Style – Container ---------- */
        $this->start_controls_section( 'section_container_style', [
            'label' => __( 'Container', 'sf-widget' ),
            'tab'   => Controls_Manager::TAB_STYLE,
        ]);

        $this->add_group_control( Group_Control_Background::get_type(), [
            'name'      => 'container_bg',
            'label'     => __( 'Background', 'sf-widget' ),
            'types'     => [ 'classic', 'gradient' ],
            'selectors' => [ '{{WRAPPER}} .sf-logo-carousel' => 'background: {{VALUE}};' ],
        ]);

        $this->add_responsive_control( 'carousel_padding', [
            'label'     => __( 'Padding', 'sf-widget' ),
            'type'      => Controls_Manager::DIMENSIONS,
            'size_units'=> [ 'px', 'em', '%' ],
            'default'   => [ 'top' => 4, 'right' => 0, 'bottom' => 4, 'left' => 0, 'unit' => 'rem' ],
            'selectors' => [ '{{WRAPPER}} .sf-logo-overflow' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
        ]);

        $this->end_controls_section();

        /* ---------- Style – Logo Item ---------- */
        $this->start_controls_section( 'section_logo_item_style', [
            'label' => __( 'Logo Item', 'sf-widget' ),
            'tab'   => Controls_Manager::TAB_STYLE,
        ]);

        $this->add_responsive_control( 'slide_inner_width', [
            'label'      => esc_html__( 'Width', 'sf-widget' ),
            'type'       => Controls_Manager::SLIDER,
            'size_units' => [ 'px', '%' ],
            'range'      => [ 'px' => [ 'min' => 50, 'max' => 1000 ], '%' => [ 'min' => 10, 'max' => 100 ] ],
            'default'    => [ 'unit' => 'px', 'size' => 155 ],
            'selectors'  => [ '{{WRAPPER}} .sf-logo-item' => 'min-width: {{SIZE}}{{UNIT}} !important;' ],
        ]);

        $this->add_responsive_control( 'slide_inner_height', [
            'label'      => esc_html__( 'Height', 'sf-widget' ),
            'type'       => Controls_Manager::SLIDER,
            'size_units' => [ 'px', 'vh' ],
            'range'      => [ 'px' => [ 'min' => 50, 'max' => 500 ] ],
            'selectors'  => [ '{{WRAPPER}} .sf-logo-item' => 'height: {{SIZE}}{{UNIT}};' ],
        ]);

        $this->start_controls_tabs( 'logo_style_tabs' );

        $this->start_controls_tab( 'logo_normal_tab', [ 'label' => __( 'Normal', 'sf-widget' ) ] );

        $this->add_group_control( Group_Control_Background::get_type(), [
            'name'     => 'logo_bg_normal',
            'selector' => '{{WRAPPER}} .sf-logo-item',
        ]);
        $this->end_controls_tab();

        $this->start_controls_tab( 'logo_hover_tab', [ 'label' => __( 'Hover', 'sf-widget' ) ] );

        $this->add_group_control( Group_Control_Background::get_type(), [
            'name'     => 'logo_bg_hover',
            'selector' => '{{WRAPPER}} .sf-logo-item:hover',
        ]);

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_responsive_control( 'logo_padding', [
            'label'     => __( 'Padding', 'sf-widget' ),
            'type'      => Controls_Manager::DIMENSIONS,
            'default'   => [ 'top' => 20, 'right' => 20, 'bottom' => 20, 'left' => 20, 'unit' => 'px' ],
            'selectors' => [ '{{WRAPPER}} .sf-logo-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
        ]);

        $this->add_responsive_control( 'logo_margin', [
            'label'     => __( 'Margin', 'sf-widget' ),
            'type'      => Controls_Manager::DIMENSIONS,
            'selectors' => [ '{{WRAPPER}} .sf-logo-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
        ]);

        $this->add_responsive_control( 'logo_border_radius', [
            'label'     => __( 'Border Radius', 'sf-widget' ),
            'type'      => Controls_Manager::DIMENSIONS,
            'default'   => [ 'top' => 14, 'right' => 14, 'bottom' => 14, 'left' => 14, 'unit' => 'px' ],
            'selectors' => [ '{{WRAPPER}} .sf-logo-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
        ]);

        $this->start_controls_tabs( 'logo_border_tabs' );

        $this->start_controls_tab( 'logo_border_normal', [ 'label' => __( 'Normal', 'sf-widget' ) ] );

        $this->add_group_control( Group_Control_Border::get_type(), [ 'name' => 'logo_border', 'selector' => '{{WRAPPER}} .sf-logo-item' ] );

        $this->add_group_control( Group_Control_Box_Shadow::get_type(), [ 'name' => 'logo_shadow', 'selector' => '{{WRAPPER}} .sf-logo-item' ] );

        $this->end_controls_tab();

        $this->start_controls_tab( 'logo_border_hover', [ 'label' => __( 'Hover', 'sf-widget' ) ] );

        $this->add_group_control( Group_Control_Border::get_type(), [ 'name' => 'logo_border_hover', 'selector' => '{{WRAPPER}} .sf-logo-item:hover' ] );

        $this->add_group_control( Group_Control_Box_Shadow::get_type(), [ 'name' => 'logo_shadow_hover', 'selector' => '{{WRAPPER}} .sf-logo-item:hover' ] );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_responsive_control( 'logo_opacity', [
            'label'     => __( 'Opacity', 'sf-widget' ),
            'type'      => Controls_Manager::SLIDER,
            'default'   => [ 'size' => 1 ],
            'selectors' => [ '{{WRAPPER}} .sf-logo-item img' => 'opacity: {{SIZE}};' ],
        ]);

        $this->add_responsive_control( 'logo_opacity_hover', [
            'label'     => __( 'Opacity on Hover', 'sf-widget' ),
            'type'      => Controls_Manager::SLIDER,
            'default'   => [ 'size' => 1 ],
            'selectors' => [ '{{WRAPPER}} .sf-logo-item:hover img' => 'opacity: {{SIZE}};' ],
        ]);

        $this->add_control( 'use_gradient_border', [
            'label'        => esc_html__( 'Use Gradient Border Color', 'sf-widget' ),
            'type'         => Controls_Manager::SWITCHER,
            'return_value' => 'yes',
            'default'      => 'yes',
        ]);

        $this->add_responsive_control( 'border_width', [
            'label'     => esc_html__( 'Border Width', 'sf-widget' ),
            'type'      => Controls_Manager::SLIDER,
            'default'   => [ 'size' => 2 ],
            'selectors' => [ '{{WRAPPER}} .sf-logo-item' => 'border-width: {{SIZE}}{{UNIT}};' ],
            'condition' => [ 'use_gradient_border!' => 'yes' ],
        ]);

        $this->add_control( 'border_style', [
            'label'     => esc_html__( 'Border Style', 'sf-widget' ),
            'type'      => Controls_Manager::SELECT,
            'default'   => 'none',
            'options'   => [ 'solid' => 'Solid', 'dashed' => 'Dashed', 'dotted' => 'Dotted', 'double' => 'Double', 'none' => 'None' ],
            'selectors' => [ '{{WRAPPER}} .sf-logo-item' => 'border-style: {{VALUE}};' ],
            'condition' => [ 'use_gradient_border!' => 'yes' ],
        ]);

        $this->add_control( 'border_color', [
            'label'     => esc_html__( 'Border Color', 'sf-widget' ),
            'type'      => Controls_Manager::COLOR,
            'selectors' => [ '{{WRAPPER}} .sf-logo-item' => 'border-color: {{VALUE}};' ],
            'condition' => [ 'use_gradient_border!' => 'yes' ],
        ]);

        $this->add_control( 'gradient_color_1', [ 'label' => __( 'Gradient Border Color 1', 'sf-widget' ), 'type' => Controls_Manager::COLOR, 'condition' => [ 'use_gradient_border' => 'yes' ] ] );

        $this->add_control( 'gradient_color_2', [ 'label' => __( 'Gradient Border Color 2', 'sf-widget' ), 'type' => Controls_Manager::COLOR, 'condition' => [ 'use_gradient_border' => 'yes' ] ] );
        
        $this->add_control( 'gradient_color_3', [ 'label' => __( 'Gradient Border Color 3', 'sf-widget' ), 'type' => Controls_Manager::COLOR, 'condition' => [ 'use_gradient_border' => 'yes' ] ] );

        $this->add_control( 'gradient_direction', [
            'label'   => __( 'Gradient Direction', 'sf-widget' ),
            'type'    => Controls_Manager::SELECT,
            'default' => 'to top right',
            'options' => [
                'to left' => 'Left to Right', 'to right' => 'Right to Left', 'to top' => 'Bottom to Top',
                'to bottom' => 'Top to Bottom', 'to top left' => 'Bottom-Right to Top-Left',
                'to top right' => 'Bottom-Left to Top-Right', 'to bottom left' => 'Top-Right to Bottom-Left',
                'to bottom right' => 'Top-Left to Bottom-Right',
            ],
            'condition' => [ 'use_gradient_border' => 'yes' ],
        ]);

        $this->end_controls_section();

        /* ---------- Style – Arrows & Dots ---------- */
        $this->start_controls_section( 'section_arrow_style', [
            'label' => __( 'Arrows', 'sf-widget' ), 'tab' => Controls_Manager::TAB_STYLE,
            'condition' => [ 'ekit_show_arrow' => 'yes' ],
        ]);
        $this->add_responsive_control( 'arrow_size', [
            'label' => __( 'Size', 'sf-widget' ), 'type' => Controls_Manager::SLIDER,
            'selectors' => [ '{{WRAPPER}} .swiper-button-prev, {{WRAPPER}} .swiper-button-next' => 'font-size: {{SIZE}}{{UNIT}};' ],
        ]);
        $this->add_control( 'arrow_color', [ 'label' => __( 'Color', 'sf-widget' ), 'type' => Controls_Manager::COLOR,
            'selectors' => [ '{{WRAPPER}} .swiper-button-prev, {{WRAPPER}} .swiper-button-next' => 'color: {{VALUE}}; fill: {{VALUE}};' ],
        ]);
        $this->add_control( 'arrow_bg', [ 'label' => __( 'Background', 'sf-widget' ), 'type' => Controls_Manager::COLOR,
            'selectors' => [ '{{WRAPPER}} .swiper-button-prev, {{WRAPPER}} .swiper-button-next' => 'background: {{VALUE}};' ],
        ]);
        $this->end_controls_section();

        $this->start_controls_section( 'section_dot_style', [
            'label' => __( 'Dots', 'sf-widget' ), 'tab' => Controls_Manager::TAB_STYLE,
            'condition' => [ 'ekit_show_dot' => 'yes' ],
        ]);
        $this->add_responsive_control( 'dot_size', [
            'label' => __( 'Size', 'sf-widget' ), 'type' => Controls_Manager::SLIDER,
            'default' => [ 'size' => 8 ], 'selectors' => [ '{{WRAPPER}} .swiper-pagination span' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};' ],
        ]);
        $this->end_controls_section();
    }

    protected function render() {
        $settings   = $this->get_settings_for_display();
        if ( empty( $settings['logos'] ) ) return;

        $widget_id  = $this->get_id();
        $all_logos  = array_merge( $settings['logos'], $settings['logos'] );

        $this->add_render_attribute( 'wrapper', [
            'class' => 'sf-logo-carousel',
            'id'    => 'sf-logo-' . $widget_id,
        ]);
        $this->add_render_attribute( 'wrapper', 'data-gradient-border', $settings['use_gradient_border'] );
        ?>
        <div <?php echo $this->get_render_attribute_string( 'wrapper' ); ?>>
            <?php if ( ! empty( $settings['ekit_show_arrow'] ) ) : ?>
                <div class="swiper-button-prev">
                    <?php Icons_Manager::render_icon( $settings['ekit_left_arrow_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                </div>
                <div class="swiper-button-next">
                    <?php Icons_Manager::render_icon( $settings['ekit_right_arrow_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                </div>
            <?php endif; ?>

            <div class="sf-logo-overflow">
                <div class="sf-logo-track"
                     data-direction="rtl">
                    <?php foreach ( $all_logos as $index => $logo ) :
                        $img       = $logo['logo_image']['url'] ?? '';
                        $img_hover = $logo['logo_image_hover']['url'] ?? '';
                        $alt       = $logo['logo_name'] ?? '';
                        $url       = $logo['logo_link']['url'] ?? '';
                        if ( empty( $img ) ) continue;

                        $this->add_render_attribute( 'logo_item_' . $index, 'class', 'sf-logo-item' );
                        $this->add_render_attribute( 'logo_item_' . $index, 'data-gradient-border', $settings['use_gradient_border'] === 'yes' ? 'yes' : 'no' );
                        if ( $logo['enable_hover_logo'] === 'yes' && $img_hover ) {
                            $this->add_render_attribute( 'logo_item_' . $index, 'class', 'has-hover-logo' );
                        }
                        ?>
                        <div <?php echo $this->get_render_attribute_string( 'logo_item_' . $index ); ?>>
                            <?php if ( $url ) : ?>
                                <a href="<?php echo esc_url( $url ); ?>"
                                   target="<?php echo esc_attr( $logo['logo_link']['is_external'] ? '_blank' : '_self' ); ?>"
                                   rel="<?php echo $logo['logo_link']['nofollow'] ? 'nofollow' : ''; ?> <?php echo $logo['logo_link']['is_external'] ? 'noopener' : ''; ?>">
                            <?php endif; ?>
                            <span class="content-image">
                                <img src="<?php echo esc_url( $img ); ?>" alt="<?php echo esc_attr( $alt ); ?>" class="main-image" loading="lazy">
                                <?php if ( $logo['enable_hover_logo'] === 'yes' && $img_hover ) : ?>
                                    <img src="<?php echo esc_url( $img_hover ); ?>" alt="<?php echo esc_attr( $alt ); ?>" class="hover-image" loading="lazy">
                                <?php endif; ?>
                            </span>
                            <?php if ( $url ) : ?></a><?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <?php if ( ! empty( $settings['ekit_show_dot'] ) ) : ?>
                <div class="swiper-pagination"></div>
            <?php endif; ?>
        </div>

        <?php
    }
}
?>