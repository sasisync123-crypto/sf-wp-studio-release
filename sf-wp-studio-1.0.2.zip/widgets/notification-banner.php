<?php
namespace SFWPStudio\Widgets;

class Notification_Banner extends \Elementor\Widget_Base
{
    use \SFWPStudio\Core\Helpers\Traits\ButtonTrait;
    public function get_name()
    {
        return 'sf-notification-banner';
    }

    public function get_title()
    {
        return esc_html__('SF Notification Banner', 'sf-widgets');
    }

    public function get_icon()
    {
        return 'sync-widget-icon eicon-tabs';
    }

    public function get_categories()
    {
        return ['syncfusion-widgets', 'layout'];
    }

    public function get_style_depends()
    {
        return ['sf-notification-banner'];
    }

    public function get_script_depends()
    {
        return [];
    }

    protected function register_controls()
    {
        $variants = include plugin_dir_path(__DIR__) . '/core/helpers/includes/variants_list.php';
        $start = is_rtl() ? 'right' : 'left';
        $end = is_rtl() ? 'left' : 'right';

        //Content Tab Controls
        $this->start_controls_section(
            'sf-notification-content-tab',
            [
                'label' => esc_html__('Banner Layout Setting', 'sf-widget'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'sf-banner-mode-select',
            [
                'label' => esc_html__('Select Mode', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'toast' => esc_html__('Toast', 'sf-widget'),
                    'banner' => esc_html__('Banner-CTA', 'sf-widget'),
                ],
                'default' => 'toast',
            ]
        );



        $this->add_control(
            'sf_notify_banner_background_image',
            [

                'label' => esc_html__('Banner Background Image', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'media_types' => ['image', 'svg'],
                'default' => [
                    'id' => 21,
                    'url' => wp_get_attachment_url(21),
                ],
                'description' => esc_html__('Upload an SVG or image to use as the banner background.', 'sf-widget'),
                'condition' => ['sf_background_type' => 'image']
            ]
        );

        //parent controls starts
        $this->add_responsive_control(
            'sync_orientation',
            [
                'label' => esc_html__('Orientation', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'toggle' => false,
                'default' => 'row',
                'options' => [
                    'row' => [
                        'title' => esc_html__('Row - horizontal', 'sf-widget'),
                        'icon' => 'eicon-arrow-' . $end,
                    ],
                    'column' => [
                        'title' => esc_html__('Column - vertical', 'sf-widget'),
                        'icon' => 'eicon-arrow-down',
                    ],

                ],
                'selectors_dictionary' => [
                    'row' => '--sf-banner-layout-direction: row;',
                    'column' => '--sf-banner-layout-direction: column;',
                ],
                'selectors' => [
                    '{{WRAPPER}} .content-parent' => '{{VALUE}}',
                ],
                'responsive' => true,
            ]
        );

        $this->add_control(
            'sf_banner_content_position',
            [
                'label' => esc_html__('Content Position', 'your-plugin-sf-widget'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'flex-start' => esc_html__('Start', 'your-plugin-sf-widget'),
                    'center' => esc_html__('Center', 'your-plugin-sf-widget'),
                    'space-between' => esc_html__('Space Between', 'your-plugin-sf-widget'),
                    'space-around' => esc_html__('Space Around', 'your-plugin-sf-widget'),
                ],
                'default' => 'flex-start',
                'selectors' => [
                    '{{WRAPPER}} .content-parent' => '--sf-banner-content-parent-align: {{VALUE}};'
                ],
                'render_type' => 'template',
            ]
        );

        $this->add_control(
            'behavior_separator',
            [
                'type' => \Elementor\Controls_Manager::DIVIDER,
                'style' => 'solid',
            ]
        );

        $this->add_control(
            'behavior_section_heading',
            [
                'type' => \Elementor\Controls_Manager::RAW_HTML,
                'raw' => '<strong style="font-size: 14px; color: #fff;">Behavior Settings</strong>',
            ]
        );

        $this->add_control(
            'sf_banner_enable_link',
            [
                'label' => esc_html__('Enable Link', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'sf-widget'),
                'label_off' => esc_html__('No', 'sf-widget'),
                'return_value' => 'yes',
                'default' => 'no',

            ]
        );

        //Banner Link
        $this->add_control(
            'banner_link',
            [
                'label' => esc_html__('Banner Link', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::URL,
                'placeholder' => esc_html__('https://your-site.com', 'sf-widget'),
                'default' => [
                    'url' => '',
                ],
                'show_external' => true,
                'condition' => ['sf_banner_enable_link' => 'yes'],


            ]
        );


        $this->add_control(
            'auto_hide',
            [
                'label' => esc_html__('Auto Hide', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'sf-widget'),
                'label_off' => esc_html__('No', 'sf-widget'),
                'return_value' => 'yes',
                'default' => 'no',

            ]
        );

        $this->add_control(
            'hide_delay',
            [
                'label' => esc_html__('Hide After (seconds)', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 30,
                'default' => 3,
                'condition' => [
                    'auto_hide' => 'yes',
                ],
            ]
        );

        $this->add_responsive_control(
            'hide_button_mobile',
            [
                'label' => esc_html__('Hide Banner', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Hide', 'sf-widget'),
                'label_off' => esc_html__('Show', 'sf-widget'),
                'return_value' => 'yes',
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .custom-banner' => 'display: none; visibility: hidden; height: 0; overflow: hidden;',
                ],

            ]
        );

        $this->end_controls_section();

        $this->start_controls_section('icon_section', [
            'label' => esc_html__('Icon / Avatar', 'sf-widget'),
        ]);

        $this->add_control(
            'sf_icon_toogle',
            [
                'label' => esc_html__('Show Icon/Avatar', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Show', 'sf-widget'),
                'label_off' => esc_html__('Hide', 'sf-widget'),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $this->add_control(
            'icon_type',
            [
                'label' => esc_html__('Type', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'icon' => esc_html__('Icon/SVG', 'sf-widget'),
                    'avatar' => esc_html__('Image', 'sf-widget'),
                ],
                'default' => 'icon',
                'condition' => ['sf_icon_toogle' => 'yes'],
            ]
        );

        $this->add_control(
            'promo_icon',
            [
                'label' => esc_html__('Icon', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::ICONS,
                'fa4compatibility' => 'icon',
                'skin' => 'inline',
                'label_block' => false,
                'render_type' => 'template',
                'default' => [
                    'value' => 'eicon-flash',
                    'library' => 'elementor-icons',
                ],
                'skin_settings' => [
                    'inline' => [
                        'none' => [
                            'label' => 'Default',
                            'icon' => 'eicon-flash',
                        ],
                        'icon' => [
                            'icon' => 'eicon-star',
                        ],
                    ],
                ],
                'recommended' => [
                    'fa-regular' => [
                        'bolt',
                    ],
                    'fa-solid' => [
                        'bolt',
                        'flash',
                    ],
                ],
                'condition' => ['icon_type' => 'icon', 'sf_icon_toogle' => 'yes'],
            ]
        );

        $this->add_control(
            'avatar_group',
            [
                'label' => esc_html__('Profile Images', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => [
                    [
                        'name' => 'image',
                        'label' => esc_html__('Image', 'sf-widget'),
                        'type' => \Elementor\Controls_Manager::MEDIA,
                        'default' => [
                            'url' => \Elementor\Utils::get_placeholder_image_src(),
                        ],
                    ],
                ],
                'default' => [
                    [
                        'image' => [
                            'url' => \Elementor\Utils::get_placeholder_image_src(),
                        ],
                    ],
                ],
                'title_field' => 'Click Here To Select Image',
                'condition' => [
                    'icon_type' => 'avatar',
                    'sf_icon_toogle' => 'yes'
                ],
            ]
        );

        $this->add_control(
            'sf-icon-color',
            [
                'label' => esc_html__('icon color', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .content-parent .promo-icon i' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .content-parent .promo-icon > svg *' => 'background-color:{{VALUE}};padding:20px;fill: {{VALUE}};',
                ],
                'condition' => ['sf_icon_toogle' => 'yes', 'icon_type' => 'icon',],
            ]
        );

        $this->add_responsive_control(
            'icon_size',
            [
                'label' => esc_html__('Icon Size', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', 'rem'],
                'range' => [
                    'px' => ['min' => 1, 'max' => 1000],
                ],
                'default' => ['unit' => 'px', 'size' => ''],
                'selectors' => [
                    '{{WRAPPER}} .promo-icon svg, {{WRAPPER}} .promo-icon i' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
                'condition' => ['sf_icon_toogle' => 'yes'],
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'banner_description',
            [
                'label' => esc_html__('Description', 'sf-widget'),
            ]
        );
        $this->add_control(
            'description_text',
            [
                'label' => esc_html__('Text', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => 'Beta is live! Unlock special pricing before the curtain lifts.',
            ]
        );

        $this->add_responsive_control(
            'sf_banner_description_width',
            [
                'label' => esc_html__('Description Width', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%', 'em', 'vw'],
                'default' => [

                    'unit' => 'px',
                ],
                'range' => [
                    'px' => ['min' => 50, 'max' => 1000, 'step' => 1],
                    '%' => ['min' => 10, 'max' => 100, 'step' => 1],
                    'em' => ['min' => 5, 'max' => 50, 'step' => 0.5],
                    'vw' => ['min' => 10, 'max' => 100, 'step' => 1],
                ],
                'selectors' => [
                    '{{WRAPPER}}' => '--sf-banner-description-width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'sf_description_typography',
                'label' => esc_html__('Description Typography', 'sf-widget'),
                'selector' => '{{WRAPPER}} .description',
                'fields_options' => [
                    'typography' => [
                        'default' => 'custom',
                    ],
                ],
            ]
        );

        $this->add_control(
            'sf_description_alignment',
            [
                'label' => esc_html__('Text Alignment', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'left' => ['title' => esc_html__('Left'), 'icon' => 'eicon-text-align-left'],
                    'center' => ['title' => esc_html__('Center'), 'icon' => 'eicon-text-align-center'],
                    'right' => ['title' => esc_html__('Right'), 'icon' => 'eicon-text-align-right'],
                ],
                'default' => 'left',
                'selectors' => [
                    '{{WRAPPER}} .description' => 'text-align: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'description_tag',
            [
                'label' => esc_html__('Description Tag', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'p',
                'options' => [
                    'h1' => 'H1',
                    'h2' => 'H2',
                    'h3' => 'H3',
                    'h4' => 'H4',
                    'h5' => 'H5',
                    'h6' => 'H6',
                    'p' => 'Paragraph',
                    'span' => 'Span',
                    'div' => 'Div',
                ],
            ]
        );

        $this->end_controls_section();


        $this->start_controls_section(
            'sf_banner_dismiss_icon',
            [
                'label' => esc_html__('Dismiss Icon', 'sf-widget'),
                'condition' => [
                    'sf-banner-mode-select' => 'toast',
                ],
            ]
        );

        $this->add_control(
            'show_dismiss_icon',
            [
                'label' => esc_html__('Show Dismiss Icon', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'sf-widget'),
                'label_off' => esc_html__('No', 'sf-widget'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'dismiss_icon',
            [
                'label' => esc_html__('List Icon/SVG', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::ICONS,
                'default' => [
                    'value' => 'eicon-close',
                    'library' => 'e-icon',
                ],
                'condition' => [
                    'show_dismiss_icon' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'dismiss_position',
            [
                'label' => esc_html__('Dismiss Icon Position', 'your-plugin'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'top-right' => esc_html__('Top Right', 'your-plugin'),
                    'center' => esc_html__('Center', 'your-plugin'),
                ],
                'default' => 'center',
                'condition' => [
                    'show_dismiss_icon' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'dismiss_color',
            [
                'label' => esc_html__('Color', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .my-banner__dismiss i, {{WRAPPER}} .my-banner__dismiss > svg *' => 'color: {{VALUE}}; fill: {{VALUE}};',
                ],
                'condition' => [
                    'show_dismiss_icon' => 'yes',
                ],
            ]
        );

        $this->add_responsive_control(
            'dismiss_size',
            [
                'label' => esc_html__('Size', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => ['px' => ['min' => 10, 'max' => 40]],
                'selectors' => [
                    '{{WRAPPER}} .my-banner__dismiss svg, {{WRAPPER}} .my-banner__dismiss i' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'show_dismiss_icon' => 'yes',
                ],
            ]
        );

        $this->end_controls_section();
       
        //Content Tab Controls ENDS




        //Style Tab Controls Starts
        $this->start_controls_section(
            'sf-notification-style-tab',
            [
                'label' => esc_html__('Banner Background Style', 'sf-widget'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );


        // Width Control
        $this->add_responsive_control(
            'banner_width',
            [
                'label' => esc_html__('Width', 'sf-widgets'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%', 'vw', 'rem', 'em'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 2000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                    'vw' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                    'rem' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 0.1,
                    ],
                    'em' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 0.1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .custom-banner' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );


        //Banner Padding
        $this->add_responsive_control(
            'banner_padding',
            [
                'label' => esc_html__('Padding', 'sf-widgets'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .custom-banner' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );



        //Solid BG Color
        $this->add_control(
            'sf-banner-solid-color',
            [
                'label' => esc_html__('Solid Background Color', 'sf-widgets'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => ['{{WRAPPER}} .custom-banner' => '--sf-banner-solid-bg: {{VALUE}};'],
                'render_type' => 'template',

            ]
        );

        //Gradient BG Color
        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name' => 'banner_background',
                'label' => esc_html__('Background Sasi', 'sf-widget'),
                'types' => ['gradient'],
                'selector' => '{{WRAPPER}} .custom-banner',

            ]
        );




        $this->end_controls_section();

        $this->start_controls_section(
            'section_border_style',
            [
                'label' => esc_html__('Border Style', 'sf-widget'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,

            ]
        );
        // Border Color Type (Solid or Gradient)
        $this->add_control(
            'border_color_type',
            [
                'label' => esc_html__('Border Color Type', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'solid' => esc_html__('Solid Border', 'sf-widget'),
                    'gradient' => esc_html__('Gradient Border', 'sf-widget'),
                ],
                'render_type' => 'template',
                'default' => 'solid',
            ]
        );

        // Border Style
        $this->add_control(
            'border_style',
            [
                'label' => esc_html__('Border Style', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'solid' => esc_html__('Solid', 'sf-widget'),
                    'dashed' => esc_html__('Dashed', 'sf-widget'),
                    'dotted' => esc_html__('Dotted', 'sf-widget'),
                    'double' => esc_html__('Double', 'sf-widget'),
                ],
                'default' => 'solid',
                'selectors' => [
                    '{{WRAPPER}} .custom-banner' => 'border-style: {{VALUE}};',
                ],
                'condition' => [
                    'border_color_type' => 'solid',
                ],
            ]
        );

           // Solid Color Picker
        $this->add_control(
            'border_color_solid',
            [
                'label' => esc_html__('Border Color', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'condition' => [
                    'border_color_type' => 'solid',

                ],
                'selectors' => [
                    '{{WRAPPER}} .custom-banner' => '--sf-banner-border-color: {{VALUE}};',
                ],
            ]
        );


        // Border Width
        $this->add_control(
            'border_width',
            [
                'label' => esc_html__('Border Width', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .custom-banner' => '--sf-banner-solid-border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'border_color_type' => 'solid',
                ],
            ]
        );

        $this->add_responsive_control(
            'border_gradient_width',
            [
                'label' => esc_html__('Gradient Border Width', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .custom-banner' => '--sf-banner-border-gradient-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'border_color_type' => 'gradient',
                ],
            ]
        );

        // Border Radius
        $this->add_control(
            'border_radius',
            [
                'label' => esc_html__('Border Radius', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .custom-banner' => '--sf-banner-border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

     
        $this->add_control(
            'gradient_direction',
            [
                'label' => esc_html__('Gradient Direction', 'my-elementor-extension'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'to top right',
                'options' => [
                    'to left' => 'Left → Right',
                    'to right' => 'Right → Left',
                    'to top' => 'Bottom → Top',
                    'to bottom' => 'Top → Bottom',
                    'to top left' => 'Bottom-Right → Top-Left',
                    'to top right' => 'Bottom-Left → Top-Right',
                    'to bottom left' => 'Top-Right → Bottom-Left',
                    'to bottom right' => 'Top-Left → Bottom-Right',
                ],
                'selectors' => [
                    '{{WRAPPER}} .custom-banner' => '--sf-banner-border-gradient-direction: {{VALUE}};',
                ],
                'condition' => [
                    'border_color_type' => 'gradient',
                ],
            ]
        );



        $this->add_control(
            'gradient_border_info',
            [
                'type' => \Elementor\Controls_Manager::RAW_HTML,
                'raw' => '<strong style="font-size: 14px; color: #fff;">Choose Colors</strong>',
                'condition' => [
                    'border_color_type' => 'gradient',
                ],
            ]

        );

        $this->add_control(
            'banner-gradient_border_color_one',
            [
                'label' => esc_html__('Gradient Border 1st Color', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'condition' => [
                    'border_color_type' => 'gradient',

                ],
                'selectors' => [
                    '{{WRAPPER}} .custom-banner' => '--sf-banner-border-gradient-color-1: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'banner-gradient_border_color_two',
            [
                'label' => esc_html__('Gradient Border 2nd Color', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'condition' => [
                    'border_color_type' => 'gradient',

                ],
                'selectors' => [
                    '{{WRAPPER}} .custom-banner' => '--sf-banner-border-gradient-color-2: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'banner-gradient_border_color_three',
            [
                'label' => esc_html__('Gradient Border 3rd Color', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .custom-banner' => '--sf-banner-border-gradient-color-3: {{VALUE}};',
                ],
                'condition' => [
                    'border_color_type' => 'gradient',

                ],
            ]
        );

        $this->add_control(
            'gradient_border_color_three',
            [
                'label' => esc_html__('Gradient Border 3rd Color', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .custom-banner' => '--sf-banner-border-gradient-color-3: {{VALUE}};',
                ],
                'condition' => [
                    'border_color_type' => 'gradient',

                    'sf_mode_toggle_' => 'yes'
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'banner_description_style',
            [
                'label' => esc_html__('Description Styles', 'sf-widget'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'sf_description_color',
            [
                'label' => esc_html__('Description Color', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .description' => '--sf-banner-description-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'enable_description_text_gradient',
            [
                'label' => esc_html__('Enable Description Gradient Text', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'sf-widget'),
                'label_off' => esc_html__('No', 'sf-widget'),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $this->add_control(
            'description_text_gradient_color_one',
            [
                'label' => esc_html__('Gradient Color One', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'condition' => ['enable_description_text_gradient' => 'yes'],
                'selectors' => [
                    '{{WRAPPER}} .description-gradient' => '--description-gradient-one:{{VALUE}}',
                ],

            ]
        );

        $this->add_control(
            'description_text_gradient_color_two',
            [
                'label' => esc_html__('Gradient Color Two', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'condition' => ['enable_description_text_gradient' => 'yes'],
                'render_type' => 'ui',
                'selectors' => [
                    '{{WRAPPER}} .description-gradient' => '--description-gradient-two:{{VALUE}}',
                ],
            ]
        );

        $this->end_controls_section();


        //button
        $this->register_button_controls('btn_1_', '1');
        $this->register_button_controls('btn_2_', '2');

        $this->start_controls_section(
            'button_addition',
            [
                'label' => esc_html__('Button Controls', 'sf-widget'),
            ]
        );

        // Width Control for button-wrappers
        $this->add_responsive_control(
            'button_wrappers_width',
            [
                'label' => esc_html__('Button Wrapper Width', 'sf-widgets'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%', 'vw', 'rem', 'em'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                    'vw' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                    'rem' => [
                        'min' => 0,
                        'max' => 50,
                        'step' => 0.1,
                    ],
                    'em' => [
                        'min' => 0,
                        'max' => 50,
                        'step' => 0.1,
                    ],
                ],
                'default' => [
                    'unit' => '%',
                    'size' => 0, // Set to 0 to avoid overriding inline min-width unless specified
                ],
                'selectors' => [
                    '{{WRAPPER}} .button-wrappers' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'flex_direction',
            [
                'label' => esc_html__('Flex Direction', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'row',
                'options' => [
                    'row' => esc_html__('Row', 'sf-widget'),
                    'column' => esc_html__('Column', 'sf-widget'),
                ],
                'selectors' => [
                    '{{WRAPPER}} .button-wrappers' => 'flex-direction: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'justify_content',
            [
                'label' => esc_html__('Horizontal Alignment', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'flex-start',
                'options' => [
                    'flex-start' => esc_html__('Left', 'sf-widget'),
                    'center' => esc_html__('Center', 'sf-widget'),
                    'flex-end' => esc_html__('Right', 'sf-widget'),
                    'space-between' => esc_html__('Space Between', 'sf-widget'),
                    'space-around' => esc_html__('Space Around', 'sf-widget'),
                ],
                'condition' => [
                    'flex_direction' => 'row',
                ],
                'selectors' => [
                    '{{WRAPPER}} .button-wrappers' => 'justify-content: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'column_alignment',
            [
                'label' => esc_html__('Column Alignment', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'flex-start',
                'options' => [
                    'flex-start' => esc_html__('Top', 'sf-widget'),
                    'center' => esc_html__('Center', 'sf-widget'),
                    'flex-end' => esc_html__('Bottom', 'sf-widget'),
                ],
                'condition' => [
                    'flex_direction' => 'column',
                ],
                'selectors' => [
                    '{{WRAPPER}} .button-wrappers' => 'align-items: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'button_gap',
            [
                'label' => esc_html__('Gap Between Buttons', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                    'em' => [
                        'min' => 0,
                        'max' => 10,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .button-wrappers' => 'gap: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

    }

    protected function render()
    {
        echo '<div class="ekit-wid-con" >';
        $this->render_raw();
        echo '</div>';
    }

    protected function render_raw()
    {
        $settings = $this->get_settings_for_display();

        if (!empty($settings['sf-banner-mode-select'] === 'toast') && $settings['sf-banner-mode-select'] === 'toast') {
            wp_enqueue_script('notification-banner');
        }

        // 1. Mode class
        $mode_class = 'mode-' . ($settings['sf-banner-mode-select'] ?? 'toast');

        // 2. Background type class (already handled by prefix_class, but we’ll add manually for full control)
        $bg_type_class = $settings['sf-banner-mode-select'] . '-bg-' . ($settings['sf_background_type'] ?? 'solidcolor');

     

        // Combine all classes
        $final_classes = trim("custom-banner $mode_class $bg_type_class");

        // Toast mode
        $is_toast = $settings['sf-banner-mode-select'] === 'toast';
        $toast_class = $is_toast ? 'my-banner--toast' : '';
        $toast_data = 'data-toast-mode="' . ($is_toast ? 'true' : 'false') . '"';

        // Position & overlay
        $position_class = 'my-banner--dismiss-' . ($settings['dismiss_position'] ?? 'top-right');

        // Background style
        $background_style = '';
        if ($settings['sf_background_type'] === 'gradient' && !empty($settings['banner_background']['gradient'])) {
            $background_style = 'style="background: ' . esc_attr($settings['banner_background']['gradient']) . ';"';
        } elseif ($settings['sf_background_type'] === 'solidcolor' && !empty($settings['sf-banner-solid-color'])) {
            $background_style = 'style="background-color: ' . esc_attr($settings['sf-banner-solid-color']) . ';"';
        } elseif ($settings['sf_background_type'] === 'image' && !empty($settings['sf_notify_banner_background_image']['url'])) {
            $background_image = esc_url($settings['sf_notify_banner_background_image']['url']);
            $background_style = 'style="background-image: url(' . $background_image . '); background-size: cover; background-repeat: no-repeat;"';
        }

        // Link setup
        $link = $settings['banner_link']['url'] ?? '';
        $target = !empty($settings['banner_link']['is_external']) ? ' target="_blank" rel="noopener"' : '';
        // Inject CSS for full-width banner when link is enabled
        if ($link) {
            echo '<style>
            {{WRAPPER}} .custom-banner { width: 100%; }
            {{WRAPPER}} .banner-clickable
            </style>';
        }

        // Clickable wrapper
        if ($link) {
            echo '<a href="' . esc_url($link) . '" class="banner-clickable"' . $target . '>';
        }


        echo '<div class="' . $position_class . ' ' . esc_attr($final_classes) . '" '
            . $background_style . ' '
            . $toast_data . ' '
            . 'data-auto-hide="' . ($settings['auto_hide'] === 'yes' ? 'true' : 'false') . '" '
            . 'data-hide-delay="' . esc_attr($settings['hide_delay']) . '">';

        echo '<div class="content-parent">';

        // Icon or avatar group
        if ($settings['icon_type'] === 'icon') {
            $icon = !empty($settings['promo_icon']['value']) ? $settings['promo_icon'] : [
                'value' => 'eicon-flash',
                'library' => 'elementor-icons',
            ];

            echo '<span class="promo-icon">';
            \Elementor\Icons_Manager::render_icon($icon, ['aria-hidden' => 'true']);
            echo '</span>';
        }
        $avatars = $settings['avatar_group'] ?? [];
        if (!empty($avatars)) {
            echo '<div class="promo-icon-group">';
            foreach ($avatars as $avatar) {
                $img_url = $avatar['image']['url'] ?? '';
                if ($img_url) {
                    echo '<img src="' . esc_url($img_url) . '" alt="" class="promo-icon-avatar">';
                }
            }
            echo '</div>';
        }

        // Description
        $desc_tag = $settings['description_tag'] ?? 'p';
        $desc_text = $settings['description_text'] ?? '';
        if (!empty($desc_text)) {
            $desc_class = $settings['enable_description_text_gradient'] === 'yes' ? 'description description-gradient' : 'description';
            echo '<' . esc_attr($desc_tag) . ' class="' . esc_attr($desc_class) . '">' . esc_html($desc_text) . '</' . esc_attr($desc_tag) . '>';
        }

        // Button
        echo '<div class="button-wrappers ekit-btn-wraper" style="display:flex;min-width: fit-content">';
        $this->render_button('btn_1_');
        $this->render_button('btn_2_');
        echo '</div>';

        echo '</div>'; // .content-parent

        // Dismiss icon
        if ($settings['sf-banner-mode-select'] === 'toast' && !empty($settings['dismiss_icon']['value'])) {
            $dismiss_icon = !empty($settings['dismiss_icon']['value']) ? $settings['dismiss_icon'] : [
                'value' => 'eicon-close',
                'library' => 'elementor-icons',
            ];

            echo '<span class="sf-icon-wrapper my-banner__dismiss banner-dismiss-trigger">';
            \Elementor\Icons_Manager::render_icon($dismiss_icon, ['aria-hidden' => 'true']);
            echo '</span>';
        }

        echo '</div>'; // .custom-banner
        if ($link) {
            echo '</a>';
        }
    }
}
