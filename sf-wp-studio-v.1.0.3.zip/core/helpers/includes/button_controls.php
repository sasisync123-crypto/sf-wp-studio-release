<?php
// namespace SFWPStudio\Core\Helpers\Includes;

use Elementor\Controls_Manager;
use Elementor\Repeater;

function ekit_button_controls( $widget, $enable_btn = false ) {
    
    $widget->start_controls_section(
        'ekit_btn_section_content',
        [
            'label' => esc_html__('SF Button', 'elementskit-lite'),
        ]
    );

    $widget->add_control(
        'show_button',
        [
            'label' => esc_html__( 'Enable Button', 'elementskit-lite' ),
            'type' => \Elementor\Controls_Manager::SWITCHER,
            'label_on' => esc_html__( 'Show', 'elementskit-lite' ),
            'label_off' => esc_html__( 'Hide', 'elementskit-lite' ),
            'default' => $enable_btn,
        ]
    );

    // Repeater definition
    $repeater = new Repeater();

    // Label
    $repeater->add_control(
        'ekit_btn_text',
        [
            'label' => esc_html__('Label', 'elementskit-lite'),
            'type' => Controls_Manager::TEXT,
            'default' => esc_html__('Learn more', 'elementskit-lite'),
            'placeholder' => esc_html__('Learn more', 'elementskit-lite'),
            'dynamic' => ['active' => true]
        ]
    );

    $repeater->add_control(
        'ekit_item_opacity_toggle',
        [
            'label' => esc_html__('Disable', 'elementskit-lite'),
            'type' => \Elementor\Controls_Manager::SWITCHER,
            'label_on' => esc_html__('Yes', 'elementskit-lite'),
            'label_off' => esc_html__('No', 'elementskit-lite'),
            'return_value' => 'yes',
            'default' => '',
            'selectors_dictionary' => [
                'yes' => 'opacity: 0.5;',
                '' => '',
            ],
            'selectors' => [
                '{{WRAPPER}} {{CURRENT_ITEM}}' => '{{VALUE}}',
            ],
        ]
    );

    //start
    $repeater->add_control(
        'ekit_icon_box_button_style',
        [
            'label' => esc_html__('Button Style', 'elementskit'),
            'type' => \Elementor\Controls_Manager::SELECT,
            'default' => 'Flat',
            'options' => [
                'Flat'  => esc_html__('Flat', 'elementskit-lite'),
                'Outline'   => esc_html__('Outline', 'elementskit-lite'),
                'Stacked' => esc_html__('Stacked', 'elementskit-lite'),
            ],
            'selectors' => [
                '{{WRAPPER}} {{CURRENT_ITEM}}' => '{{VALUE}}',
                '{{WRAPPER}} {{CURRENT_ITEM}} > i' => '{{VALUE}}',
                '{{WRAPPER}} {{CURRENT_ITEM}} > svg' => '{{VALUE}}',
            ]
        ]
    );

    //flat
    $repeater->add_control(
        'ekit_icon_box_flat_variant',
        [
            'label' => esc_html__('Flat Variant', 'elementskit'),
            'type' => \Elementor\Controls_Manager::SELECT,
            'default' => 'primary',
            'options' => [
                'primary'   => esc_html__('Primary', 'elementskit-lite'),
                'secondary' => esc_html__('Secondary', 'elementskit-lite'),
                'white'     => esc_html__('White', 'elementskit-lite'),
                'black'     => esc_html__('Black', 'elementskit-lite'),
                'accent'    => esc_html__('Accent', 'elementskit-lite'),
            ],
            'selectors_dictionary' => [
                'primary' => 'background-color: var(--e-global-color-primary);  border: none;',
                'secondary' => 'background-color: var(--e-global-color-secondary); border: none;',
                'white' => 'background-color: var(--e-global-color-light);   border: none;',
                'black' => 'background-color: var(--e-global-color-light); color:  border: none;',
                'accent' => 'background-color: var(--e-global-color-accent);  border: none;',
            ],
            'hover_selectors_dictionary' => [
                'primary' => 'background-color: var(--e-global-color-secondary); ',
                'secondary' =>'background-color: var(--e-global-color-secondary); ',
                'white' => 'background-color: var(--e-global-color-secondary);  ',
                'black' => 'background-color: var(--e-global-color-secondary); ',
                'accent' => 'background-color: var(--e-global-color-secondary); ',
            ],
            'selectors' => [
                '{{WRAPPER}} {{CURRENT_ITEM}}' => '{{VALUE}}',
                // '{{WRAPPER}} {{CURRENT_ITEM}} > i' => '{{VALUE}}',
                // '{{WRAPPER}} {{CURRENT_ITEM}} > svg' => '{{VALUE}}',
                '{{WRAPPER}} {{CURRENT_ITEM}}:hover' => 'color: var(--e-global-color-light)',
            ],
            'condition' => [
                'ekit_icon_box_button_style' => 'Flat'
            ],
        ]
    );

    // Stacked Variant Control
    $repeater->add_control(
        'ekit_icon_box_stacked_variant',
        [
            'label' => esc_html__('Stacked Variant', 'elementskit'),
            'type' => \Elementor\Controls_Manager::SELECT,
            'default' => 'primary',
            'options' => [
                'primary'   => esc_html__('Primary', 'elementskit-lite'),
                'secondary' => esc_html__('Secondary', 'elementskit-lite'),
                'black'     => esc_html__('Black', 'elementskit-lite'),
                'accent'    => esc_html__('Accent', 'elementskit-lite'),
            ],
            'selectors_dictionary' => [
                'primary'   => 'background-color: transparent; color: var(--e-global-color-primary);',
                'secondary' => 'background-color: transparent; color: var(--e-global-color-secondary);',
                'black'     => 'background-color: transparent; color: var(--e-global-color-light);',
                'accent'    => 'background-color: transparent; color: var(--e-global-color-accent);',
            ],
            'selectors' => [
                '{{WRAPPER}} {{CURRENT_ITEM}}' => '{{ekit_icon_box_stacked_variant}}',
                '{{WRAPPER}} {{CURRENT_ITEM}}:hover' => 'color: var(--e-global-color-light);',
            ],
            'condition' => [
                'ekit_icon_box_button_style' => 'Stacked'
            ],
        ]
    );

    // Outline Variant Control
    
    $repeater->add_control(
        'ekit_icon_box_outline_variant',
        [
            'label' => esc_html__('Outline Variant', 'elementskit'),
            'type' => \Elementor\Controls_Manager::SELECT,
            'default' => 'primary',
            'options' => [
                'primary'   => esc_html__('Primary', 'elementskit-lite'),
                'secondary' => esc_html__('Secondary', 'elementskit-lite'),
                'black'     => esc_html__('Black', 'elementskit-lite'),
                'accent'    => esc_html__('Accent', 'elementskit-lite'),
            ],
            'selectors_dictionary' => [
                'primary'   => 'background-color: transparent; border-width: var(--ekit-border-width); border-style: var(--ekit-border-style); border-color: var(--e-global-color-primary); color: var(--e-global-color-primary);',

                'secondary' => 'background-color: transparent; border-width: var(--ekit-border-width); border-style: var(--ekit-border-style); border-color: var(--e-global-color-secondary); color: var(--e-global-color-secondary);',

                'black'     => 'background-color: transparent; border-width: var(--ekit-border-width); border-style: var(--ekit-border-style); border-color: var(--e-global-color-light); color: var(--e-global-color-light);',
                
                'accent'    => 'background-color: transparent; border-width: var(--ekit-border-width); border-style: var(--ekit-border-style); border-color: var(--e-global-color-accent); color: var(--e-global-color-primary);',
            ],
            'selectors' => [
                '{{WRAPPER}} {{CURRENT_ITEM}}' => '{{VALUE}}',
                '{{WRAPPER}} {{CURRENT_ITEM}}:hover' => 'border-color: transparent; color: var(--e-global-color-light);',
            ],
            'condition' => [
                'ekit_icon_box_button_style' => 'Outline'
            ],
        ]
    );

    //end

    // URL
    $repeater->add_control(
        'ekit_btn_url',
        [
            'label' => esc_html__('URL', 'elementskit-lite'),
            'type' => Controls_Manager::URL,
            'placeholder' => esc_url('https://wpmet.com'),
            'dynamic' => ['active' => true],
            'default' => [
                'url' => '#',
            ],
        ]
    );

    // Icon switch
    $repeater->add_control(
        'ekit_btn_icons__switch',
        [
            'label' => esc_html__('Add icon?', 'elementskit-lite'),
            'type' => Controls_Manager::SWITCHER,
            'default' => 'no',
            'label_on' => esc_html__('Yes', 'elementskit-lite'),
            'label_off' => esc_html__('No', 'elementskit-lite'),
        ]
    );

    // Icon picker
    $repeater->add_control(
        'ekit_btn_icons',
        [
            'label' => esc_html__('Icon', 'elementskit-lite'),
            'type' => Controls_Manager::ICONS,
            'fa4compatibility' => 'ekit_btn_icon',
            'label_block' => true,
            'default' => [
                'value' => 'fas fa-angle-down',
                'library' => 'fa-solid',
            ],
            'condition' => [
                'ekit_btn_icons__switch' => 'yes',
            ],
        ]
    );

    // Icon position
    $repeater->add_control(
        'ekit_btn_icon_align',
        [
            'label' => esc_html__('Icon Position', 'elementskit-lite'),
            'type' => Controls_Manager::SELECT,
            'default' => 'right',
            'options' => [
                'left' => esc_html__('Before', 'elementskit-lite'),
                'right' => esc_html__('After', 'elementskit-lite'),
            ],
            'condition' => [
                'ekit_btn_icons__switch' => 'yes',
            ],
        ]
    );

    // Icon size
    $repeater->add_responsive_control(
        'ekit_btn_normal_icon_font_size',
        [
            'label' => esc_html__('Icon Size', 'elementskit-lite'),
            'type' => Controls_Manager::SLIDER,
            'size_units' => ['px', 'em', 'rem'],
            'range' => [
                'px' => ['min' => 1, 'max' => 100],
            ],
            'default' => ['unit' => 'px', 'size' => 20],
            'selectors' => [
                '{{WRAPPER}} {{CURRENT_ITEM}} > :is(i, svg)' => 'font-size: {{SIZE}}{{UNIT}};',
            ],
            'condition' => [
                'ekit_btn_icons__switch' => 'yes',
            ],
        ]
    );

    //icon color
    $repeater->add_control(
        'ekit_btn_icon_color',
        [
            'label' => esc_html__('Icon Color', 'elementskit-lite'),
            'type' => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} {{CURRENT_ITEM}} > i' => 'color: {{VALUE}}; fill: {{VALUE}};',
                '{{WRAPPER}} {{CURRENT_ITEM}} > svg' => 'color: {{VALUE}}; fill: {{VALUE}};',
            ],
            'condition' => [
                'ekit_btn_icons__switch' => 'yes',
            ],
        ]
    );

    // Optional per-item class
    $repeater->add_control(
        'ekit_btn_class',
        [
            'label' => esc_html__('Class', 'elementskit-lite'),
            'type' => Controls_Manager::TEXT,
            'dynamic' => ['active' => true],
            'placeholder' => esc_html__('Class Name', 'elementskit-lite'),
        ]
    );

    // Optional per-item ID
    $repeater->add_control(
        'ekit_btn_id',
        [
            'label' => esc_html__('id', 'elementskit-lite'),
            'type' => Controls_Manager::TEXT,
            'dynamic' => ['active' => true],
            'placeholder' => esc_html__('ID', 'elementskit-lite'),
        ]
    );


    $repeater->add_control(
        'ekit_btn_section_settings',
        [
            'label' => esc_html__('Button Settings', 'elementskit-lite'),
            'type' => Controls_Manager::HEADING,
            'separator' => 'before',
        ]
    );

    // Typography
    $repeater->add_group_control(
        \Elementor\Group_Control_Typography::get_type(),
        [
            'name' => 'ekit_btn_typography',
            'selector' => '{{WRAPPER}} {{CURRENT_ITEM}}',
        ]
    );

    $repeater->add_control(
        'sf-button-size',
        [
            'label' => esc_html__('Button Size', 'elementskit'),
            'type' => \Elementor\Controls_Manager::SELECT,
            'default' => 'md',
            'options' => [
                'sm'  => esc_html__('Small', 'elementskit-lite'),
                'md' => esc_html__('Medium', 'elementskit-lite'),
                'lg'   => esc_html__('Large', 'elementskit-lite'),
            ],
            'selectors_dictionary' => [
                'sm' => 'padding:var(--sf-padding-sm);',
                'md' => 'padding:var(--sf-padding-md);',
                'lg' => 'padding:var(--sf-padding-lg);',
                
            ],
            'selectors' => [
                '{{WRAPPER}} {{CURRENT_ITEM}} ' => '{{VALUE}}',
            ]
        ]
    );

    //Font Size
    $repeater->add_responsive_control(
        'ekit_btn_normal_text_font_size',
        [
            'label' => esc_html__('Text Size', 'elementskit-lite'),
            'type' => Controls_Manager::SLIDER,
            'size_units' => ['px', 'em', 'rem'],
            'range' => [
                'px' => ['min' => 8, 'max' => 100],
                'em' => ['min' => 0.5, 'max' => 5],
                'rem' => ['min' => 0.5, 'max' => 5],
            ],
            'default' => [
                'unit' => 'px'
            ],
            'selectors' => [
                '{{WRAPPER}} {{CURRENT_ITEM}}' => 'font-size: {{SIZE}}{{UNIT}};',
            ],
        ]
    );

    // Text Shadow
    $repeater->add_group_control(
        \Elementor\Group_Control_Text_Shadow::get_type(),
        [
            'name' => 'ekit_btn_shadow',
            'selector' => '{{WRAPPER}} {{CURRENT_ITEM}}',
        ]
    );

    //Box Shadow
    $repeater->add_group_control(
        \Elementor\Group_Control_Box_Shadow::get_type(),
        [
            'name' => 'ekit_btn_box_shadow_group',
            'selector' => '{{WRAPPER}} {{CURRENT_ITEM}}',
        ]
    );

    // Width
    $repeater->add_responsive_control(
        'width',
        [
            'label' => esc_html__('Min Width', 'elementskit-lite'),
            'type' => \Elementor\Controls_Manager::SLIDER,
            'size_units' => ['px', '%'],
            'default' => [
                'unit' => 'px',
                'size' => 120,
            ],
            'selectors' => [
                '{{WRAPPER}} {{CURRENT_ITEM}}' => 'min-width: {{SIZE}}{{UNIT}}; width: auto;',
            ],
        ]
    );

    // Padding
    $repeater->add_responsive_control(
        'ekit_btn_text_padding',
        [
            'label' => esc_html__('Padding', 'elementskit-lite'),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => ['px', 'em', '%'],
            'selectors' => [
                '{{WRAPPER}} {{CURRENT_ITEM}}' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]
    );

    // Margin
    $repeater->add_responsive_control(
        'ekit_btn_text_margin',
        [
            'label' => esc_html__('Margin', 'elementskit-lite'),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => ['px', 'em', '%'],
            'selectors' => [
                '{{WRAPPER}} {{CURRENT_ITEM}}' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]
    );


    // Padding after icon (left align)
    $repeater->add_responsive_control(
        'ekit_btn_normal_icon_padding_left',
        [
            'label' => esc_html__('Add space after icon', 'elementskit-lite'),
            'type' => Controls_Manager::SLIDER,
            'size_units' => ['px'],
            'range' => ['px' => ['min' => 0, 'max' => 100, 'step' => 1]],
            'default' => ['unit' => 'px', 'size' => 10],
            'selectors' => [
                '{{WRAPPER}} {{CURRENT_ITEM}} > i, {{WRAPPER}} {{CURRENT_ITEM}} > svg' => 'margin-right: {{SIZE}}{{UNIT}};',
                '.rtl {{WRAPPER}} {{CURRENT_ITEM}} > i, .rtl {{WRAPPER}} {{CURRENT_ITEM}} > svg' => 'margin-left: {{SIZE}}{{UNIT}}; margin-right: 0;',
            ],
            'condition' => [
                'ekit_btn_icon_align' => 'left',
            ],
        ]
    );

    // Padding before icon (right align)
    $repeater->add_responsive_control(
        'ekit_btn_normal_icon_padding_right',
        [
            'label' => esc_html__('Add space before icon', 'elementskit-lite'),
            'type' => Controls_Manager::SLIDER,
            'size_units' => ['px'],
            'range' => ['px' => ['min' => 0, 'max' => 100, 'step' => 1]],
            'default' => ['unit' => 'px', 'size' => 10],
            'selectors' => [
                '{{WRAPPER}} {{CURRENT_ITEM}} > i, {{WRAPPER}} {{CURRENT_ITEM}} > svg' => 'margin-left: {{SIZE}}{{UNIT}};',
                '.rtl {{WRAPPER}} {{CURRENT_ITEM}} > i, .rtl {{WRAPPER}} {{CURRENT_ITEM}} > svg' => 'margin-left: 0; margin-right: {{SIZE}}{{UNIT}};',
            ],
            'condition' => [
                'ekit_btn_icon_align' => 'right',
            ],
        ]
    );

    // Vertical align
    $repeater->add_responsive_control(
        'ekit_btn_normal_icon_vertical_align',
        array(
            'label' => esc_html__('Move icon  Vertically', 'elementskit-lite'),
            'type' => Controls_Manager::SLIDER,
            'size_units' => array(
                'px',
                'em',
                'rem',
            ),
            'range' => [
                'px' => ['min' => -20, 'max' => 20],
                'em' => ['min' => -5, 'max' => 5],
                'rem' => ['min' => -5, 'max' => 5],
            ],
            'selectors' => array(
                '{{WRAPPER}} {{CURRENT_ITEM}} > i, {{WRAPPER}} {{CURRENT_ITEM}} > svg' => ' -webkit-transform: translateY({{SIZE}}{{UNIT}}); -ms-transform: translateY({{SIZE}}{{UNIT}}); transform: translateY({{SIZE}}{{UNIT}})',
            ),
        )
    );

// 		$repeater->add_control(
//             'ekit_btn_animation_section_settings',
//             [
//                 'label' => esc_html__('Animation Settings', 'elementskit-lite'),
//                 'type' => Controls_Manager::HEADING,
//                 'separator' => 'before',
//                 'condition' => [
//                     'ekit_btn_icons__switch' => 'yes',
//                     'ekit_btn_icon_align' => 'right',
//                 ]
//             ]
//         );
    
// 		 $repeater->add_control(
//             'ekit_btn_animation_section_settings',
//             [
//                 'label' => esc_html__('Animation Settings', 'elementskit-lite'),
//                 'type' => Controls_Manager::HEADING,
//                 'separator' => 'before',
//                 'condition' => [
//                     'ekit_icon_box_button_style' => 'Stacked',
//                 ]
//             ]
//         );

    $repeater->add_control(
        'ekit_btn_icons_hover_switch',
        [
            'label' => esc_html__('Hover Effect', 'elementskit-lite'),
            'type' => Controls_Manager::SWITCHER,
            'default' => 'No',
            'label_on' => esc_html__('Yes', 'elementskit-lite'),
            'label_off' => esc_html__('No', 'elementskit-lite'),
            'condition' => [
                'ekit_btn_icons__switch' => 'yes',
                'ekit_btn_icon_align' => 'right',
            ]
        ]
    );

    $repeater->add_control(
        'ekit_btn_icons_hover_underline_switch',
        [
            'label' => esc_html__('Hover Underline Effect', 'elementskit-lite'),
            'type' => Controls_Manager::SWITCHER,
            'default' => 'No',
            'label_on' => esc_html__('Yes', 'elementskit-lite'),
            'label_off' => esc_html__('No', 'elementskit-lite'),
            'condition' => [
                'ekit_icon_box_button_style' => 'Stacked',
            ]
        ]
    );

    $repeater->add_control(
        'ekit_btn_color_section_settings',
        [
            'label' => esc_html__('Color Settings', 'elementskit-lite'),
            'type' => Controls_Manager::HEADING,
            'separator' => 'before',
        ]
    );
    
    // Tabs: Normal / Hover
    $repeater->start_controls_tabs('ekit_btn_tabs_style');

    // Normal Tab
    $repeater->start_controls_tab(
        'ekit_btn_tabnormal',
        [
            'label' => esc_html__('Normal', 'elementskit-lite'),
        ]
    );

    $repeater->add_control(
        'ekit_btn_text_color',
        [
            'label' => esc_html__('Color', 'elementskit-lite'),
            'type' => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} {{CURRENT_ITEM}}' => 'color: {{VALUE}}; fill: {{VALUE}};',
            ],
        ]
    );

    $repeater->add_control(
        'ekit_btn_bg_color',
        [
            'label' => esc_html__('Background Color', 'elementskit-lite'),
            'type' => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} {{CURRENT_ITEM}}' => 'background-color: {{VALUE}};',
            ],
        ]
    );


    $repeater->end_controls_tab();

    // Hover Tab
    $repeater->start_controls_tab(
        'ekit_btn_tab_button_hover',
        [
            'label' => esc_html__('Hover', 'elementskit-lite'),
        ]
    );

    $repeater->add_control(
        'ekit_btn_hover_color',
        [
            'label' => esc_html__('Color', 'elementskit-lite'),
            'type' => \Elementor\Controls_Manager::COLOR,
            'default' => 'var(--e-global-color-text)',
            'selectors' => [
                '{{WRAPPER}} {{CURRENT_ITEM}}:hover' => 'color:var(--e-global-color-light); fill: {{VALUE}};',
            ],
        ]
    );

    $repeater->add_control(
        'ekit_btn_icon_hover_color',
        [
            'label' => esc_html__('Icon Color', 'elementskit-lite'),
            'type' => \Elementor\Controls_Manager::COLOR,
            'default' => 'var(--e-global-color-light)',
            'selectors' => [
                '{{WRAPPER}} {{CURRENT_ITEM}} > i:hover' => 'fill: {{VALUE}};',
                '{{WRAPPER}} {{CURRENT_ITEM}} > svg:hover' => 'fill: {{VALUE}};',
            ],
        ]
    );

    $repeater->add_control(
        'ekit_btn_bg_hover_color',
        [
            'label' => esc_html__('Background Color', 'elementskit-lite'),
            'type' => \Elementor\Controls_Manager::COLOR,
            'default' => 'var(--e-global-color-secondary)',
            'selectors' => [
                '{{WRAPPER}} {{CURRENT_ITEM}}:hover' => 'background-color: {{VALUE}};',
            ],
            'condition' => [
                'ekit_btn_icons_hover_underline_switch' => 'No',
            ]
        ]
    );

    $repeater->end_controls_tab();

    // End Tabs
    $repeater->end_controls_tabs();


    $repeater->add_control(
        'ekit_btn_border_section_settings',
        [
            'label' => esc_html__('Border Settings', 'elementskit-lite'),
            'type' => Controls_Manager::HEADING,
            'separator' => 'before',
        ]
    );

    $repeater->add_responsive_control(
        'ekit_btn_border_style',
        [
            'label' => esc_html_x('Border Type', 'Border Control', 'elementskit-lite'),
            'type' => Controls_Manager::SELECT,
            'options' => [
                'none' => esc_html__('None', 'elementskit-lite'),
                'solid' => esc_html_x('Solid', 'Border Control', 'elementskit-lite'),
                'double' => esc_html_x('Double', 'Border Control', 'elementskit-lite'),
                'dotted' => esc_html_x('Dotted', 'Border Control', 'elementskit-lite'),
                'dashed' => esc_html_x('Dashed', 'Border Control', 'elementskit-lite'),
                'groove' => esc_html_x('Groove', 'Border Control', 'elementskit-lite'),
            ],
            'default' => '',
            'selectors' => [
                '{{WRAPPER}} .elementskit-btn' => 'border-style: {{VALUE}};',
            ],
        ]
    );
    $repeater->add_responsive_control(
        'ekit_btn_border_dimensions',
        [
            'label' => esc_html_x('Border Width', 'Border Control', 'elementskit-lite'),
            'type' => Controls_Manager::DIMENSIONS,
            'condition' => [
                'ekit_btn_border_style!' => 'none'
            ],
            'selectors' => [
                '{{WRAPPER}} .elementskit-btn' => 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]
    );

    $repeater->add_responsive_control(
        'ekit_btn_border_radius_h',
        [
            'label' => esc_html__('Border Radius', 'elementskit-lite'),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => ['px', '%'],
            'selectors' => [
                '{{WRAPPER}} .elementskit-btn:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]
    );

    // Repeater field
    $widget->add_control(
        'ekit_btn_list',
        [
            'label' => esc_html__('Buttons', 'elementskit-lite'),
            'type' => Controls_Manager::REPEATER,
            'fields' => $repeater->get_controls(),
            'default' => [
                [
                    'ekit_btn_text' => esc_html__('Learn more', 'elementskit-lite'),
                    'ekit_btn_url' => ['url' => '#'],
                ],
            ],
            'title_field' => '{{{ ekit_btn_text }}}',
            'condition' => [
                'show_button' => 'yes',
            ],
        ]
    );

    // Keep your existing global alignment control as-is

    $widget->add_control(
        'ekit_btn_border_section_settings',
        [
            'label' => esc_html__('Other Settings', 'elementskit-lite'),
            'type' => Controls_Manager::HEADING,
            'separator' => 'before',
            'condition' => [
                'show_button' => 'yes',
            ],
        ]
    );

    $widget->add_responsive_control(
        'ekit_btn_align',
        [
            'label' => esc_html__('Text Alignment', 'elementskit-lite'),
            'type' => Controls_Manager::CHOOSE,
            'default' => 'center',
            'options' => [
                'left' => [
                    'title' => esc_html__('Left', 'elementskit-lite'),
                    'icon' => 'eicon-text-align-left',
                ],
                'center' => [
                    'title' => esc_html__('Center', 'elementskit-lite'),
                    'icon' => 'eicon-text-align-center',
                ],
                'right' => [
                    'title' => esc_html__('Right', 'elementskit-lite'),
                    'icon' => 'eicon-text-align-right',
                ],
            ],
            'selectors_dictionary' => [
                'left' => 'justify-content: flex-start;',
                'center' => 'justify-content: center;',
                'right' => 'justify-content: flex-end;',
            ],
            'prefix_class' => 'elementor-align-%s',
            'selectors' => [
                '{{WRAPPER}} .ekit-btn-wraper .elementskit-btn' => '{{VALUE}};',
            ],  			
            'condition' => [
                'show_button' => 'yes',
            ],
        ]
    );

    $widget->add_responsive_control(
        'ekit_btn_justifycontent',
        [
            'label' => esc_html__('Alignment', 'elementskit-lite'),
            'type' => Controls_Manager::CHOOSE,
            'default' => 'left',
            'options' => [
                'left' => [
                    'title' => esc_html__('Left', 'elementskit-lite'),
                    'icon' => 'eicon-text-align-left',
                ],
                'center' => [
                    'title' => esc_html__('Center', 'elementskit-lite'),
                    'icon' => 'eicon-text-align-center',
                ],
                'right' => [
                    'title' => esc_html__('Right', 'elementskit-lite'),
                    'icon' => 'eicon-text-align-right',
                ],
            ],
            'selectors_dictionary' => [
                'left' => 'justify-content: flex-start;',
                'center' => 'justify-content: center;',
                'right' => 'justify-content: flex-end;',
            ],
            'prefix_class' => 'elementor-align-%s',
            'selectors' => [
                '{{WRAPPER}} .ekit-btn-wraper' => '{{VALUE}};',
            ],
            'condition' => [
                'show_button' => 'yes',
            ],
        ]
    );

    $widget->add_responsive_control(
        'ekit_btn_wrapper_width',
        [
            'label' => esc_html__('Button Wrapper Width', 'elementskit-lite'),
            'type' => Controls_Manager::SLIDER,
            'size_units' => ['%', 'px', 'vw'],
            'default' => [
                'unit' => '%',
                'size' => 100,
            ],
            'range' => [
                '%' => [
                    'min' => 0,
                    'max' => 100,
                ],
                'px' => [
                    'min' => 0,
                    'max' => 2000,
                ],
                'vw' => [
                    'min' => 0,
                    'max' => 100,
                ],
            ],
            'selectors' => [
                '{{WRAPPER}} .ekit-btn-wraper' => 'width: {{SIZE}}{{UNIT}};',
            ],
            'condition' => [
                'show_button' => 'yes',
            ],
        ]
    );

    $widget->add_responsive_control(
        'ekit_btn_flex_direction',
        [
            'label' => esc_html__('Button Direction', 'elementskit-lite'),
            'type' => \Elementor\Controls_Manager::CHOOSE,
            'options' => [
                'row' => [
                    'title' => esc_html__('Row', 'elementskit-lite'),
                    'icon' => 'eicon-h-align-left',
                ],
                'row-reverse' => [
                    'title' => esc_html__('Row Reverse', 'elementskit-lite'),
                    'icon' => 'eicon-h-align-right',
                ],
                'column' => [
                    'title' => esc_html__('Column', 'elementskit-lite'),
                    'icon' => 'eicon-v-align-top',
                ],
                'column-reverse' => [
                    'title' => esc_html__('Column Reverse', 'elementskit-lite'),
                    'icon' => 'eicon-v-align-bottom',
                ],
            ],
            'default' => 'row',
            'tablet_default' => 'row',
            'mobile_default' => 'column',
            'selectors' => [
                '{{WRAPPER}} .ekit-btn-wraper' => 'display: flex; flex-direction: {{VALUE}};',
            ],
            'condition' => [
                'show_button' => 'yes',
            ],
        ]
    );


    $widget->add_responsive_control(
        'ekit_btn_gap',
        [
            'label' => esc_html__('Button Gap', 'elementskit-lite'),
            'type' => Controls_Manager::SLIDER,
            'size_units' => ['px', 'em', '%'],
            'range' => [
                'px' => [ 'min' => 0, 'max' => 100 ],
                'em' => [ 'min' => 0, 'max' => 10 ],
                '%'  => [ 'min' => 0, 'max' => 100 ],
            ],
            'default' => [
                'unit' => 'px',
                'size' => 16, // Desktop default
            ],
            'mobile_default' => [
                'unit' => 'px',
                'size' => 16,
            ],
            'selectors' => [
                '{{WRAPPER}} .ekit-btn-wraper' => 'gap: {{SIZE}}{{UNIT}};',
            ],
            'condition' => [
                'show_button' => 'yes',
            ],
        ]
    );

    $widget->add_responsive_control(
        'ekit_btn_wrapper_margin',
        [
            'label' => esc_html__('Wrapper Margin', 'elementor-kit'),
            'type' => \Elementor\Controls_Manager::DIMENSIONS,
            'size_units' => ['px', '%', 'em'],
            'default' => [
            'top' => '20',
            'right' => '0',
            'bottom' => '0',
            'left' => '0',
            'unit' => 'px',
            'isLinked' => false,
            ],
            'selectors' => [
            '{{WRAPPER}} .ekit-btn-wraper' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
            'condition' => [
                'show_button' => 'yes',
            ],
        ]
        );
        

    $widget->end_controls_section();

}