<?php
namespace SFWPStudio\Core\Helpers\Traits;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

trait ParaTrait {

    protected function register_para_controls( $enable_Para = "yes" ) {

        $this->start_controls_section(
            'sf_paragraph_content_section',
            [
                'label' => __('Paragraph', 'sf-widget'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'sf_paragraph_text_show',
            [
                'label' => esc_html__( 'Show Paragraph', 'sf-widget' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => $enable_Para,
            ]
        );

        // Text Control
        $this->add_control(
            'sf_paragraph_text',
            [
                'label' => __('Paragraph Text', 'sf-widget'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => __('Enter your paragraph text here.', 'sf-widget'),
                'condition' => [
                    'sf_paragraph_text_show' => 'yes',
                ],
            ]
        );

        $this->end_controls_section();

        // Style Section
        $this->start_controls_section(
            'sf_para_style_section',
            [
                'label' => __('Paragraph Style', 'sf-widget'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                'sf_paragraph_text_show' => 'yes',
            ],
            ],
        );
       
        // Typography Control
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'sf_paragraph_typography',
                'selector' => '{{WRAPPER}} .sf-custom-paragraph p',
            ]
        );
       
        // Text Color Control
        $this->add_control(
            'sf_paragraph_text_color',
            [
                'label' => __('Text Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .sf-custom-paragraph p' => 'color: {{VALUE}};',
                ],
            ]
        );
       
        // Background Color Control
        $this->add_control(
            'sf_paragraph_background_color',
            [
                'label' => __('Background Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .sf-custom-paragraph' => 'background-color: {{VALUE}};',
                ],
            ]
        );
       
        // Padding Control
        $this->add_responsive_control(
            'sf_paragraph_padding',
            [
                'label' => __('Padding', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .sf-custom-paragraph' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

		$this->add_responsive_control(
			'sf_paragraph_margin',
			[
				'label' => __('Margin', 'sf-widget'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors' => [
					'{{WRAPPER}} .sf-custom-paragraph' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
       
        $this->end_controls_section();
    }

    protected function render_para() {
        $settings = $this->get_settings_for_display();

        if ( !empty($settings['sf_paragraph_text']) && $settings['sf_paragraph_text_show'] === 'yes' ) {
            echo '<div class="sf-custom-paragraph"><p>' . wp_kses_post($settings['sf_paragraph_text']) . '</p></div>';
        }
    }
}