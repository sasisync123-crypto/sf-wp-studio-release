<?php
namespace SFWPStudio\Widgets;

if (!defined('ABSPATH'))
    exit;

use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Repeater;

if (!defined('ABSPATH'))
    exit;


class Avatar extends Widget_Base
{
    use \SFWPStudio\Core\Helpers\Traits\HeadingTrait;
    use \SFWPStudio\Core\Helpers\Traits\DescriptionTrait;
    use \SFWPStudio\Core\Helpers\Traits\ButtonTrait;

    public function get_name()
    {
        return 'sf-avatar';
    }

    public function get_title()
    {
        return __('SF Avatar', 'avatar-widget-plugin');
    }

    public function get_icon()
    {
        return 'sync-widget-icon eicon-tabs';
    }

    public function get_keywords()
    {
        return ['sf', 'avatar', 'profile'];
    }

  //SFWP CODE STARTS
    public function get_categories()
    {
        return ['syncfusion-widgets'];
    }

    public function is_dynamic_content(): bool
    {
        return false;
    }
    //SFWP CODE ENDS

    protected function _register_controls()
    {
        // AVATAR SECTION
        $this->start_controls_section(
            'section_content',
            [
                'label' => __('Avatar', 'elementor-avatar-widget'),
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'avatar_source',
            [
                'label' => __('Image Source', 'elementor-avatar-widget'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'upload' => __('Upload', 'elementor-avatar-widget'),
                    'url' => __('URL', 'elementor-avatar-widget'),
                ],
                'default' => 'upload',
            ]
        );

        $repeater->add_control(
            'avatar_image',
            [
                'label' => __('Avatar Image', 'elementor-avatar-widget'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'dynamic' => [
                    'active' => true,
                ],
                'condition' => [
                    'avatar_source' => 'upload',
                ],
            ]
        );

        $repeater->add_control(
            'avatar_url',
            [
                'label' => __('Avatar Image URL', 'elementor-avatar-widget'),
                'type' => Controls_Manager::TEXT,
                'placeholder' => __('https://example.com/avatar.jpg', 'elementor-avatar-widget'),
                'condition' => [
                    'avatar_source' => 'url',
                ],
            ]
        );

        $repeater->add_control(
            'avatar_link_enable',
            [
                'label' => __('Enable Link', 'elementor-avatar-widget'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('On', 'elementor-avatar-widget'),
                'label_off' => __('Off', 'elementor-avatar-widget'),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $repeater->add_control(
            'avatar_link_url',
            [
                'label' => __('Link URL', 'elementor-avatar-widget'),
                'type' => Controls_Manager::URL,
                'placeholder' => __('https://example.com', 'elementor-avatar-widget'),
                'condition' => [
                    'avatar_link_enable' => 'yes',
                ],
            ]
        );

        $repeater->add_control(
            'avatar_status',
            [
                'label' => __('Status Badge', 'elementor-avatar-widget'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'none' => __('None', 'elementor-avatar-widget'),
                    'online' => __('Online', 'elementor-avatar-widget'),
                    'offline' => __('Offline', 'elementor-avatar-widget'),
                    'busy' => __('Busy', 'elementor-avatar-widget'),
                ],
                'default' => 'none',
            ]
        );

        $repeater->add_control(
            'avatar_status_position',
            [
                'label' => __('Badge Position', 'elementor-avatar-widget'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'top-left' => __('Top Left', 'elementor-avatar-widget'),
                    'top-right' => __('Top Right', 'elementor-avatar-widget'),
                    'bottom-left' => __('Bottom Left', 'elementor-avatar-widget'),
                    'bottom-right' => __('Bottom Right', 'elementor-avatar-widget'),
                ],
                'default' => 'top-left',
                'condition' => [
                    'avatar_status!' => 'none',
                ],
            ]
        );

        $this->add_control(
            'avatars',
            [
                'label' => __('Avatar Image', 'elementor-avatar-widget'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'avatar_image' => ['url' => Utils::get_placeholder_image_src()],
                        'avatar_status' => 'none',
                        'avatar_status_position' => 'bottom-right',
                    ],
                    [
                        'avatar_image' => ['url' => Utils::get_placeholder_image_src()],
                        'avatar_status' => 'none',
                        'avatar_status_position' => 'bottom-right',
                    ],
                    [
                        'avatar_image' => ['url' => Utils::get_placeholder_image_src()],
                        'avatar_status' => 'none',
                        'avatar_status_position' => 'bottom-right',
                    ],
                ],
                'title_field' => '{{{ avatar_image.url }}}',
            ]
        );

        $this->add_control(
            'avatar_size',
            [
                'label' => __('Avatar Size', 'elementor-avatar-widget'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'xs' => __('Extra Small', 'elementor-avatar-widget'),
                    'sm' => __('Small', 'elementor-avatar-widget'),
                    'md' => __('Medium', 'elementor-avatar-widget'),
                    'lg' => __('Large', 'elementor-avatar-widget'),
                    'xl' => __('Extra Large', 'elementor-avatar-widget'),
                ],
                'default' => 'md',
            ]
        );

        $this->add_control(
            'avatar_overlap',
            [
                'label' => __('Avatar Gap', 'elementor-avatar-widget'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    's' => __('Small', 'elementor-avatar-widget'),
                    'm' => __('Medium', 'elementor-avatar-widget'),
                    'l' => __('Large', 'elementor-avatar-widget'),
                    'xl' => __('Extra Large', 'elementor-avatar-widget'),
                ],
                'default' => 'm',
            ]
        );

        $this->add_control(
            'avatar_shape',
            [
                'label' => __('Avatar Shape', 'elementor-avatar-widget'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'circle' => __('Circle', 'elementor-avatar-widget'),
                    'square' => __('Square', 'elementor-avatar-widget'),
                    'rounded' => __('Rounded Square', 'elementor-avatar-widget'),
                ],
                'default' => 'circle',
            ]
        );

        $this->end_controls_section();

        // Register Heading Controls
        $this->register_heading_controls();

        // Register Description Controls
        $this->register_description_controls();

        // CONTAINER STYLE SECTION
        $this->start_controls_section(
            'section_wrapper_style',
            [
                'label' => __('Container', 'elementor-avatar-widget'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'wrapper_background_color',
            [
                'label' => __('Background Color', 'elementor-avatar-widget'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .avatar-widget-wrapper' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'wrapper_background_image',
            [
                'label' => __('Background Image', 'elementor-avatar-widget'),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .avatar-widget-wrapper' => 'background-image: url({{URL}}); background-size: cover; background-position: center; background-repeat: no-repeat;',
                ],
            ]
        );

        $this->add_control(
            'wrapper_border_toggle',
            [
                'label' => __('Border', 'elementor-avatar-widget'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('On', 'elementor-avatar-widget'),
                'label_off' => __('Off', 'elementor-avatar-widget'),
                'return_value' => 'yes',
                'default' => '', // Switch OFF by default
                'selectors' => [
                    '{{WRAPPER}} .avatar-widget-wrapper' => '{{VALUE}} === "yes" ? "border-style: {{wrapper_border_style.VALUE}}" : "border-style: none"',
                ],
            ]
        );

        $this->add_responsive_control(
            'wrapper_border_width',
            [
                'label' => __('Border Width', 'elementor-avatar-widget'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 20,
                    ],
                ],
                'default' => [
                    'size' => 1,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .avatar-widget-wrapper' => 'border-width: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'wrapper_border_toggle' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'wrapper_border_style',
            [
                'label' => __('Border Style', 'elementor-avatar-widget'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'solid' => __('Solid', 'elementor-avatar-widget'),
                    'dashed' => __('Dashed', 'elementor-avatar-widget'),
                    'dotted' => __('Dotted', 'elementor-avatar-widget'),
                    'double' => __('Double', 'elementor-avatar-widget'),
                    'none' => __('None', 'elementor-avatar-widget'),
                ],
                'default' => 'solid',
                'selectors' => [
                    '{{WRAPPER}} .avatar-widget-wrapper' => 'border-style: {{VALUE}};',
                ],
                'condition' => [
                    'wrapper_border_toggle' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'wrapper_border_color',
            [
                'label' => __('Border Color', 'elementor-avatar-widget'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#000000',
                'selectors' => [
                    '{{WRAPPER}} .avatar-widget-wrapper' => 'border-color: {{VALUE}};',
                ],
                'condition' => [
                    'wrapper_border_toggle' => 'yes',
                ],
            ]
        );

        $this->add_responsive_control(
            'wrapper_border_radius',
            [
                'label' => __('Border Radius', 'elementor-avatar-widget'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .avatar-widget-wrapper' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'wrapper_border_toggle' => 'yes',
                ],
            ]
        );

        $this->add_responsive_control(
            'wrapper_padding',
            [
                'label' => __('Padding', 'elementor-avatar-widget'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'default' => [
                    'top' => 10,
                    'right' => 10,
                    'bottom' => 10,
                    'left' => 10,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .avatar-widget-wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'wrapper_margin',
            [
                'label' => __('Margin', 'elementor-avatar-widget'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .avatar-widget-wrapper' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'wrapper_width',
            [
                'label' => __('Wrapper Width', 'elementor-avatar-widget'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['%'],
                'range' => [
                    '%' => [
                        'min' => 35,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => '%',
                    'size' => 40,
                ],
                'tablet_default' => [
                    'unit' => '%',
                    'size' => 100,
                ],
                'mobile_default' => [
                    'unit' => '%',
                    'size' => 100,
                ],
                'selectors' => [
                    '{{WRAPPER}} .avatar-widget-wrapper' => 'width: {{SIZE}}{{UNIT}} !important; box-sizing: border-box;',
                ],
            ]
        );

        $this->add_responsive_control(
            'content_wrapper_width',
            [
                'label' => __('Content Wrapper Width', 'elementor-avatar-widget'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['%'],
                'range' => [
                    '%' => [
                        'min' => 35,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => '%',
                    'size' => 100,
                ],
                'tablet_default' => [
                    'unit' => '%',
                    'size' => 100,
                ],
                'mobile_default' => [
                    'unit' => '%',
                    'size' => 100,
                ],
                'selectors' => [
                    '{{WRAPPER}} .avatar-text-wrapper, {{WRAPPER}} .avatar-text-after-wrapper' => 'width: {{SIZE}}{{UNIT}} !important; box-sizing: border-box;',
                ],
                'condition' => [
                    'show_title|show_description' => 'yes',
                ],
            ]
        );

        // Previous fix: Ensure .avatar-group-wrapper supports justify-content
        $this->add_control(
            'avatar_group_wrapper_layout',
            [
                'label' => __('Avatar Group Layout', 'elementor-avatar-widget'),
                'type' => \Elementor\Controls_Manager::HIDDEN,
                'default' => 'flex',
                'selectors' => [
                    '{{WRAPPER}} .avatar-group-wrapper' => 'display: flex; justify-content: inherit;',
                ],
            ]
        );

        // NEW: Control to ensure .avatar-widget supports justify-content
        $this->add_control(
            'avatar_widget_layout',
            [
                'label' => __('Avatar Widget Layout', 'elementor-avatar-widget'),
                'type' => \Elementor\Controls_Manager::HIDDEN,
                'default' => 'flex',
                'selectors' => [
                    '{{WRAPPER}} .avatar-widget' => 'width: 100%; justify-content: inherit;',
                ],
            ]
        );

        $this->end_controls_section();

        // AVATAR STYLE SECTION
        $this->start_controls_section(
            'section_avatar_style',
            [
                'label' => __('Avatar', 'elementor-avatar-widget'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'avatar_group_wrapper_width',
            [
                'label' => esc_html__('Avatar Width', 'elementor-avatar-widget'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['%'],
                'range' => [
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => '%',
                    'size' => 100,
                ],
                'tablet_default' => [
                    'unit' => '%',
                    'size' => 100,
                ],
                'mobile_default' => [
                    'unit' => '%',
                    'size' => 100,
                ],
                'selectors' => [
                    '{{WRAPPER}} .avatar-group-wrapper' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'avatar_padding',
            [
                'label' => __('Avatar Padding', 'elementor-avatar-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .avatar-image' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'avatar_margin',
            [
                'label' => __('Avatar Margin', 'elementor-avatar-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .avatar-image' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'avatar_horizontal_alignment',
            [
                'label' => __('Horizontal Alignment', 'elementor-avatar-widget'),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'flex-start' => [
                        'title' => __('Left', 'elementor-avatar-widget'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __('Center', 'elementor-avatar-widget'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'flex-end' => [
                        'title' => __('Right', 'elementor-avatar-widget'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'flex-start',
                'selectors' => [
                    '{{WRAPPER}} .avatar-group-wrapper' => 'justify-content: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'show_border',
            [
                'label' => __('Enable Border', 'elementor-avatar-widget'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'elementor-avatar-widget'),
                'label_off' => __('No', 'elementor-avatar-widget'),
                'return_value' => 'yes',
                'default' => 'No',
            ]
        );

        $this->add_control(
            'avatar_border_type',
            [
                'label' => __('Border Type', 'elementor-avatar-widget'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'solid' => __('Solid', 'elementor-avatar-widget'),
                    'dotted' => __('Dotted', 'elementor-avatar-widget'),
                    'dashed' => __('Dashed', 'elementor-avatar-widget'),
                ],
                'default' => 'solid',
                'condition' => [
                    'show_border' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'avatar_border_width',
            [
                'label' => __('Border Width', 'elementor-avatar-widget'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1px' => '1px',
                    '2px' => '2px',
                    'custom' => __('Custom', 'elementor-avatar-widget'),
                ],
                'default' => '2px',
                'condition' => [
                    'show_border' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'avatar_border_width_custom',
            [
                'label' => __('Custom Border Width', 'elementor-avatar-widget'),
                'type' => Controls_Manager::TEXT,
                'placeholder' => 'e.g. 3px or 0.2rem',
                'condition' => [
                    'show_border' => 'yes',
                    'avatar_border_width' => 'custom',
                ],
            ]
        );

        $this->add_control(
            'avatar_border_color',
            [
                'label' => __('Border Color', 'elementor-avatar-widget'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'primary' => __('Primary', 'elementor-avatar-widget'),
                    'grey' => __('Grey', 'elementor-avatar-widget'),
                    'black' => __('Black', 'elementor-avatar-widget'),
                    'custom' => __('Custom', 'elementor-avatar-widget'),
                ],
                'default' => 'primary',
                'condition' => [
                    'show_border' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'avatar_border_color_custom',
            [
                'label' => __('Custom Border Color', 'elementor-avatar-widget'),
                'type' => Controls_Manager::COLOR,
                'default' => '#ff0000',
                'condition' => [
                    'show_border' => 'yes',
                    'avatar_border_color' => 'custom',
                ],
            ]
        );

        $this->add_control(
            'avatar_shadow',
            [
                'label' => __('Avatar Shadow', 'elementor-avatar-widget'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'none' => __('None', 'elementor-avatar-widget'),
                    'soft' => __('Soft', 'elementor-avatar-widget'),
                    'medium' => __('Medium', 'elementor-avatar-widget'),
                    'strong' => __('Strong', 'elementor-avatar-widget'),
                ],
                'default' => 'soft',
            ]
        );

        $this->add_control(
            'avatar_hover_effect',
            [
                'label' => __('Hover Effect', 'elementor-avatar-widget'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'none' => __('None', 'elementor-avatar-widget'),
                    'scale' => __('Scale', 'elementor-avatar-widget'),
                ],
                'default' => 'none',
            ]
        );

        $this->end_controls_section();

        // Register Heading Style Controls
        $this->register_heading_style_controls();

        // Register Description Style Controls
        $this->register_description_style_controls();
    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();

        // Set outer-wrapper width to 100% and avatar-widget-wrapper width in pixels
        echo '<div class="avatar-outer-wrapper" style="width: 100%; margin: 0 auto;">';
        echo '<div class="avatar-widget-wrapper" style="display: flex; flex-direction: column; height: 100%;">';

        // Render heading above
        if ($settings['title_position'] === 'above' && $settings['show_title'] === 'yes' && !empty($settings['avatar_heading'])) {
            $this->render_heading($settings, 'above');
        }

        // Render description above
        if (isset($settings['description_position']) && $settings['description_position'] === 'above' && $settings['show_description'] === 'yes' && !empty($settings['description_text'])) {
            $this->render_description($settings, 'above');
        }

        echo '<div class="avatar-widget" style="display: flex; flex-direction: row; gap: 12px; align-items: center;">';

        // Wrap heading and description in a single div when 'before'
        if (in_array($settings['title_position'], ['before']) || (isset($settings['description_position']) && in_array($settings['description_position'], ['before']))) {
            echo '<div class="avatar-text-wrapper" style="display: flex; flex-direction: column; gap: 8px;">';
            if ($settings['title_position'] === 'before' && $settings['show_title'] === 'yes' && !empty($settings['avatar_heading'])) {
                $this->render_heading($settings, 'before');
            }
            if (isset($settings['description_position']) && $settings['description_position'] === 'before' && $settings['show_description'] === 'yes' && !empty($settings['description_text'])) {
                $this->render_description($settings, 'before');
            }
            echo '</div>';
        }

        // Render avatar group
        echo '<div class="avatar-group-wrapper">';
        $this->render_avatar_group($settings);
        echo '</div>';

        // Wrap heading and description in a single div when 'after'
        if (in_array($settings['title_position'], ['after']) || (isset($settings['description_position']) && in_array($settings['description_position'], ['after']))) {
            echo '<div class="avatar-text-after-wrapper" style="display: flex; flex-direction: column; gap: 8px;">';
            if ($settings['title_position'] === 'after' && $settings['show_title'] === 'yes' && !empty($settings['avatar_heading'])) {
                $this->render_heading($settings, 'after');
            }
            if (isset($settings['description_position']) && $settings['description_position'] === 'after' && $settings['show_description'] === 'yes' && !empty($settings['description_text'])) {
                $this->render_description($settings, 'after');
            }
            echo '</div>';
        }

        echo '</div>'; // end avatar-widget

        // Render heading below
        if ($settings['title_position'] === 'below' && $settings['show_title'] === 'yes' && !empty($settings['avatar_heading'])) {
            $this->render_heading($settings, 'below');
        }

        // Render description below
        if (isset($settings['description_position']) && $settings['description_position'] === 'below' && $settings['show_description'] === 'yes' && !empty($settings['description_text'])) {
            $this->render_description($settings, 'below');
        }

        echo '</div>'; // end avatar-widget-wrapper
        echo '</div>'; // end avatar-outer-wrapper
    }

    protected function render_avatar_group($settings)
    {
        // AVATAR SETTINGS
        // Calculate offset for overlapping
        switch ($settings['avatar_overlap']) {
            case 's':
                $offset = 40;
                break;
            case 'm':
                $offset = 30;
                break;
            case 'l':
                $offset = 20;
                break;
            case 'xl':
                $offset = 10;
                break;
            default:
                $offset = 30;
        }

        // Calculate border radius
        switch ($settings['avatar_shape']) {
            case 'circle':
                $borderRadius = '50%';
                break;
            case 'square':
                $borderRadius = '0';
                break;
            case 'rounded':
                $borderRadius = '12px';
                break;
            default:
                $borderRadius = '50%';
        }

        // Calculate box shadow
        switch ($settings['avatar_shadow']) {
            case 'none':
                $boxShadow = 'none';
                break;
            case 'soft':
                $boxShadow = '0 2px 6px rgba(0,0,0,0.1)';
                break;
            case 'medium':
                $boxShadow = '0 4px 12px rgba(0,0,0,0.2)';
                break;
            case 'strong':
                $boxShadow = '0 6px 18px rgba(0,0,0,0.3)';
                break;
            default:
                $boxShadow = '0 2px 6px rgba(0,0,0,0.1)';
        }

        // Calculate avatar size
        switch ($settings['avatar_size']) {
            case 'xs':
                $avatarSize = 40;
                break;
            case 'sm':
                $avatarSize = 60;
                break;
            case 'md':
                $avatarSize = 80;
                break;
            case 'lg':
                $avatarSize = 100;
                break;
            case 'xl':
                $avatarSize = 120;
                break;
            default:
                $avatarSize = 80;
        }

        // Calculate border style
        $borderStyle = 'none';
        if ($settings['show_border'] === 'yes') {
            $borderWidth = ($settings['avatar_border_width'] === 'custom')
                ? ($settings['avatar_border_width_custom'] ?? '2px')
                : $settings['avatar_border_width'];

            $borderColor = '#fff';
            switch ($settings['avatar_border_color']) {
                case 'primary':
                    $borderColor = '#0073e6';
                    break;
                case 'grey':
                    $borderColor = '#ccc';
                    break;
                case 'black':
                    $borderColor = '#000';
                    break;
                case 'custom':
                    $borderColor = $settings['avatar_border_color_custom'] ?? '#000';
                    break;
            }

            $borderStyle = $borderWidth . ' ' . $settings['avatar_border_type'] . ' ' . $borderColor;
        }

        // Calculate hover effect
        $hover_style = '';
        $hover_on = '';
        if ($settings['avatar_hover_effect'] === 'scale') {
            $hover_style = 'transition: transform 0.3s ease;';
            $hover_on = 'onmouseover="this.style.transform=\'scale(1.1)\'" onmouseout="this.style.transform=\'scale(1)\'"';
        }

        // Get alignment value for inline style
        $alignment = $settings['avatar_horizontal_alignment'] ?? 'center';

        // Render avatar group
        echo '<div class="avatar-group" style="display: flex; flex-direction: row;">';

        foreach ($settings['avatars'] as $index => $avatar) {
            $image_url = ($avatar['avatar_source'] === 'url')
                ? ($avatar['avatar_url'] ?? Utils::get_placeholder_image_src())
                : ($avatar['avatar_image']['url'] ?? Utils::get_placeholder_image_src());

            $link_enabled = isset($avatar['avatar_link_enable']) && $avatar['avatar_link_enable'] === 'yes';
            $link_url = !empty($avatar['avatar_link_url']['url']) ? esc_url($avatar['avatar_link_url']['url']) : '';

            // Get per-item status and position
            $status = $avatar['avatar_status'] ?? 'none';
            $position = $avatar['avatar_status_position'] ?? 'bottom-right';

            // Calculate badge color and position
            $badgeColor = 'transparent';
            $badgePosition = '';
            if ($status !== 'none') {
                switch ($status) {
                    case 'online':
                        $badgeColor = '#4CAF50';
                        break;
                    case 'offline':
                        $badgeColor = '#9E9E9E';
                        break;
                    case 'busy':
                        $badgeColor = '#F44336';
                        break;
                }

                switch ($position) {
                    case 'top-left':
                        $badgePosition = 'top: 4px; left: 4px;';
                        break;
                    case 'top-right':
                        $badgePosition = 'top: 4px; right: 4px;';
                        break;
                    case 'bottom-left':
                        $badgePosition = 'bottom: 8px; left: 8px;';
                        break;
                    case 'bottom-right':
                        $badgePosition = 'bottom: 8px; right: 8px;';
                        break;
                }
            }

            $margin = ($index === array_key_last($settings['avatars'])) ? '0' : '-' . esc_attr($offset) . 'px';
            echo '<div class="avatar-circle" style="position: relative; margin-right: ' . $margin . ';">';

            if ($link_enabled && $link_url) {
                echo '<a href="' . $link_url . '" target="_blank" rel="noopener">';
            }

            echo '<div class="avatar-image">';
            echo '<img src="' . esc_url($image_url) . '" style="width:' . esc_attr($avatarSize) . 'px; height:' . esc_attr($avatarSize) . 'px; border-radius:' . esc_attr($borderRadius) . '; object-fit:cover; border:' . esc_attr($borderStyle) . '; box-shadow:' . esc_attr($boxShadow) . '; ' . $hover_style . '" ' . $hover_on . ' alt="Avatar">';
            echo '</div>';

            if ($link_enabled && $link_url) {
                echo '</a>';
            }

            if ($status !== 'none') {
                echo '<span style="position:absolute; ' . $badgePosition . ' width:12px; height:12px; border-radius:50%; background-color:' . esc_attr($badgeColor) . '; border:1px solid white; box-shadow: 0 0 0 2px #fff;"></span>';
            }

            echo '</div>';
        }

        echo '</div>'; // end avatar-group
    }
}
